#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update -qq
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  libgl1 libxcursor1 libxrandr2 libgtk-3-0 libgdk-pixbuf-2.0-0 \
  libcairo2 libpango-1.0-0 libharfbuzz0b libatk1.0-0 libpangocairo-1.0-0 \
  libasound2 libnss3 libxss1 xvfb xauth
printf 'Unity Linux runtime dependencies installed.\n'
