# Unity 6.3 LTS portable

Version installée : **6000.3.11f1**, changeset officiel `3000ef702840`.

## Emplacements

- Archive officielle persistante : `.tools/unity/Unity-6000.3.11f1.tar.xz`
- Cache extrait à la demande : `/tmp/valdoria-unity/6000.3.11f1`
- Lanceur : `tools/unity/run.sh`
- Dépendances Linux : `tools/unity/install-runtime-deps.sh`

## Utilisation

1. Dans une nouvelle session sandbox, exécuter une fois `tools/unity/install-runtime-deps.sh`, car les paquets système sont éphémères.
2. Vérifier avec `tools/unity/run.sh -version -batchmode -nographics -quit`.
3. Pour ouvrir l’interface, utiliser `tools/unity/run.sh` depuis une session disposant d’un affichage X11.

## Licence

Les fichiers de l’éditeur sont installés, mais Unity exige une licence Unity Personal/Pro valide pour créer, ouvrir ou compiler un projet. L’activation nécessite un compte Unity et ne peut pas être automatisée sans identifiants ou fichier de licence fourni par l’utilisateur.

Aucun module Android, iOS ou WebGL n’est installé afin de limiter l’installation à environ 8,1 Go. Ces modules nécessiteraient plusieurs gigaoctets supplémentaires.
