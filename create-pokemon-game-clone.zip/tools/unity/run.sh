#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
VERSION="6000.3.11f1"
ARCHIVE="$ROOT/.tools/unity/Unity-${VERSION}.tar.xz"
CACHE_ROOT="${TMPDIR:-/tmp}/valdoria-unity/$VERSION"
UNITY="$CACHE_ROOT/Editor/Unity"

if [[ ! -x "$UNITY" ]]; then
  if [[ ! -f "$ARCHIVE" ]]; then
    echo "Unity archive not found: $ARCHIVE" >&2
    exit 1
  fi
  echo "Extracting Unity $VERSION into $CACHE_ROOT (first launch only)..." >&2
  rm -rf "$CACHE_ROOT"
  mkdir -p "$CACHE_ROOT"
  tar -xJf "$ARCHIVE" -C "$CACHE_ROOT"
  chmod +x "$UNITY"
fi

if ldd "$UNITY" 2>/dev/null | grep -q 'not found'; then
  echo "Unity runtime libraries are missing. Run: $HERE/install-runtime-deps.sh" >&2
  exit 2
fi
if [[ -z "${DISPLAY:-}" ]]; then
  exec xvfb-run -a "$UNITY" "$@"
else
  exec "$UNITY" "$@"
fi
