extends Node3D

func _ready() -> void:
    var packed := load("res://models/creature.glb") as PackedScene
    if packed == null:
        push_error("VALDORIA: import GLB impossible")
        get_tree().quit(1)
        return
    var creature := packed.instantiate()
    add_child(creature)
    var animations := creature.find_children("*", "AnimationPlayer", true, false)
    print("VALDORIA_GODOT_OK nodes=", creature.get_child_count(), " animation_players=", animations.size())
    get_tree().quit(0)
