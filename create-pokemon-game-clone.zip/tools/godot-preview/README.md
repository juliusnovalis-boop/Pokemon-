# VALDORIA — Godot asset preview

Projet minimal pour valider les GLB du jeu dans Godot 4.7.

- `godot --headless --path tools/godot-preview --editor --quit` importe les assets.
- `godot --headless --path tools/godot-preview` instancie la créature et vérifie la scène.

Ce projet sert de banc de test pour une éventuelle migration du rendu Three.js vers Godot Web. Le jeu Next.js reste l'application principale.
