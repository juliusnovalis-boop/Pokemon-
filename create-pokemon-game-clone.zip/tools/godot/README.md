# Godot 4.7.2 portable

Le binaire Linux x86_64 officiel est conservé dans ce dossier pour survivre aux sessions isolées du sandbox.

- Version : `./tools/godot/run.sh --version`
- Importer le banc d'essai : `./tools/godot/run.sh --headless --path tools/godot-preview --editor --quit`
- Exécuter le test GLB : `./tools/godot/run.sh --headless --path tools/godot-preview`
- Installer les templates Web/Linux : `./tools/godot/install-export-templates.sh`

Le lanceur isole les données Godot sous `tools/godot/data`, au lieu d'utiliser les dossiers système éphémères.
