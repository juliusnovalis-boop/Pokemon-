#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
export XDG_DATA_HOME="$HERE/data"
export XDG_CONFIG_HOME="$HERE/config"
export XDG_CACHE_HOME="$HERE/cache"
exec "$HERE/godot" "$@"
