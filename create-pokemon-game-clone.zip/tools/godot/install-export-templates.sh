#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
VERSION="4.7.2"
TAG="4.7.2-stable"
DEST="$HERE/data/godot/export_templates/${VERSION}.stable"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$DEST"
curl -fL --retry 3 \
  "https://github.com/godotengine/godot/releases/download/$TAG/Godot_v${TAG}_export_templates.tpz" \
  -o "$TMP/templates.tpz"
unzip -q "$TMP/templates.tpz" -d "$TMP/unpacked"
cp -a "$TMP/unpacked/templates/." "$DEST/"
echo "Godot export templates installed in $DEST"
