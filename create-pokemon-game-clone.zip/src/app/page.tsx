import ValdoriaGame from "@/components/game/ValdoriaGame";

export default function Home() {
  return <ValdoriaGame />;
}
