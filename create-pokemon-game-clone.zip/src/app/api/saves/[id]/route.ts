import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { gameSaves } from "@/db/schema";
import type { SaveState } from "@/lib/game/types";

export const runtime = "nodejs";

type Params = { params: Promise<{ id: string }> };

/** Charge une sauvegarde complete. */
export async function GET(_req: Request, { params }: Params) {
  const { id } = await params;
  const [row] = await db.select().from(gameSaves).where(eq(gameSaves.id, id)).limit(1);
  if (!row) return NextResponse.json({ error: "Sauvegarde introuvable" }, { status: 404 });
  return NextResponse.json({ id: row.id, state: row.state, updatedAt: row.updatedAt.toISOString() });
}

/** Met a jour une sauvegarde (autosave cote client). */
export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  const body = (await req.json().catch(() => null)) as { state?: SaveState } | null;
  if (!body?.state || typeof body.state.playerName !== "string") {
    return NextResponse.json({ error: "Etat invalide" }, { status: 400 });
  }
  const state = body.state;
  const [row] = await db
    .update(gameSaves)
    .set({ state, playerName: state.playerName.slice(0, 40), champion: !!state.champion, updatedAt: new Date() })
    .where(eq(gameSaves.id, id))
    .returning({ id: gameSaves.id });
  if (!row) return NextResponse.json({ error: "Sauvegarde introuvable" }, { status: 404 });
  return NextResponse.json({ ok: true });
}

/** Supprime une sauvegarde. */
export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  await db.delete(gameSaves).where(eq(gameSaves.id, id));
  return NextResponse.json({ ok: true });
}
