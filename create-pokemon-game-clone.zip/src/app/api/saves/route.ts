import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { gameSaves } from "@/db/schema";
import type { SaveMeta, SaveState } from "@/lib/game/types";

export const runtime = "nodejs";

function isValidState(v: unknown): v is SaveState {
  if (typeof v !== "object" || v === null) return false;
  const s = v as SaveState;
  return (
    typeof s.playerName === "string" &&
    Array.isArray(s.team) &&
    Array.isArray(s.box) &&
    Array.isArray(s.badges) &&
    typeof s.eclats === "number" &&
    typeof s.items === "object" &&
    typeof s.champion === "boolean"
  );
}

/** Liste des sauvegardes (metadonnees pour l'ecran "Continuer"). */
export async function GET() {
  const rows = await db.select().from(gameSaves).orderBy(desc(gameSaves.updatedAt)).limit(24);
  const out: SaveMeta[] = rows.map((r) => {
    const state = r.state as SaveState;
    return {
      id: r.id,
      playerName: r.playerName,
      champion: r.champion,
      updatedAt: r.updatedAt.toISOString(),
      teamPreview: (state.team ?? []).slice(0, 6).map((c) => ({ speciesId: c.speciesId, level: c.level })),
    };
  });
  return NextResponse.json(out);
}

/** Nouvelle partie. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => null)) as { state?: unknown } | null;
  if (!body || !isValidState(body.state)) {
    return NextResponse.json({ error: "Etat de sauvegarde invalide" }, { status: 400 });
  }
  const state = body.state;
  if (state.playerName.length > 40) state.playerName = state.playerName.slice(0, 40);
  const [row] = await db
    .insert(gameSaves)
    .values({ playerName: state.playerName, champion: state.champion, state })
    .returning({ id: gameSaves.id });
  return NextResponse.json({ id: row.id }, { status: 201 });
}
