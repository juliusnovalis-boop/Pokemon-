import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "VALDORIA — Chroniques des Gardiens",
  description:
    "Un RPG web 3D de capture de créatures original : explore quatre continents, capture des créatures d'éther, défie les champions et conquière les Couronnes.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="stylesheet" href="/fonts/cinzel.css" />
        <link rel="stylesheet" href="/fonts/manrope.css" />
      </head>
      <body className="bg-[#07071a] font-body text-slate-100 antialiased">{children}</body>
    </html>
  );
}
