"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Compass,
  Crown,
  FolderOpen,
  Globe2,
  Map,
  Shield,
  Sparkles,
  Swords,
  Trash2,
} from "lucide-react";
import { useGame } from "@/lib/game/store";
import { getSpecies } from "@/lib/game/data/species";
import { CreaturePortrait } from "./bits";

const REGIONS = [
  { name: "Afikala", note: "Savanes & légendes", color: "#e8a53c" },
  { name: "Ameritopia", note: "Canyons & néons", color: "#e0524d" },
  { name: "Ashikawa", note: "Temples & dragons", color: "#e14b5a" },
  { name: "Euroterra", note: "Châteaux & fjords", color: "#7f9fe8" },
];

export default function TitleScreen() {
  const { saves, fetchSaves, loadGame, deleteGame, goStarter } = useGame();
  const [name, setName] = useState("");

  useEffect(() => {
    fetchSaves();
  }, [fetchSaves]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#070b18]">
      <Image src="/art/hero.jpg" alt="Les îles de Valdoria" fill priority className="object-cover object-center" />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(5,9,20,.96)_0%,rgba(5,9,20,.78)_43%,rgba(5,9,20,.36)_72%,rgba(5,9,20,.78)_100%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(7,11,24,.18),rgba(7,11,24,.46)_64%,#070b18_100%)]" />
      <div className="world-grid absolute inset-0 opacity-55" />
      <div className="topo-lines absolute -left-16 top-0 h-full w-[48%] opacity-60" />

      <div className="relative z-10 mx-auto grid min-h-screen max-w-7xl items-center gap-10 px-5 py-10 lg:grid-cols-[1.14fr_.86fr] lg:px-10">
        {/* Identite du jeu */}
        <section className="pt-8 lg:pt-0">
          <motion.div
            initial={{ opacity: 0, x: -18 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-7 inline-flex items-center gap-3 rounded-full border border-[#e8c97a]/25 bg-[#111a2d]/70 px-4 py-2 backdrop-blur-md"
          >
            <Compass className="h-4 w-4 text-[#f0ca78]" />
            <span className="ui-kicker text-[#ead39e]">RPG d&apos;exploration 3D</span>
            <span className="h-1 w-1 rounded-full bg-[#e8c97a]" />
            <span className="text-[10px] font-bold uppercase tracking-[.18em] text-slate-400">Monde persistant</span>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="ui-kicker mb-3 text-[#d4b56f]"
          >
            Chroniques des Gardiens
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.16 }}
            className="font-display text-6xl font-black leading-[.88] tracking-[-0.045em] text-[#fff9e9] sm:text-7xl lg:text-[6.7rem]"
            style={{ textShadow: "0 8px 50px rgba(0,0,0,.55)" }}
          >
            VALDORIA
            <span className="mt-3 block text-xl font-medium tracking-[.34em] text-[#e8c97a] sm:text-2xl">
              LES QUATRE COURONNES
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.28 }}
            className="mt-7 max-w-2xl text-base font-medium leading-7 text-slate-300 sm:text-lg"
          >
            Choisis ton continent, lie-toi à une créature d&apos;éther et traverse un monde où chaque autel protège une histoire oubliée.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.36 }}
            className="mt-8 grid max-w-2xl grid-cols-2 gap-2 sm:grid-cols-4"
          >
            {REGIONS.map((region) => (
              <div key={region.name} className="ui-region-card rounded-xl px-3 py-3" style={{ borderTopColor: region.color }}>
                <span className="mb-2 block h-1 w-8 rounded-full" style={{ background: region.color, boxShadow: `0 0 12px ${region.color}` }} />
                <p className="font-display text-sm font-bold text-white">{region.name}</p>
                <p className="mt-1 text-[10px] font-medium text-slate-400">{region.note}</p>
              </div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.48 }}
            className="mt-9 flex flex-wrap gap-x-8 gap-y-4"
          >
            <Stat icon={Sparkles} value="29" label="Créatures" />
            <Stat icon={Swords} value="24" label="Champions" />
            <Stat icon={Crown} value="4" label="Couronnes" />
          </motion.div>
        </section>

        {/* Carnet de départ */}
        <motion.aside
          initial={{ opacity: 0, x: 24, rotateY: -5 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="ui-parchment rounded-[1.75rem] p-5 sm:p-7"
        >
          <div className="relative z-[1]">
            <div className="flex items-start justify-between gap-5">
              <div>
                <p className="ui-kicker text-[#9d7130]">Carnet de voyage</p>
                <h2 className="font-display mt-2 text-2xl font-black text-[#172035]">Commencer l&apos;expédition</h2>
              </div>
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-[#aa8952]/30 bg-[#172035] text-[#f4d486] shadow-lg">
                <Map className="h-5 w-5" />
              </div>
            </div>

            <div className="my-5 h-px bg-gradient-to-r from-transparent via-[#7e6845]/30 to-transparent" />

            <label htmlFor="trainer-name" className="ui-kicker text-[#645438]">
              Nom du dresseur
            </label>
            <div className="mt-2.5 flex flex-col gap-3 sm:flex-row">
              <input
                id="trainer-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && goStarter(name)}
                maxLength={20}
                placeholder="Comment doit-on t'appeler ?"
                className="ui-input rounded-xl px-4 py-3.5 text-sm font-semibold"
              />
              <button
                onClick={() => goStarter(name)}
                className="ui-button-primary soft-shine inline-flex shrink-0 items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-xs font-black uppercase tracking-[.16em]"
              >
                Partir <ArrowRight className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-6 flex items-center gap-3 rounded-xl border border-[#7c6949]/15 bg-white/35 px-3.5 py-3 text-[#51472f]">
              <Shield className="h-5 w-5 shrink-0 text-[#a5752c]" />
              <p className="text-[11px] font-semibold leading-4">
                Progression sauvegardée automatiquement après chaque combat, capture et achat.
              </p>
            </div>

            {saves.length > 0 && (
              <div className="mt-7">
                <div className="mb-3 flex items-center justify-between">
                  <p className="ui-kicker flex items-center gap-2 text-[#645438]">
                    <FolderOpen className="h-3.5 w-3.5" /> Reprendre
                  </p>
                  <span className="rounded-full bg-[#172035]/10 px-2 py-0.5 text-[10px] font-black text-[#172035]">{saves.length}</span>
                </div>
                <ul className="max-h-60 space-y-2 overflow-y-auto pr-1">
                  {saves.map((save) => (
                    <li
                      key={save.id}
                      className="group flex items-center gap-3 rounded-xl border border-[#392f21]/10 bg-white/45 p-3 transition hover:-translate-y-0.5 hover:border-[#a5752c]/35 hover:bg-white/75 hover:shadow-md"
                    >
                      <button onClick={() => loadGame(save.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                        <div className="flex -space-x-2.5">
                          {save.teamPreview.slice(0, 3).map((preview, i) => (
                            <span key={i} className="rounded-full border-2 border-[#f4ecd9] shadow-sm" title={getSpecies(preview.speciesId).name}>
                              <CreaturePortrait speciesId={preview.speciesId} size={38} ring={false} glow={false} />
                            </span>
                          ))}
                        </div>
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-2 truncate font-display text-sm font-bold text-[#172035]">
                            {save.playerName}
                            {save.champion && <Crown className="h-3.5 w-3.5 text-[#b67f27]" />}
                          </span>
                          <span className="mt-0.5 block text-[10px] font-semibold uppercase tracking-wider text-[#81765f]">
                            {new Date(save.updatedAt).toLocaleDateString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                          </span>
                        </span>
                        <ArrowRight className="h-4 w-4 text-[#a5752c] opacity-0 transition group-hover:opacity-100" />
                      </button>
                      <button
                        onClick={() => deleteGame(save.id)}
                        className="rounded-lg p-2 text-[#9b8b70] opacity-40 transition hover:bg-red-100 hover:text-red-700 group-hover:opacity-100"
                        title="Supprimer la sauvegarde"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </motion.aside>
      </div>

      <div className="absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 text-[9px] font-bold uppercase tracking-[.24em] text-slate-500">
        <Globe2 className="h-3.5 w-3.5" /> Un monde original · Assets 3D CC0 · Sauvegarde PostgreSQL
      </div>
    </div>
  );
}

function Stat({ icon: Icon, value, label }: { icon: typeof Sparkles; value: string; label: string }) {
  return (
    <div className="ui-stat flex items-center gap-3">
      <Icon className="h-5 w-5 text-[#e8c97a]" />
      <span>
        <b className="font-display block text-xl leading-none text-white">{value}</b>
        <span className="text-[9px] font-extrabold uppercase tracking-[.2em] text-slate-500">{label}</span>
      </span>
    </div>
  );
}
