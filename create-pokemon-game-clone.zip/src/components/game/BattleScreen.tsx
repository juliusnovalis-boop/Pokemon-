"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { AnimatePresence, motion } from "framer-motion";
import { Backpack, ChevronsRight, Flag, Loader2, Swords, Users } from "lucide-react";
import { useGame } from "@/lib/game/store";
import { getZone } from "@/lib/game/data/regions";
import { getSpecies } from "@/lib/game/data/species";
import { getMove } from "@/lib/game/data/moves";
import { ITEMS, maxHpOf, xpNeeded } from "@/lib/game/engine";
import { TYPE_COLOR } from "@/lib/game/data/chart";
import type { ItemId, OwnedCreature } from "@/lib/game/types";
import { HpBar, StatusBadge, TypeChip } from "./bits";

const BattleScene = dynamic(() => import("@/components/game3d/BattleScene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-[#e8c97a]" />
    </div>
  ),
});

type Menu = "root" | "moves" | "bag" | "team" | null;

export default function BattleScreen() {
  const { battle, state, actMove, actItem, actSwitch, actRun, finishBattle } = useGame();
  const [menu, setMenu] = useState<Menu>(null);
  const [busy, setBusy] = useState(true);
  const logRef = useRef<HTMLDivElement>(null);
  const lastLogLen = useRef(0);

  // Lecture animee du journal : on bloque les actions un court instant par evenement.
  useEffect(() => {
    if (!battle) return;
    const added = battle.log.length - lastLogLen.current;
    lastLogLen.current = battle.log.length;
    const duration = battle.over ? 900 : Math.min(2400, 500 + Math.max(0, added) * 400);
    setBusy(true);
    const t = setTimeout(() => setBusy(false), duration);
    return () => clearTimeout(t);
  }, [battle]);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: "smooth" });
  }, [battle?.log.length]);

  if (!battle || !state) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#e8c97a]" />
      </div>
    );
  }

  const zone = getZone(state.region, battle.zoneId);
  const player = state.team[battle.playerIndex];
  const enemy = battle.enemyTeam[battle.enemyIndex];
  if (!player || !enemy) return null;

  const pSpecies = getSpecies(player.speciesId);
  const eSpecies = getSpecies(enemy.speciesId);
  const playerMax = maxHpOf(player);
  const enemyMax = maxHpOf(enemy);
  const canAct = !busy && !battle.over && !battle.awaitingSwitch;
  const tint = TYPE_COLOR[eSpecies.type];
  const orbIds: ItemId[] = ["orbe", "super-orbe", "hyper-orbe"];
  const healIds: ItemId[] = ["potion", "elixir"];

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Scene 3D du duel */}
      <div className="absolute inset-0">
        <BattleScene battle={battle} playerSpeciesId={player.speciesId} playerFainted={player.hp <= 0 && !battle.over} />
      </div>
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#07071a]/70 via-transparent to-[#07071a]/80" />

      {/* Bandeau haut */}
      <div className="absolute inset-x-0 top-0 z-20 p-4">
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <div className="hud-plate rounded-xl px-4 py-2.5" style={{ borderLeftColor: zone.hue, borderLeftWidth: 3 }}>
            <p className="text-[10px] font-semibold uppercase tracking-[0.3em]" style={{ color: zone.hue }}>
              {zone.name}
            </p>
            <h2 className="font-display text-sm font-bold tracking-wide text-slate-100 md:text-base">
              {battle.kind === "boss" ? `${battle.bossTitle} — ${battle.bossName}` : "Rencontre sauvage"}
            </h2>
          </div>
          {battle.kind === "boss" && (
            <div className="flex items-center gap-1.5 rounded-full border border-white/10 bg-black/50 px-3 py-2 backdrop-blur-md">
              {battle.enemyTeam.map((c, i) => (
                <span
                  key={c.uid}
                  className={`h-2.5 w-2.5 rounded-full ${i === battle.enemyIndex ? "ring-2 ring-white/50" : ""}`}
                  style={{ background: c.hp > 0 ? "#ff5f6d" : "#3a3a4a" }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Carte ennemie */}
      <div className="absolute right-4 top-24 z-20 md:right-10 md:top-20">
        <motion.div
          key={enemy.uid}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          className="battle-plate w-64 rounded-2xl p-3.5"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-display truncate text-sm font-black text-[#172035]">{eSpecies.name}</span>
            <span className="rounded-md bg-[#172035]/8 px-2 py-0.5 text-[10px] font-black text-[#4e4a40]">NIV. {enemy.level}</span>
          </div>
          <div className="mt-1 flex items-center gap-2">
            <TypeChip type={eSpecies.type} />
            <StatusBadge status={enemy.status} />
          </div>
          <div className="mt-2">
            <HpBar hp={enemy.hp} max={enemyMax} />
          </div>
        </motion.div>
        <AnimatePresence>
          {battle.lastHit?.side === "enemy" && battle.lastHit.dmg > 0 && (
            <motion.span
              key={battle.lastHit.key}
              initial={{ opacity: 0, y: 0, scale: 0.8 }}
              animate={{ opacity: 1, y: -30, scale: 1.2 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="pointer-events-none absolute -left-6 top-1/2 font-display text-3xl font-black text-[#ffd9d0]"
              style={{ textShadow: `0 0 18px ${tint}` }}
            >
              -{battle.lastHit.dmg}
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Carte joueur */}
      <div className="absolute bottom-[268px] left-4 z-20 md:bottom-[250px] md:left-10">
        <motion.div
          key={player.uid}
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="battle-plate w-64 rounded-2xl p-3.5"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-display truncate text-sm font-black text-[#172035]">{pSpecies.name}</span>
            <span className="rounded-md bg-[#172035]/8 px-2 py-0.5 text-[10px] font-black text-[#4e4a40]">NIV. {player.level}</span>
          </div>
          <div className="mt-1 flex items-center gap-2">
            <TypeChip type={pSpecies.type} />
            <StatusBadge status={player.status} />
          </div>
          <div className="mt-2">
            <HpBar hp={player.hp} max={playerMax} />
          </div>
          <div className="mt-1 flex items-center justify-between text-[10px] tabular-nums text-slate-500">
            <span>
              PV {player.hp}/{playerMax}
            </span>
            <span>
              XP {player.xp}/{xpNeeded(player.level)}
            </span>
          </div>
        </motion.div>
        <AnimatePresence>
          {battle.lastHit?.side === "player" && battle.lastHit.dmg > 0 && (
            <motion.span
              key={battle.lastHit.key}
              initial={{ opacity: 0, y: 0, scale: 0.8 }}
              animate={{ opacity: 1, y: -30, scale: 1.2 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="pointer-events-none absolute -right-6 top-1/2 font-display text-3xl font-black text-[#ffd9d0]"
              style={{ textShadow: "0 0 18px #ff5f3d" }}
            >
              -{battle.lastHit.dmg}
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Console inferieure */}
      <div className="absolute inset-x-0 bottom-0 z-20 p-4">
        <div className="mx-auto grid max-w-6xl gap-3 md:grid-cols-[1fr_1.15fr]">
          {/* Journal */}
          <div ref={logRef} className="h-32 space-y-1 overflow-y-auto rounded-2xl border border-white/10 bg-black/60 p-4 backdrop-blur-md md:h-40">
            {battle.log.slice(-9).map((l) => (
              <p
                key={l.id}
                className={`text-[13px] leading-snug ${
                  l.tone === "good" ? "text-emerald-300" : l.tone === "bad" ? "text-rose-300" : l.tone === "warn" ? "text-amber-300" : "text-slate-200"
                }`}
              >
                {l.text}
              </p>
            ))}
          </div>

          {/* Actions */}
          <div className="ui-glass min-h-[10rem] rounded-2xl p-4">
            {battle.over ? (
              <div className="flex h-full flex-col items-center justify-center gap-3">
                <p className="font-display text-xl font-bold text-slate-100">
                  {battle.over === "win"
                    ? battle.kind === "boss"
                      ? "Le Gardien s'incline."
                      : "Victoire !"
                    : battle.over === "caught"
                      ? "Capture réussie !"
                      : battle.over === "flee"
                        ? "Fuite réussie."
                        : "Défaite…"}
                </p>
                <button
                  onClick={finishBattle}
                  disabled={busy}
                  className="ui-button-primary inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-black uppercase tracking-widest disabled:opacity-60"
                >
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ChevronsRight className="h-4 w-4" />}
                  Continuer
                </button>
              </div>
            ) : battle.awaitingSwitch ? (
              <div>
                <p className="mb-2.5 text-xs font-bold uppercase tracking-widest text-rose-300">
                  Choisis la prochaine créature à envoyer !
                </p>
                <TeamPicker state={state} activeUid={player.uid} onPick={actSwitch} />
              </div>
            ) : menu === null ? (
              <div className="flex h-full flex-col items-center justify-center gap-2">
                {busy ? (
                  <p className="inline-flex items-center gap-2 text-sm text-slate-400">
                    <Loader2 className="h-4 w-4 animate-spin" /> Le combat se déroule…
                  </p>
                ) : (
                  <p className="text-sm text-slate-300">Que doit faire {pSpecies.name} ?</p>
                )}
                <button
                  onClick={() => setMenu("root")}
                  disabled={!canAct}
                  className="ui-button-primary mt-1 rounded-xl px-8 py-3 text-sm font-black uppercase tracking-widest disabled:opacity-50"
                >
                  Ouvrir les actions
                </button>
              </div>
            ) : menu === "root" ? (
              <div className="grid h-full grid-cols-2 gap-2">
                <MenuBtn icon={Swords} label="Attaquer" onClick={() => setMenu("moves")} disabled={!canAct} accent />
                <MenuBtn icon={Backpack} label="Sac" onClick={() => setMenu("bag")} disabled={!canAct} />
                <MenuBtn icon={Users} label="Équipe" onClick={() => setMenu("team")} disabled={!canAct} />
                <MenuBtn
                  icon={Flag}
                  label={battle.kind === "wild" ? "Fuite" : "Pas de fuite"}
                  onClick={() => {
                    if (battle.kind === "wild") {
                      actRun();
                      setMenu(null);
                    }
                  }}
                  disabled={!canAct || battle.kind !== "wild"}
                />
              </div>
            ) : menu === "moves" ? (
              <div>
                <div className="grid grid-cols-2 gap-2">
                  {player.moves.map((mid) => {
                    const m = getMove(mid);
                    return (
                      <button
                        key={mid}
                        disabled={!canAct}
                        onClick={() => {
                          actMove(mid);
                          setMenu(null);
                        }}
                        className="ui-button-dark rounded-xl px-3 py-2.5 text-left disabled:opacity-50"
                      >
                        <span className="flex items-center justify-between gap-2">
                          <span className="truncate text-sm font-bold text-slate-100">{m.name}</span>
                          <span className="text-[10px] font-bold" style={{ color: TYPE_COLOR[m.type] }}>
                            {m.power}
                          </span>
                        </span>
                        <span className="mt-1 block">
                          <TypeChip type={m.type} />
                        </span>
                      </button>
                    );
                  })}
                </div>
                <BackBtn onClick={() => setMenu("root")} />
              </div>
            ) : menu === "bag" ? (
              <div>
                <div className="grid grid-cols-2 gap-2">
                  {[...orbIds, ...healIds].map((id) => {
                    const n = state.items[id] ?? 0;
                    const isOrb = ITEMS[id].kind === "orbe";
                    const disabledOrb = isOrb && battle.kind !== "wild";
                    return (
                      <button
                        key={id}
                        disabled={!canAct || n <= 0 || disabledOrb}
                        onClick={() => {
                          actItem(id);
                          setMenu(null);
                        }}
                        className="ui-button-dark rounded-xl px-3 py-2.5 text-left disabled:opacity-40"
                        title={disabledOrb ? "Impossible de capturer la créature d'un Gardien" : ITEMS[id].desc}
                      >
                        <span className="flex items-center justify-between text-sm font-bold text-slate-100">
                          {ITEMS[id].name}
                          <span className="text-[11px] text-slate-400">×{n}</span>
                        </span>
                        <span className="mt-0.5 block text-[10px] uppercase tracking-wider text-slate-500">
                          {isOrb ? "Capture" : "Soin"}
                          {disabledOrb && " · impossible ici"}
                        </span>
                      </button>
                    );
                  })}
                </div>
                <BackBtn onClick={() => setMenu("root")} />
              </div>
            ) : (
              <div>
                <TeamPicker
                  state={state}
                  activeUid={player.uid}
                  note="Changer de créature consomme ton tour."
                  onPick={(uid) => {
                    actSwitch(uid);
                    setMenu(null);
                  }}
                />
                <BackBtn onClick={() => setMenu("root")} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function MenuBtn({
  icon: Icon,
  label,
  onClick,
  disabled,
  accent,
}: {
  icon: typeof Swords;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center justify-center gap-2 rounded-xl px-4 py-3.5 text-sm font-bold uppercase tracking-widest transition disabled:opacity-40 ${
        accent ? "text-[#1a1408] hover:brightness-110" : "border border-white/10 bg-white/5 text-slate-100 hover:bg-white/10"
      }`}
      style={accent ? { background: "linear-gradient(135deg,#f6dd9b,#d9a94e)" } : undefined}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}

function BackBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="ui-button-dark mt-2 w-full rounded-lg py-1.5 text-[11px] font-bold uppercase tracking-widest text-slate-300"
    >
      Retour
    </button>
  );
}

function TeamPicker({
  state,
  activeUid,
  onPick,
  note,
}: {
  state: { team: OwnedCreature[] };
  activeUid: string;
  onPick: (uid: string) => void;
  note?: string;
}) {
  return (
    <div>
      {note && <p className="mb-2 text-[11px] text-slate-500">{note}</p>}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {state.team.map((c) => {
          const sp = getSpecies(c.speciesId);
          const ko = c.hp <= 0;
          const active = c.uid === activeUid;
          return (
            <button
              key={c.uid}
              disabled={ko || active}
              onClick={() => onPick(c.uid)}
              className={`flex items-center gap-2.5 rounded-xl border px-2.5 py-2 text-left transition ${
                active
                  ? "border-[#e8c97a]/40 bg-[#e8c97a]/10"
                  : ko
                    ? "border-white/5 bg-white/[0.02] opacity-40"
                    : "border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              <span className="relative h-9 w-9 shrink-0 overflow-hidden rounded-full border border-white/20">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={sp.image} alt={sp.name} className="h-full w-full object-cover" />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-xs font-bold text-slate-100">
                  {sp.name}
                  {active && <span className="ml-1 text-[9px] uppercase text-[#e8c97a]">· actif</span>}
                </span>
                <span className="block text-[10px] text-slate-400">
                  Niv. {c.level} · PV {c.hp}/{maxHpOf(c)}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
