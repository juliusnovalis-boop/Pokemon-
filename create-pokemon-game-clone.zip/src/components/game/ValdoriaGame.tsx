"use client";

import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useGame } from "@/lib/game/store";
import TitleScreen from "./TitleScreen";
import StarterScreen from "./StarterScreen";
import WorldScreen from "./WorldScreen";
import BattleScreen from "./BattleScreen";

export default function ValdoriaGame() {
  const { screen, notice, setNotice } = useGame();

  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(null), 6000);
    return () => clearTimeout(t);
  }, [notice, setNotice]);

  return (
    <div className="min-h-screen bg-[#07071a] text-slate-100">
      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0, scale: 0.995 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.005 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
        >
          {screen === "title" && <TitleScreen />}
          {screen === "starter" && <StarterScreen />}
          {screen === "overworld" && <WorldScreen />}
          {screen === "battle" && <BattleScreen />}
        </motion.div>
      </AnimatePresence>

      <AnimatePresence>
        {notice && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="fixed bottom-6 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2"
          >
            <div className="battle-plate rounded-2xl border-l-4 border-l-[#d7a947] px-5 py-3.5 text-center text-sm font-bold text-[#172035]">
              {notice}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
