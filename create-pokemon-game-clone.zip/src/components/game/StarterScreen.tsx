"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Check,
  FlaskConical,
  Loader2,
  MapPin,
  ShieldAlert,
  Sparkles,
} from "lucide-react";
import { useGame } from "@/lib/game/store";
import { REGIONS, getRegion } from "@/lib/game/data/regions";
import { SPECIES } from "@/lib/game/data/species";
import { TYPE_COLOR } from "@/lib/game/data/chart";
import { CreaturePortrait, TypeChip } from "./bits";

export default function StarterScreen() {
  const { pendingStarterName, createGame, backToTitle } = useGame();
  const [regionId, setRegionId] = useState(REGIONS[0].id);
  const [busy, setBusy] = useState<string | null>(null);
  const region = getRegion(regionId);

  const stats = (id: string) => {
    const s = SPECIES[id].base;
    return [
      { label: "Vitalité", short: "PV", value: s.hp },
      { label: "Attaque", short: "ATK", value: s.atk },
      { label: "Défense", short: "DEF", value: s.def },
      { label: "Vitesse", short: "VIT", value: s.spd },
    ];
  };

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#070b18] px-4 py-6 sm:px-7 lg:px-10">
      <div
        className="absolute inset-0 transition-colors duration-700"
        style={{
          background: `radial-gradient(850px 520px at 80% -5%, ${region.hue}35, transparent 62%), radial-gradient(800px 500px at -10% 100%, ${region.hue}18, transparent 70%), #070b18`,
        }}
      />
      <div className="world-grid absolute inset-0 opacity-55" />
      <div className="topo-lines absolute inset-0 opacity-45" />

      <main className="relative z-10 mx-auto max-w-7xl">
        <header className="flex items-center justify-between gap-4">
          <button onClick={backToTitle} className="ui-button-dark inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-[10px] font-black uppercase tracking-[.18em]">
            <ArrowLeft className="h-4 w-4" /> Retour
          </button>
          <div className="hidden items-center gap-3 sm:flex">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#e8c97a] text-[10px] font-black text-[#172035]">1</span>
            <span className="ui-kicker text-[#e8c97a]">Choix du continent</span>
            <span className="h-px w-12 bg-white/15" />
            <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/20 text-[10px] font-black text-slate-400">2</span>
            <span className="ui-kicker text-slate-500">Premier compagnon</span>
          </div>
          <p className="font-display text-sm font-bold tracking-[.22em] text-[#f7e6b7]">VALDORIA</p>
        </header>

        <section className="mt-8 grid gap-7 lg:grid-cols-[.72fr_1.28fr]">
          {/* Atlas des continents */}
          <div>
            <p className="ui-kicker text-[#d6b66f]">Atlas des quatre couronnes</p>
            <h1 className="font-display mt-3 max-w-xl text-3xl font-black leading-tight text-[#fff9e9] sm:text-4xl">
              Où commencera ton histoire, {pendingStarterName} ?
            </h1>
            <p className="mt-3 max-w-xl text-sm font-medium leading-6 text-slate-400">
              Chaque continent possède son climat, ses champions, ses créatures et une menace différente.
            </p>

            <div className="mt-6 grid gap-2 sm:grid-cols-2 lg:grid-cols-1">
              {REGIONS.map((candidate, index) => {
                const active = candidate.id === regionId;
                return (
                  <button
                    key={candidate.id}
                    onClick={() => setRegionId(candidate.id)}
                    data-active={active}
                    className="ui-region-card group rounded-2xl p-4 text-left"
                    style={{ "--region-color": candidate.hue } as React.CSSProperties}
                  >
                    <div className="flex items-center gap-4">
                      <span
                        className="font-display flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border text-lg font-black"
                        style={{ color: candidate.hue, borderColor: `${candidate.hue}55`, background: `${candidate.hue}16` }}
                      >
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <b className="font-display text-lg text-white">{candidate.name}</b>
                          {active && <Check className="h-4 w-4" style={{ color: candidate.hue }} />}
                        </span>
                        <span className="mt-0.5 block truncate text-[11px] font-semibold text-slate-400">{candidate.tagline}</span>
                      </span>
                      <ArrowRight className={`h-4 w-4 transition ${active ? "translate-x-0 opacity-100" : "-translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-70"}`} style={{ color: candidate.hue }} />
                    </div>
                  </button>
                );
              })}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={region.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="ui-glass mt-4 rounded-2xl p-4"
              >
                <div className="relative z-[1] space-y-3">
                  <div className="flex items-start gap-3">
                    <FlaskConical className="mt-0.5 h-4 w-4 shrink-0" style={{ color: region.hue }} />
                    <div>
                      <p className="ui-kicker text-slate-500">Guide scientifique</p>
                      <p className="mt-1 text-sm font-bold text-slate-200">{region.professor}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" style={{ color: region.hue }} />
                    <div>
                      <p className="ui-kicker text-slate-500">Menace détectée</p>
                      <p className="mt-1 text-sm font-bold text-slate-200">{region.villain}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Selection du compagnon */}
          <div>
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="ui-kicker flex items-center gap-2" style={{ color: region.hue }}>
                  <Sparkles className="h-3.5 w-3.5" /> Partenaires disponibles
                </p>
                <h2 className="font-display mt-2 text-2xl font-black text-white">Choisis avec le cœur</h2>
              </div>
              <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-slate-500">
                <BookOpen className="h-4 w-4" /> Données du {region.professor}
              </p>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={region.id}
                initial={{ opacity: 0, x: 18 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -18 }}
                className="grid gap-4 md:grid-cols-3"
              >
                {region.starters.map((id, index) => {
                  const species = SPECIES[id];
                  const color = TYPE_COLOR[species.type];
                  return (
                    <motion.article
                      key={id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.08 }}
                      whileHover={{ y: -7 }}
                      className="ui-creature-card group relative flex min-h-[30rem] flex-col overflow-hidden rounded-[1.6rem] p-4"
                      style={{ "--type-color": color } as React.CSSProperties}
                    >
                      <div className="relative z-[1] flex h-full flex-col">
                        <div className="flex items-center justify-between">
                          <span className="font-display text-xs font-black text-[#8b7651]">N° {String(index + 1).padStart(2, "0")}</span>
                          <TypeChip type={species.type} size="md" />
                        </div>

                        <div className="mx-auto mt-3 w-fit transition duration-300 group-hover:scale-[1.04]">
                          <CreaturePortrait speciesId={id} size={164} ring={false} glow={false} shape="card" />
                        </div>

                        <h3 className="font-display mt-3 text-center text-xl font-black text-[#172035]">{species.name}</h3>
                        <p className="mt-2 min-h-[66px] text-center text-[11px] font-semibold leading-[1.55] text-[#6e644f]">{species.desc}</p>

                        <div className="my-3 h-px bg-gradient-to-r from-transparent via-[#7e6845]/25 to-transparent" />
                        <div className="space-y-2">
                          {stats(id).map((stat) => (
                            <div key={stat.short} className="grid grid-cols-[2.2rem_1fr_1.7rem] items-center gap-2">
                              <span className="text-[9px] font-black tracking-wider text-[#7b6b50]" title={stat.label}>{stat.short}</span>
                              <div className="h-1.5 overflow-hidden rounded-full bg-[#172035]/10">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${Math.min(100, (stat.value / 90) * 100)}%` }}
                                  transition={{ delay: 0.18 + index * 0.08, duration: 0.65 }}
                                  className="h-full rounded-full"
                                  style={{ background: `linear-gradient(90deg, ${color}aa, ${color})` }}
                                />
                              </div>
                              <span className="text-right text-[10px] font-black tabular-nums text-[#172035]">{stat.value}</span>
                            </div>
                          ))}
                        </div>

                        <button
                          disabled={busy !== null}
                          onClick={async () => {
                            setBusy(id);
                            await createGame(id, region.id);
                          }}
                          className="mt-auto inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/70 px-3 py-3 text-xs font-black uppercase tracking-[.13em] text-[#121722] shadow-[0_3px_0_color-mix(in_srgb,var(--type-color)_48%,#4a3820)] transition hover:-translate-y-0.5 hover:brightness-110 disabled:opacity-50"
                          style={{ background: `linear-gradient(180deg, ${color}cc, ${color})` }}
                        >
                          {busy === id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                          {busy === id ? "Préparation…" : `Choisir ${species.name}`}
                        </button>
                      </div>
                    </motion.article>
                  );
                })}
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        <footer className="mt-7 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 border-t border-white/8 pt-4 text-[9px] font-bold uppercase tracking-[.2em] text-slate-600">
          <span className="inline-flex items-center gap-1.5"><MapPin className="h-3 w-3" /> Six zones par continent</span>
          <span>·</span>
          <span>Progression sauvegardée automatiquement</span>
        </footer>
      </main>
    </div>
  );
}
