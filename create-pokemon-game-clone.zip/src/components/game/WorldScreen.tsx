"use client";

import { useRef, useState } from "react";
import dynamic from "next/dynamic";
import { AnimatePresence, motion } from "framer-motion";
import {
  Archive,
  Coins,
  Crown,
  Gamepad2,
  HeartPulse,
  Loader2,
  LogOut,
  Medal,
  ShoppingBag,
  Sparkles,
  Swords,
  Users,
  X,
} from "lucide-react";
import { useGame } from "@/lib/game/store";
import { getRegion, getZone } from "@/lib/game/data/regions";
import { getAreas } from "@/lib/game/data/worldLayout";
import type { WorldControls } from "@/components/game3d/WorldScene";
import { BoxPanel, ShopPanel, TeamPanel } from "./panels";

const WorldScene = dynamic(() => import("@/components/game3d/WorldScene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-[#e8c97a]" />
    </div>
  ),
});

type Drawer = "equipe" | "reserve" | "boutique" | null;

export default function WorldScreen() {
  const { state, startWild, startBoss, healAtSanctuary, backToTitle, setNotice } = useGame();
  const controlsRef = useRef<WorldControls>({ x: 0, z: 0, sprint: false });
  const [proximity, setProximity] = useState<string | null>(null);
  const [drawer, setDrawer] = useState<Drawer>(null);
  const [showHelp, setShowHelp] = useState(true);

  if (!state) return null;
  const region = getRegion(state.region);
  const areas = getAreas(region);
  const badges = state.badges;
  const badgesCount = Math.min(5, badges.length);
  const zone = proximity ? getZone(state.region, proximity) : null;
  const zoneBeaten = zone ? badges.includes(zone.id) : false;
  const zoneLocked = zone ? badges.length < zone.minBadges : false;

  const DRAWERS: { id: Exclude<Drawer, null>; label: string; icon: typeof Users }[] = [
    { id: "equipe", label: `Équipe (${state.team.length})`, icon: Users },
    { id: "reserve", label: `Réserve (${state.box.length})`, icon: Archive },
    { id: "boutique", label: "Boutique", icon: ShoppingBag },
  ];

  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Scene 3D */}
      <div className="absolute inset-0">
        <WorldScene
          controlsRef={controlsRef}
          badges={badges}
          champion={state.champion}
          areas={areas}
          zones={region.zones}
          onEncounter={(zoneId) => startWild(zoneId)}
          onProximity={setProximity}
          onSanctuary={() => {
            healAtSanctuary();
            setNotice("Le Sanctuaire restaure toute ton équipe.");
          }}
        />
      </div>

      {/* HUD superieur */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-20 p-4">
        <div className="pointer-events-auto mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/50 px-4 py-3 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <p className="font-display text-sm font-bold tracking-[0.25em] text-[#e8c97a]">VALDORIA</p>
            <span className="h-4 w-px bg-white/15" />
            <h1 className="flex items-center gap-2 text-sm font-bold text-slate-100">
              {state.playerName}
              {state.champion && <Crown className="h-4 w-4 text-[#e8c97a]" />}
            </h1>
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Medal key={i} className={`h-3.5 w-3.5 ${i < badgesCount ? "text-[#e8c97a]" : "text-slate-700"}`} />
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#e8c97a]/25 bg-[#e8c97a]/10 px-3 py-1.5 text-xs font-black text-[#ffe1a0] shadow-inner">
              <Coins className="h-3.5 w-3.5" /> {state.eclats}
            </span>
            <button
              onClick={() => {
                healAtSanctuary();
                setNotice("Ton équipe est entièrement soignée.");
              }}
              className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 text-xs font-bold text-emerald-300 transition hover:bg-emerald-400/20"
            >
              <HeartPulse className="h-3.5 w-3.5" /> Soigner
            </button>
            <button
              onClick={backToTitle}
              className="rounded-full border border-white/10 bg-white/5 p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-slate-200"
              title="Retour au titre"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Aide debutante */}
      <AnimatePresence>
        {showHelp && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute left-1/2 top-20 z-20 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2"
          >
            <div className="relative rounded-2xl border border-white/10 bg-black/60 px-4 py-3 text-center text-xs leading-relaxed text-slate-300 backdrop-blur-md">
              <button onClick={() => setShowHelp(false)} className="absolute right-2 top-2 rounded-full p-1 text-slate-500 hover:text-slate-200">
                <X className="h-3.5 w-3.5" />
              </button>
              <span className="inline-flex items-center gap-1.5 font-bold text-[#e8c97a]">
                <Gamepad2 className="h-3.5 w-3.5" /> Comment jouer
              </span>
              <br />
              <b>ZQSD / WASD / flèches</b> pour explorer · <b>Maj</b> pour sprinter · les <b className="text-emerald-300">herbes hautes</b> déclenchent des
              rencontres · les <b className="text-[#e8c97a]">autels dorés</b> abritent les Gardiens · le <b className="text-teal-300">cristal central</b> soigne
              ton équipe.
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Carte de proximite (autel) */}
      <AnimatePresence>
        {zone && (
          <motion.div
            key={zone.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-24 left-1/2 z-20 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 md:bottom-28"
          >
            <div className="overflow-hidden rounded-2xl border border-white/15 bg-black/70 backdrop-blur-md">
              <div className="border-b border-white/10 px-4 py-2.5" style={{ background: `linear-gradient(90deg, ${zone.hue}22, transparent)` }}>
                <p className="text-xs font-bold uppercase tracking-[0.25em]" style={{ color: zone.hue }}>
                  Autel — {zone.name}
                </p>
              </div>
              <div className="flex items-center justify-between gap-3 px-4 py-3">
                {zoneBeaten ? (
                  <p className="flex items-center gap-2 text-sm text-[#e8c97a]">
                    <Medal className="h-4 w-4" /> {zone.boss.badge} déjà obtenu.
                  </p>
                ) : zoneLocked ? (
                  <p className="text-sm text-slate-400">
                    Un sceau protège cet autel. Il faut <b className="text-slate-200">{zone.minBadges} emblème{zone.minBadges > 1 ? "s" : ""}</b>.
                  </p>
                ) : (
                  <>
                    <p className="text-sm text-slate-300">
                      <b className="text-slate-100">{zone.boss.name}</b>, {zone.boss.title}, t'attend.
                      <span className="block text-xs text-slate-500">
                        {zone.boss.team.length} créatures · {zone.boss.reward} éclats
                      </span>
                    </p>
                    <button
                      onClick={() => startBoss(zone.id)}
                      className="inline-flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold uppercase tracking-widest text-[#14100a] transition hover:brightness-110"
                      style={{ background: `linear-gradient(135deg, ${zone.hue}, ${zone.hue}99)` }}
                    >
                      <Swords className="h-4 w-4" /> Défier
                    </button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Joystick tactile */}
      <Joystick controlsRef={controlsRef} />

      {/* Boutons panneaux (droite) */}
      <div className="absolute right-4 top-1/2 z-20 flex -translate-y-1/2 flex-col gap-2">
        {DRAWERS.map((d) => (
          <button
            key={d.id}
            onClick={() => setDrawer(drawer === d.id ? null : d.id)}
            className={`rounded-2xl border p-3 transition ${
              drawer === d.id
                ? "border-[#e8c97a]/50 bg-[#e8c97a]/15 text-[#e8c97a]"
                : "border-white/10 bg-black/50 text-slate-300 backdrop-blur-md hover:bg-black/70"
            }`}
            title={d.label}
          >
            <d.icon className="h-5 w-5" />
          </button>
        ))}
      </div>

      {/* Tiroir lateral */}
      <AnimatePresence>
        {drawer && (
          <motion.aside
            key={drawer}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 40 }}
            className="absolute bottom-4 right-16 top-20 z-30 w-[min(92vw,30rem)] overflow-y-auto rounded-2xl border border-white/10 bg-[#0b0b1e]/95 p-4 shadow-2xl backdrop-blur-xl md:right-20"
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-slate-50">
                {drawer === "equipe" ? "Ton Équipe" : drawer === "reserve" ? "La Réserve" : "Boutique d'Éther"}
              </h2>
              <button onClick={() => setDrawer(null)} className="rounded-full p-1.5 text-slate-400 hover:bg-white/10 hover:text-slate-100">
                <X className="h-4 w-4" />
              </button>
            </div>
            {drawer === "equipe" && <TeamPanel />}
            {drawer === "reserve" && <BoxPanel />}
            {drawer === "boutique" && <ShopPanel />}
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Legende rencontres */}
      <div className="pointer-events-none absolute bottom-4 left-1/2 z-10 -translate-x-1/2">
        <p className="hud-plate flex items-center gap-2 rounded-full px-4 py-2 text-[9px] font-black uppercase tracking-[0.22em] text-slate-400">
          <Sparkles className="h-3 w-3 text-[#e8c97a]" /> Marche dans les anneaux d'herbes hautes
        </p>
      </div>
    </div>
  );
}

/* ------------------------------ Joystick -------------------------------- */

function Joystick({ controlsRef }: { controlsRef: React.MutableRefObject<WorldControls> }) {
  const base = useRef<HTMLDivElement>(null);
  const [stick, setStick] = useState({ x: 0, y: 0, active: false });
  const pointerId = useRef<number | null>(null);

  const update = (clientX: number, clientY: number) => {
    const el = base.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = clientX - cx;
    const dy = clientY - cy;
    const max = rect.width / 2;
    const len = Math.hypot(dx, dy);
    const clamped = Math.min(len, max);
    const nx = len > 0 ? dx / len : 0;
    const ny = len > 0 ? dy / len : 0;
    setStick({ x: nx * clamped, y: ny * clamped, active: true });
    const c = controlsRef.current;
    // ecran : +x droite, +z bas
    c.x = nx * (clamped / max);
    c.z = ny * (clamped / max);
  };

  const release = () => {
    pointerId.current = null;
    setStick({ x: 0, y: 0, active: false });
    const c = controlsRef.current;
    c.x = 0;
    c.z = 0;
  };

  return (
    <div
      ref={base}
      onPointerDown={(e) => {
        pointerId.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (pointerId.current === e.pointerId) update(e.clientX, e.clientY);
      }}
      onPointerUp={release}
      onPointerCancel={release}
      className={`absolute bottom-8 left-4 z-20 h-28 w-28 touch-none rounded-full border backdrop-blur-sm transition-opacity md:left-8 ${
        stick.active ? "border-[#e8c97a]/40 bg-white/10" : "border-white/15 bg-black/30 opacity-60"
      }`}
    >
      <div
        className="absolute left-1/2 top-1/2 h-12 w-12 rounded-full border border-[#e8c97a]/50 bg-gradient-to-br from-[#f6dd9b] to-[#d9a94e] shadow-lg"
        style={{ transform: `translate(calc(-50% + ${stick.x}px), calc(-50% + ${stick.y}px))` }}
      />
    </div>
  );
}
