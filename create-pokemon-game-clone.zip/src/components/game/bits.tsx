"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import {
  CircleDot,
  Droplets,
  Flame,
  Ghost,
  Leaf,
  Mountain,
  Snowflake,
  Sparkles,
  Wind,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { TYPE_COLOR, TYPE_LABEL } from "@/lib/game/data/chart";
import { getSpecies } from "@/lib/game/data/species";
import { maxHpOf, xpNeeded } from "@/lib/game/engine";
import type { OwnedCreature, TypeName } from "@/lib/game/types";

export const TYPE_ICON: Record<TypeName, LucideIcon> = {
  feu: Flame,
  eau: Droplets,
  plante: Leaf,
  foudre: Zap,
  glace: Snowflake,
  roche: Mountain,
  spectre: Ghost,
  aerien: Wind,
  dragon: Sparkles,
  normal: CircleDot,
};

export function TypeChip({ type, size = "sm" }: { type: TypeName; size?: "sm" | "md" }) {
  const Icon = TYPE_ICON[type];
  const c = TYPE_COLOR[type];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-semibold uppercase tracking-widest ${
        size === "sm" ? "px-2.5 py-0.5 text-[10px]" : "px-3 py-1 text-xs"
      }`}
      style={{ color: c, borderColor: `${c}55`, background: `${c}14` }}
    >
      <Icon className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} strokeWidth={2.4} />
      {TYPE_LABEL[type]}
    </span>
  );
}

export function CreaturePortrait({
  speciesId,
  size = 128,
  ring = true,
  glow = true,
  shape = "circle",
}: {
  speciesId: string;
  size?: number;
  ring?: boolean;
  glow?: boolean;
  shape?: "circle" | "card";
}) {
  const sp = getSpecies(speciesId);
  const c = TYPE_COLOR[sp.type];
  const style: React.CSSProperties = {
    width: size,
    height: size,
    border: ring ? `2px solid ${c}88` : "none",
    boxShadow: glow ? `0 0 ${size / 3}px ${c}55, inset 0 0 ${size / 5}px rgba(0,0,0,.6)` : undefined,
  };
  if (!sp.image) {
    // Sceau procedurale pour les especes sans portrait 2D
    const Icon = TYPE_ICON[sp.type];
    return (
      <div
        className="relative flex shrink-0 items-center justify-center overflow-hidden rounded-full"
        style={{ ...style, background: `radial-gradient(circle at 35% 30%, ${c}66, #0c0c22 75%)` }}
      >
        <Icon className="absolute opacity-25" style={{ width: size * 0.72, height: size * 0.72, color: c }} strokeWidth={1} />
        <span className="font-display relative font-bold" style={{ color: "#fff", fontSize: size * 0.34, textShadow: `0 0 ${size / 6}px ${c}` }}>
          {sp.name.slice(0, 1)}
        </span>
      </div>
    );
  }
  return (
    <div className={`relative shrink-0 overflow-hidden ${shape === "circle" ? "rounded-full" : "rounded-[1.15rem]"}`} style={style}>
      <Image src={sp.image} alt={sp.name} fill sizes={`${size}px`} className="object-cover" />
    </div>
  );
}

export function HpBar({ hp, max, height = 10 }: { hp: number; max: number; height?: number }) {
  const pct = Math.max(0, Math.min(100, (hp / Math.max(1, max)) * 100));
  const color = pct > 50 ? "#5fd98a" : pct > 20 ? "#ffd23f" : "#ff5f6d";
  return (
    <div className="w-full overflow-hidden rounded-full bg-black/50 ring-1 ring-white/10" style={{ height }}>
      <motion.div
        className="h-full rounded-full"
        initial={false}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        style={{ background: `linear-gradient(90deg, ${color}, ${color}bb)`, boxShadow: `0 0 12px ${color}66` }}
      />
    </div>
  );
}

export function XpBar({ c }: { c: OwnedCreature }) {
  const pct = Math.max(0, Math.min(100, (c.xp / xpNeeded(c.level)) * 100));
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/50 ring-1 ring-white/10">
      <motion.div
        className="h-full rounded-full bg-sky-300"
        initial={false}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.5 }}
        style={{ boxShadow: "0 0 8px #7dd3fc88" }}
      />
    </div>
  );
}

export function creatureSummary(c: OwnedCreature) {
  const sp = getSpecies(c.speciesId);
  const max = maxHpOf(c);
  return { sp, max, pct: (c.hp / max) * 100 };
}

export function StatusBadge({ status }: { status: OwnedCreature["status"] }) {
  if (!status) return null;
  const isBurn = status === "brulure";
  return (
    <span
      className="inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white"
      style={{ background: isBurn ? "#ff5f3d88" : "#c9a80088" }}
    >
      {isBurn ? "Brûlure" : "Paralysie"}
    </span>
  );
}
