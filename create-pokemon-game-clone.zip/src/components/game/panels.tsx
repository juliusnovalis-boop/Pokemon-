"use client";

import { Archive, ArrowDownToLine, ArrowUpFromLine, Coins } from "lucide-react";
import { useGame } from "@/lib/game/store";
import { getSpecies } from "@/lib/game/data/species";
import { ITEMS, statsFor } from "@/lib/game/engine";
import type { ItemId } from "@/lib/game/types";
import { CreaturePortrait, HpBar, StatusBadge, TypeChip, XpBar } from "./bits";

export function TeamPanel() {
  const { state, deposit } = useGame();
  if (!state) return null;
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {state.team.map((c) => {
        const sp = getSpecies(c.speciesId);
        const max = statsFor(sp, c.level).hp;
        return (
          <div key={c.uid} className="ui-region-card rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <CreaturePortrait speciesId={c.speciesId} size={60} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-display truncate text-base font-bold text-slate-50">{sp.name}</h4>
                  <span className="text-xs font-bold text-slate-300">Niv. {c.level}</span>
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <TypeChip type={sp.type} />
                  <StatusBadge status={c.status} />
                </div>
              </div>
            </div>
            <div className="mt-3 space-y-1.5">
              <div className="flex items-center gap-2">
                <HpBar hp={c.hp} max={max} height={8} />
                <span className="w-14 text-right text-[10px] tabular-nums text-slate-400">
                  {c.hp}/{max}
                </span>
              </div>
              <XpBar c={c} />
            </div>
            <button
              onClick={() => deposit(c.uid)}
              className="ui-button-dark mt-3 inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-300"
            >
              <ArrowDownToLine className="h-3.5 w-3.5" /> Réserve
            </button>
          </div>
        );
      })}
    </div>
  );
}

export function BoxPanel() {
  const { state, withdraw } = useGame();
  if (!state) return null;
  if (state.box.length === 0) {
    return (
      <div className="flex h-40 flex-col items-center justify-center rounded-2xl border border-dashed border-white/15 text-slate-500">
        <Archive className="mb-2 h-6 w-6" />
        <p className="text-sm">La Réserve est vide. Marche dans les herbes hautes pour capturer !</p>
      </div>
    );
  }
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {state.box.map((c) => {
        const sp = getSpecies(c.speciesId);
        return (
          <div key={c.uid} className="ui-region-card rounded-2xl p-4 text-center">
            <div className="mx-auto w-fit">
              <CreaturePortrait speciesId={c.speciesId} size={56} />
            </div>
            <h4 className="font-display mt-2 text-sm font-bold text-slate-100">{sp.name}</h4>
            <p className="text-xs text-slate-400">Niv. {c.level}</p>
            <div className="mt-2 flex justify-center">
              <TypeChip type={sp.type} />
            </div>
            <button
              onClick={() => withdraw(c.uid)}
              className="ui-button-dark mt-3 inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-300"
            >
              <ArrowUpFromLine className="h-3.5 w-3.5" /> Reprendre
            </button>
          </div>
        );
      })}
    </div>
  );
}

export function ShopPanel() {
  const { state, buy } = useGame();
  if (!state) return null;
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {(Object.keys(ITEMS) as ItemId[]).map((id) => {
        const item = ITEMS[id];
        const owned = state.items[id] ?? 0;
        const afford = state.eclats >= item.price;
        return (
          <div key={id} className="ui-region-card flex flex-col rounded-2xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-display text-base font-bold text-slate-50">{item.name}</h4>
                <p className="mt-1 text-xs text-slate-400">{item.desc}</p>
              </div>
              <span className="rounded-full bg-white/10 px-2 py-0.5 text-[11px] font-bold text-slate-300">×{owned}</span>
            </div>
            <button
              onClick={() => buy(id)}
              disabled={!afford}
              className={`mt-3 inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition ${
                        afford ? "ui-button-primary" : "cursor-not-allowed border border-white/10 bg-white/5 text-slate-500"
                      }`}
            >
              <Coins className="h-4 w-4" /> {item.price} éclats
            </button>
          </div>
        );
      })}
    </div>
  );
}
