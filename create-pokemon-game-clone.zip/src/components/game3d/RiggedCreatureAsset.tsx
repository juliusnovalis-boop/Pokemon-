"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { clone as skeletonClone } from "three/examples/jsm/utils/SkeletonUtils.js";
import { getSpecies } from "@/lib/game/data/species";

/**
 * Association entre les especes de Valdoria et les modeles CC0 rigges.
 * Les fichiers viennent de Quaternius Ultimate Monsters / Animated Animals
 * et de Gobkit Free Animal Pack (voir public/models/licenses/SOURCES.txt).
 */
export const CREATURE_ASSET: Record<string, string> = {
  // Especes historiques
  pyrrax: "gob_Corgi",
  hydriss: "gob_Platypus",
  feuillou: "mount_deer",
  rocarok: "mob_goleling",
  zephyrelle: "mob_birb",
  sombraile: "mob_ghost",
  glacibou: "mob_birb_blob",
  foudrix: "mob_bunny",
  drakonyx: "mob_dragon_fly",

  // Afikala
  flambaobab: "mob_cactoro_blob",
  cameleonio: "mob_frog",
  hippotide: "gob_Hippo",
  soleonix: "boss1",
  zebrolt: "mount_donkey",

  // Ameritopia
  coyotflamme: "gob_Corgi",
  racovert: "mob_yeti_blob",
  castoreau: "gob_Platypus",
  thundereagal: "mount_pegasus",
  bisonbron: "gob_Rhino",

  // Ashikawa
  tanukiflam: "mob_cat_blob",
  pandaboo: "mob_yeti",
  koiryu: "mob_fish_blob",
  shinryujin: "boss10",
  tsurumi: "gob_Duck",

  // Euroterra
  dragonnet: "mob_dino",
  faeloup: "mount_deer",
  phoquevalier: "gob_Platypus",
  arthurion: "boss8",
  brumelin: "mob_ghost_skull",
};

const GOBKIT = new Set([
  "gob_Duck",
  "gob_Shark",
  "gob_Bat",
  "gob_Rhino",
  "gob_Anglerfish",
  "gob_Red",
  "gob_Corgi",
  "gob_Hippo",
  "gob_Jellyfish",
  "gob_Platypus",
]);

const urlFor = (name: string) => `/models/creatures/${name}.glb`;

export function hasRiggedAsset(speciesId: string): boolean {
  return !!CREATURE_ASSET[speciesId];
}

export default function RiggedCreatureAsset({ speciesId }: { speciesId: string }) {
  const assetName = CREATURE_ASSET[speciesId];
  const { scene, animations } = useGLTF(urlFor(assetName));
  const model = useMemo(() => skeletonClone(scene), [scene]);
  const species = getSpecies(speciesId);

  const bounds = useMemo(() => {
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const targetHeight = species.rarity === "legendaire" ? 2.15 : species.template === "bird" ? 1.55 : 1.65;
    const factor = targetHeight / Math.max(0.01, size.y);
    return {
      factor,
      offset: new THREE.Vector3(-center.x, -box.min.y, -center.z),
    };
  }, [model, species.rarity, species.template]);

  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  if (!mixerRef.current) mixerRef.current = new THREE.AnimationMixer(model);
  const mixer = mixerRef.current;

  useEffect(() => {
    model.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((material) => {
            if ("roughness" in material) {
              const m = material as THREE.MeshStandardMaterial;
              m.roughness = Math.min(m.roughness ?? 0.65, 0.72);
            }
            material.needsUpdate = true;
          });
        } else if (mesh.material && "roughness" in mesh.material) {
          const m = mesh.material as THREE.MeshStandardMaterial;
          m.roughness = Math.min(m.roughness ?? 0.65, 0.72);
          m.needsUpdate = true;
        }
      }
    });

    if (!animations.length) return;
    const namedIdle = animations.find((clip) => /idle/i.test(clip.name));
    let clip = namedIdle ?? animations[0];

    // Les anciens GLB Gobkit contiennent idle/attaque/mort/marche dans une
    // seule piste de 120 images. On isole les 30 premieres images (idle).
    if (GOBKIT.has(assetName) && clip.duration > 1.3) {
      clip = THREE.AnimationUtils.subclip(clip, `${assetName}-${speciesId}-idle`, 0, 29, 24);
    }

    const action = mixer.clipAction(clip);
    action.reset().setLoop(THREE.LoopRepeat, Infinity).fadeIn(0.2).play();
    return () => {
      action.fadeOut(0.1);
      mixer.stopAllAction();
    };
  }, [animations, assetName, mixer, model, speciesId]);

  useFrame((_, delta) => mixer.update(Math.min(delta, 0.05)));

  return (
    <group scale={bounds.factor}>
      <primitive object={model} position={bounds.offset} />
    </group>
  );
}

// Aucun prechargement global : les 47 GLB de creatures doivent rester a la
// demande, sinon le navigateur decode des dizaines de squelettes au lancement
// du monde et le budget WebGL explose.
