"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Sparkles, Stars } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import type { BattleState } from "@/lib/game/types";
import { getSpecies } from "@/lib/game/data/species";
import { TYPE_COLOR } from "@/lib/game/data/chart";
import CreatureModel from "./CreatureModel";
import { BattleArchitecture } from "./ArchitectureAssets";

const PLAYER_POS: [number, number, number] = [-2.4, 0, 1.7];
const ENEMY_POS: [number, number, number] = [2.6, 0, -1.6];

interface BattleSceneProps {
  battle: BattleState;
  playerSpeciesId: string;
  playerFainted: boolean;
}

/* ------------------------------ Orbe capture ------------------------------ */

function CatchOrb({ nonce, success }: { nonce: number; success: boolean }) {
  const orb = useRef<THREE.Group>(null);
  const start = useRef(-1);
  const [visible, setVisible] = useState(false);
  const dur = 1.9;

  useEffect(() => {
    if (nonce > 0) {
      start.current = -1;
      setVisible(true);
    }
  }, [nonce]);

  useFrame(({ clock }) => {
    const o = orb.current;
    if (!o || !visible) return;
    if (start.current < 0) start.current = clock.elapsedTime;
    const p = Math.min(1, (clock.elapsedTime - start.current) / dur);
    const from = new THREE.Vector3(PLAYER_POS[0], 0.8, PLAYER_POS[1] ? PLAYER_POS[2] : 0);
    const to = new THREE.Vector3(ENEMY_POS[0], 0.9, ENEMY_POS[2]);
    if (p < 0.35) {
      // arc de lancer
      const q = p / 0.35;
      const m = from.clone().lerp(to, q);
      m.y += Math.sin(q * Math.PI) * 2.6;
      o.position.copy(m);
    } else {
      // secousses de l'orbe
      const q = (p - 0.35) / 0.65;
      const wobble = success ? Math.sin(q * Math.PI * 4) * (0.35 - q * 0.25) : Math.sin(q * Math.PI * 2.5) * 0.18;
      o.position.set(to.x + wobble * 0.4, to.y - q * 0.6, to.z);
      o.rotation.z = wobble * 2;
    }
    if (p >= 1) setVisible(false);
  });

  if (!visible) return null;
  return (
    <group ref={orb}>
      <mesh castShadow>
        <sphereGeometry args={[0.28, 16, 16]} />
        <meshStandardMaterial color="#7fe8d5" emissive="#4ed8c2" emissiveIntensity={2.2} roughness={0.2} metalness={0.5} />
      </mesh>
      <mesh>
        <torusGeometry args={[0.29, 0.03, 8, 24]} />
        <meshStandardMaterial color="#e8c97a" emissive="#d9a94e" emissiveIntensity={1.4} metalness={0.7} roughness={0.25} />
      </mesh>
      <pointLight color="#7fe8d5" intensity={14} distance={8} decay={2} />
    </group>
  );
}

/* ------------------------------- Arenas ---------------------------------- */

function Arena({ tint, kind }: { tint: string; kind: BattleState["kind"] }) {
  const runes = useRef<THREE.Group>(null);
  useFrame(({ clock }, delta) => {
    if (runes.current) runes.current.rotation.y += delta * 0.12;
  });
  const void1 = clockSafe();
  return (
    <group>
      {/* sol sombre */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.02, 0]}>
        <circleGeometry args={[46, 48]} />
        <meshStandardMaterial color="#0c0f1e" roughness={0.9} />
      </mesh>
      {/* estrade */}
      <mesh receiveShadow position={[0, -0.25, 0]}>
        <cylinderGeometry args={[8.2, 9, 0.5, 48]} />
        <meshStandardMaterial color="#232842" roughness={0.65} metalness={0.25} />
      </mesh>
      {/* anneau de runes */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, 0]}>
        <ringGeometry args={[7.4, 8, 64]} />
        <meshBasicMaterial color={tint} transparent opacity={0.85} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.011, 0]}>
        <ringGeometry args={[4.6, 4.75, 48]} />
        <meshBasicMaterial color={tint} transparent opacity={0.35} />
      </mesh>
      {/* runes orbitales */}
      <group ref={runes} position={[0, 0.4, 0]}>
        {Array.from({ length: 8 }).map((_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return (
            <mesh key={i} position={[Math.cos(a) * 8.6, 0.15 + (i % 2) * 0.22, Math.sin(a) * 8.6]} rotation={[0, a, 0.2]}>
              <boxGeometry args={[0.16, 0.5, 0.05]} />
              <meshStandardMaterial color={tint} emissive={tint} emissiveIntensity={1.4} transparent opacity={0.9} />
            </mesh>
          );
        })}
      </group>
      {kind === "boss" && (
        <Float speed={2} floatIntensity={0.7} rotationIntensity={0.3}>
          <mesh position={[0, 6.4, -6]} rotation={[0, void1, 0]}>
            <octahedronGeometry args={[0.8]} />
            <meshStandardMaterial color="#b388ff" emissive="#8a5cff" emissiveIntensity={2} roughness={0.2} />
          </mesh>
        </Float>
      )}
      <Sparkles count={90} scale={22} size={2.6} speed={0.45} color={tint} position={[0, 3, 0]} />
    </group>
  );
}

function clockSafe() {
  return Math.PI / 6;
}

/* --------------------------------- Scene ---------------------------------- */

export default function BattleScene({ battle, playerSpeciesId, playerFainted }: BattleSceneProps) {
  const enemy = battle.enemyTeam[battle.enemyIndex];
  const tint = TYPE_COLOR[getSpecies(enemy?.speciesId ?? "pyrrax").type];

  // nonces d'animation derives du dernier coup
  const [playerAtk, setPlayerAtk] = useState(0);
  const [enemyAtk, setEnemyAtk] = useState(0);
  const [playerHit, setPlayerHit] = useState(0);
  const [enemyHit, setEnemyHit] = useState(0);
  const lastKey = useRef(0);

  useEffect(() => {
    const hit = battle.lastHit;
    if (!hit || hit.key === lastKey.current) return;
    lastKey.current = hit.key;
    if (hit.side === "enemy") {
      setPlayerAtk((n) => n + 1);
      setEnemyHit((n) => n + 1);
    } else {
      setEnemyAtk((n) => n + 1);
      setPlayerHit((n) => n + 1);
    }
  }, [battle.lastHit]);

  const enemyFaint = enemy?.hp <= 0 && battle.over !== null;

  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [0, 3.6, 8.4], fov: 42, near: 0.5, far: 120 }}
      gl={{ antialias: true }}
      style={{ background: "#07071a" }}
    >
      <fog attach="fog" args={["#0a0d20", 18, 70]} />
      <Stars radius={80} depth={20} count={1400} factor={3} fade speed={0.8} />

      <ambientLight intensity={0.4} color="#9fb0e8" />
      {/* projecteur principal */}
      <directionalLight castShadow position={[6, 10, 4]} intensity={1.4} color="#fff4d6" shadow-mapSize={[1024, 1024]} />
      {/* rebonds colores par camp */}
      <pointLight position={[ENEMY_POS[0], 4, ENEMY_POS[2]]} color={tint} intensity={26} distance={16} decay={2} />
      <pointLight position={[PLAYER_POS[0], 4, PLAYER_POS[2]]} color="#e8c97a" intensity={16} distance={14} decay={2} />
      <hemisphereLight args={["#413a6e", "#0a0e1c", 0.4]} />

      <Arena tint={tint} kind={battle.kind} />
      <BattleArchitecture tint={tint} boss={battle.kind === "boss"} />

      {/* creatures face a face */}
      <CreatureModel
        key={`p-${playerSpeciesId}-${playerFainted ? "ko" : "ok"}`}
        speciesId={playerSpeciesId}
        position={PLAYER_POS}
        rotationY={Math.PI * 0.32}
        scale={1.15}
        attackNonce={playerAtk}
        hitNonce={playerHit}
        faint={playerFainted}
      />
      {enemy && (
        <CreatureModel
          key={`e-${enemy.uid}`}
          speciesId={enemy.speciesId}
          position={ENEMY_POS}
          rotationY={-Math.PI * 0.68}
          scale={1.15}
          attackNonce={enemyAtk}
          hitNonce={enemyHit}
          faint={enemyFaint}
        />
      )}

      {battle.catchAnim ? <CatchOrb nonce={battle.catchAnim} success={battle.over === "caught"} /> : null}

      {/* camera sway leger */}
      <CameraSway />

      <EffectComposer>
        <Bloom luminanceThreshold={0.45} intensity={0.85} mipmapBlur radius={0.7} />
      </EffectComposer>
    </Canvas>
  );
}

function CameraSway() {
  useFrame(({ camera, clock }) => {
    const t = clock.elapsedTime;
    camera.position.x = Math.sin(t * 0.35) * 0.5;
    camera.position.y = 3.6 + Math.sin(t * 0.5) * 0.15;
    camera.lookAt(0.2, 1.1, 0);
  });
  return null;
}
