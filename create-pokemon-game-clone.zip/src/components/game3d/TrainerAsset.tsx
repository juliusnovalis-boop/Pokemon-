"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { clone as skeletonClone } from "three/examples/jsm/utils/SkeletonUtils.js";

const URL = "/models/characters/trainer.glb";

type Locomotion = "idle" | "walk" | "run";

export default function TrainerAsset({ speedRef }: { speedRef: React.MutableRefObject<number> }) {
  const { scene, animations } = useGLTF(URL);
  const model = useMemo(() => skeletonClone(scene), [scene]);
  const mixer = useMemo(() => new THREE.AnimationMixer(model), [model]);
  const current = useRef<Locomotion>("idle");

  const fit = useMemo(() => {
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    return {
      scale: 1.75 / Math.max(0.01, size.y),
      offset: new THREE.Vector3(-center.x, -box.min.y, -center.z),
    };
  }, [model]);

  const actions = useMemo(() => {
    const find = (name: string) => animations.find((clip) => clip.name === name);
    return {
      idle: find("Idle") ? mixer.clipAction(find("Idle")!) : null,
      walk: find("Walking_A") ? mixer.clipAction(find("Walking_A")!) : null,
      run: find("Running_A") ? mixer.clipAction(find("Running_A")!) : null,
    };
  }, [animations, mixer]);

  useEffect(() => {
    model.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        // Le pack contient toutes les armes possibles. Le dresseur explore
        // sans armes visibles : elles restent dans le GLB pour les animations.
        if (/knife|crossbow|throwable/i.test(mesh.name)) mesh.visible = false;
      }
    });
    actions.idle?.reset().fadeIn(0.15).play();
    return () => {
      mixer.stopAllAction();
    };
  }, [actions, mixer, model]);

  useFrame((_, delta) => {
    const speed = speedRef.current;
    const next: Locomotion = speed < 0.6 ? "idle" : speed > 14 ? "run" : "walk";
    if (next !== current.current) {
      const prevAction = actions[current.current];
      const nextAction = actions[next];
      prevAction?.fadeOut(0.18);
      nextAction?.reset().fadeIn(0.18).play();
      current.current = next;
    }
    mixer.update(Math.min(delta, 0.05));
  });

  return (
    <group scale={fit.scale}>
      <primitive object={model} position={fit.offset} />
    </group>
  );
}

// Le prechargement du personnage est evite : le GLB de 3,5 Mo est charge
// uniquement quand le monde s'affiche, avec repli capsule pendant Suspense.

