"use client";

import React, { Suspense, useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Float, Sky, Sparkles, Stars, useGLTF } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { ISLAND_RADIUS, SANCTUARY_POS, mulberry32, scatter, type AreaLayout, type PropPlacement } from "@/lib/game/data/worldLayout";
import { zoneUnlocked } from "@/lib/game/data/regions";
import type { Zone } from "@/lib/game/types";
import CreatureModel from "./CreatureModel";
import { ZoneArena, ZoneSettlement } from "./ArchitectureAssets";
import TrainerAsset from "./TrainerAsset";

export interface WorldControls {
  x: number; // -1..1 lateral
  z: number; // -1..1 avant/arriere
  sprint: boolean;
}

interface WorldSceneProps {
  controlsRef: React.MutableRefObject<WorldControls>;
  badges: string[];
  champion: boolean;
  areas: AreaLayout[];
  zones: Zone[];
  onEncounter: (zoneId: string) => void;
  onProximity: (zoneId: string | null) => void;
  onSanctuary: () => void;
}

/* ------------------------- Chargement assets CC0 ------------------------- */
/* Pack "Nature Kit" (Kenney, licence CC0 - domaine public) importe en GLB.  */

const KIT_URL = (name: string) => `/models/kit/${name}.glb`;

function KitProp({
  name,
  position,
  rotationY = 0,
  scale = 1,
  castShadow = true,
}: {
  name: string;
  position: [number, number, number];
  rotationY?: number;
  scale?: number | [number, number, number];
  castShadow?: boolean;
}) {
  const { scene } = useGLTF(KIT_URL(name));
  const cloned = useMemo(() => {
    const s = scene.clone(true);
    s.traverse((o) => {
      const m = o as THREE.Mesh;
      if ((m as THREE.Mesh).isMesh) {
        m.castShadow = castShadow;
        m.receiveShadow = true;
      }
    });
    return s;
  }, [scene, castShadow]);
  return <primitive object={cloned} position={position} rotation={[0, rotationY, 0]} scale={scale} />;
}

/** Disperse un modele du kit sur le secteur. */
function KitScatter({ area, name, list, base = 1 }: { area: AreaLayout; name: string; list: PropPlacement[]; base?: number }) {
  return (
    <group>
      {list.map((t, i) => (
        <KitProp key={`${name}-${i}`} name={name} position={[t.pos[0], 0, t.pos[1]]} rotationY={t.rot} scale={t.scale * base} />
      ))}
    </group>
  );
}

/* ------------------------------- Biomes ---------------------------------- */

function BiomeProps({ area }: { area: AreaLayout }) {
  const trees = useMemo(() => scatter(area, 14, 24, 7), [area]);
  const deco = useMemo(() => scatter(area, 12, 20, 21), [area]);
  const deco2 = useMemo(() => scatter(area, 8, 26, 33), [area]);

  switch (area.propKind) {
    case "arbres":
      return (
        <group>
          <KitScatter area={area} name="tree_default" list={trees} base={1.25} />
          <KitScatter area={area} name="tree_detailed" list={deco2} base={1.35} />
          <KitScatter area={area} name="plant_bushTriangle" list={deco} base={1.1} />
        </group>
      );
    case "champignons":
      return (
        <group>
          <KitScatter area={area} name="tree_blocks_dark" list={trees} base={1.3} />
          <KitScatter area={area} name="mushroom_tanGroup" list={deco} base={1.2} />
          <KitScatter area={area} name="stump_old" list={deco2.slice(0, 4)} base={1.1} />
          {/* lucioles */}
          <Sparkles count={40} scale={26} size={2.4} speed={0.5} color={area.accent} position={[area.center[0], 2, area.center[1]]} />
        </group>
      );
    case "cristaux": {
      return (
        <group>
          <KitScatter area={area} name="tree_pineRoundA" list={trees} base={1.4} />
          <KitScatter area={area} name="stone_smallI" list={deco2} base={1.2} />
          {/* cristaux proceduraux emissifs (brillent sous le bloom) */}
          {deco.map((t, i) => (
            <mesh key={i} castShadow position={[t.pos[0], 0.7 * t.scale, t.pos[1]]} rotation={[t.rot * 0.3, t.rot, 0]} scale={[t.scale * 0.5, t.scale * 1.6, t.scale * 0.5]}>
              <octahedronGeometry args={[0.8]} />
              <meshStandardMaterial color={area.foliage} emissive={area.accent} emissiveIntensity={1} transparent opacity={0.92} roughness={0.15} />
            </mesh>
          ))}
        </group>
      );
    }
    case "rochers":
      return (
        <group>
          <KitScatter area={area} name="rock_tallD" list={trees} base={1.35} />
          <KitScatter area={area} name="rock_smallF" list={deco} base={1.1} />
          <KitScatter area={area} name="cliff_half_stone" list={deco2.slice(0, 3)} base={1.6} />
        </group>
      );
    case "cactus":
      return (
        <group>
          <KitScatter area={area} name="cactus_tall" list={trees} base={1.15} />
          <KitScatter area={area} name="cactus_short" list={deco} base={1.1} />
          <KitScatter area={area} name="tree_palmTall" list={deco2.slice(0, 4)} base={1.3} />
          <KitScatter area={area} name="rock_tallD" list={deco2.slice(4, 7)} base={1.2} />
        </group>
      );
    case "runes":
      return (
        <group>
          <KitScatter area={area} name="statue_column" list={trees.slice(0, 8)} base={0.9} />
          <KitScatter area={area} name="statue_head" list={deco.slice(0, 5)} base={0.9} />
          <KitScatter area={area} name="statue_block" list={deco2.slice(0, 3)} base={0.85} />
          <KitScatter area={area} name="tree_plateau_dark" list={deco2.slice(3)} base={1.2} />
        </group>
      );
  }
}

/** Herbes hautes : zone de rencontres. */
function GrassPatch({ area }: { area: AreaLayout }) {
  const blades = useMemo(() => {
    const rnd = mulberry32(99);
    const out: { pos: [number, number]; rot: number; s: number }[] = [];
    for (let i = 0; i < 220; i++) {
      const ang = rnd() * Math.PI * 2;
      const dist = Math.sqrt(rnd()) * (area.patchRadius - 1);
      out.push({
        pos: [area.center[0] + Math.cos(ang) * dist, area.center[1] + Math.sin(ang) * dist],
        rot: rnd() * Math.PI,
        s: 0.7 + rnd() * 0.7,
      });
    }
    return out;
  }, [area]);
  const bushes = useMemo(() => scatter(area, 12, area.patchRadius + 2, 55), [area]);
  const g = useRef<THREE.InstancedMesh>(null);

  useEffect(() => {
    const mesh = g.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const eul = new THREE.Euler();
    const v = new THREE.Vector3();
    blades.forEach((b, i) => {
      eul.set(0.12, b.rot, (i % 2 ? 1 : -1) * 0.12);
      q.setFromEuler(eul);
      m.compose(v.set(b.pos[0], 0.36 * b.s, b.pos[1]), q, new THREE.Vector3(b.s, b.s, b.s));
      mesh.setMatrixAt(i, m);
    });
    mesh.instanceMatrix.needsUpdate = true;
  }, [blades]);

  return (
    <group>
      <instancedMesh ref={g} args={[undefined, undefined, blades.length]} key={blades.length}>
        <coneGeometry args={[0.1, 0.75, 4]} />
        <meshStandardMaterial color={area.foliage} roughness={0.85} />
      </instancedMesh>
      <KitScatter area={area} name="plant_bushTriangle" list={bushes} base={1.15} />
      {/* anneau indicatif */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[area.center[0], 0.03, area.center[1]]}>
        <ringGeometry args={[area.patchRadius - 0.5, area.patchRadius, 48]} />
        <meshBasicMaterial color={area.accent} transparent opacity={0.35} />
      </mesh>
    </group>
  );
}

/** Autel du Gardien : statues + gemme flottante. */
function Altar({ area, beaten, locked }: { area: AreaLayout; beaten: boolean; locked: boolean }) {
  const [x, z] = area.altar;
  return (
    <group position={[x, 0, z]}>
      <Suspense fallback={null}>
        <KitProp name="statue_obelisk" position={[0, 0, 0]} scale={1.1} />
        <KitProp name="statue_column" position={[-2.4, 0, 1.2]} scale={0.7} />
        <KitProp name="statue_column" position={[2.4, 0, 1.2]} scale={0.7} />
        <KitProp name="path_stoneCircle" position={[0, 0.01, 1.6]} scale={1.4} castShadow={false} />
      </Suspense>
      <Float speed={2.4} rotationIntensity={0.6} floatIntensity={1.2}>
        <mesh castShadow position={[0, 3.4, 0]}>
          <octahedronGeometry args={[0.6]} />
          <meshStandardMaterial
            color={locked ? "#555" : area.accent}
            emissive={locked ? "#222" : area.accent}
            emissiveIntensity={beaten ? 2.4 : locked ? 0.2 : 1.2}
            metalness={0.4}
            roughness={0.2}
          />
        </mesh>
      </Float>
      <pointLight position={[0, 3.6, 0]} color={locked ? "#666" : area.accent} intensity={beaten ? 30 : 14} distance={16} decay={2} />
      {beaten && <Sparkles count={26} scale={5} size={3} speed={0.5} color={area.accent} position={[0, 3.4, 0]} />}
      {locked && (
        <mesh position={[0, 1.6, 0]}>
          <sphereGeometry args={[2.6, 20, 20]} />
          <meshBasicMaterial color="#8a5cff" transparent opacity={0.05} />
        </mesh>
      )}
    </group>
  );
}

/** Creature ambiante qui vagabonde dans son secteur. */
function Wanderer({ area, speciesId, seed }: { area: AreaLayout; speciesId: string; seed: number }) {
  const g = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const grp = g.current;
    if (!grp) return;
    const t = clock.elapsedTime * (0.12 + seed * 0.03) + seed * 7;
    const r = 6 + (seed % 3) * 3;
    const x = area.center[0] + Math.cos(t) * r;
    const z = area.center[1] + Math.sin(t * 1.3) * r;
    grp.position.set(x, 0, z);
    grp.rotation.y = Math.atan2(Math.cos(t * 1.3) * 1.3 * Math.cos(t), -Math.sin(t)) + Math.PI / 2;
  });
  return (
    <group ref={g}>
      <CreatureModel speciesId={speciesId} scale={0.85} />
    </group>
  );
}

/* ------------------------------- Le dresseur ----------------------------- */

function Trainer({ controlsRef, onMove }: { controlsRef: React.MutableRefObject<WorldControls>; onMove: (x: number, z: number, speed: number) => void }) {
  const g = useRef<THREE.Group>(null);
  const pos = useRef(new THREE.Vector3(0, 0, 14));
  const speedRef = useRef(0);

  useFrame((_, delta) => {
    const grp = g.current;
    if (!grp) return;
    const c = controlsRef.current;
    const len = Math.hypot(c.x, c.z);
    const nx = len > 1 ? c.x / len : c.x;
    const nz = len > 1 ? c.z / len : c.z;
    const speed = (c.sprint ? 20 : 12) * Math.min(1, len);
    speedRef.current = speed;
    pos.current.x += nx * speed * delta;
    pos.current.z += nz * speed * delta;
    const d = Math.hypot(pos.current.x, pos.current.z);
    const max = ISLAND_RADIUS - 4;
    if (d > max) {
      pos.current.x *= max / d;
      pos.current.z *= max / d;
    }
    grp.position.copy(pos.current);
    if (speed > 0.5) {
      const targetRot = Math.atan2(nx, nz);
      let diff = targetRot - grp.rotation.y;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      grp.rotation.y += diff * Math.min(1, delta * 10);
    }
    onMove(pos.current.x, pos.current.z, speed);
  });

  return (
    <group ref={g}>
      <Suspense
        fallback={
          <mesh castShadow position={[0, 0.85, 0]}>
            <capsuleGeometry args={[0.25, 1.2, 6, 12]} />
            <meshStandardMaterial color="#2e3d5e" roughness={0.6} />
          </mesh>
        }
      >
        <TrainerAsset speedRef={speedRef} />
      </Suspense>
    </group>
  );
}

/* ----------------------------- Systeme global ---------------------------- */

function GameSystems({
  controlsRef,
  badges,
  areas,
  zones,
  onEncounter,
  onProximity,
  onSanctuary,
}: {
  controlsRef: React.MutableRefObject<WorldControls>;
  badges: string[];
  areas: AreaLayout[];
  zones: Zone[];
  onEncounter: (zoneId: string) => void;
  onProximity: (zoneId: string | null) => void;
  onSanctuary: () => void;
}) {
  const playerPos = useRef<{ x: number; z: number; speed: number }>({ x: 0, z: 14, speed: 0 });
  const rollTimer = useRef(0);
  const nearSanctuary = useRef(false);
  const nearAltar = useRef<string | null>(null);
  const { camera } = useThree();
  const camTarget = useMemo(() => new THREE.Vector3(), []);
  const lookTarget = useMemo(() => new THREE.Vector3(), []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const c = controlsRef.current;
      const k = e.key.toLowerCase();
      if (["arrowup", "w", "z"].includes(k)) c.z = -1;
      else if (["arrowdown", "s"].includes(k)) c.z = 1;
      else if (["arrowleft", "a", "q"].includes(k)) c.x = -1;
      else if (["arrowright", "d"].includes(k)) c.x = 1;
      else if (k === "shift") c.sprint = true;
    };
    const up = (e: KeyboardEvent) => {
      const c = controlsRef.current;
      const k = e.key.toLowerCase();
      if (["arrowup", "w", "z"].includes(k) && c.z === -1) c.z = 0;
      else if (["arrowdown", "s"].includes(k) && c.z === 1) c.z = 0;
      else if (["arrowleft", "a", "q"].includes(k) && c.x === -1) c.x = 0;
      else if (["arrowright", "d"].includes(k) && c.x === 1) c.x = 0;
      else if (k === "shift") c.sprint = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [controlsRef]);

  useFrame((_, delta) => {
    const p = playerPos.current;
    camTarget.set(p.x, 22, p.z + 16);
    camera.position.lerp(camTarget, 1 - Math.exp(-3.2 * delta));
    lookTarget.set(p.x, 1.4, p.z);
    camera.lookAt(lookTarget);

    const dSanct = Math.hypot(p.x - SANCTUARY_POS[0], p.z - SANCTUARY_POS[1]);
    if (dSanct < 5 && !nearSanctuary.current) {
      nearSanctuary.current = true;
      onSanctuary();
    } else if (dSanct >= 6) {
      nearSanctuary.current = false;
    }

    let found: string | null = null;
    for (const a of areas) {
      const d = Math.hypot(p.x - a.altar[0], p.z - a.altar[1]);
      if (d < 4.5) {
        found = a.zoneId;
        break;
      }
    }
    if (found !== nearAltar.current) {
      nearAltar.current = found;
      onProximity(found);
    }

    if (p.speed > 2) {
      rollTimer.current += delta;
      if (rollTimer.current > 0.55) {
        rollTimer.current = 0;
        for (const a of areas) {
          const zn = zones.find((z) => z.id === a.zoneId);
          if (!zn || !zoneUnlocked(zn, badges)) continue;
          const d = Math.hypot(p.x - a.center[0], p.z - a.center[1]);
          if (d < a.patchRadius && Math.random() < 0.3) {
            onEncounter(a.zoneId);
            break;
          }
        }
      }
    } else {
      rollTimer.current = 0;
    }
  });

  return (
    <Trainer
      controlsRef={controlsRef}
      onMove={(x, z, speed) => {
        playerPos.current = { x, z, speed };
      }}
    />
  );
}

/* --------------------------------- Scene --------------------------------- */

function FloatingIsles() {
  const isles = useMemo(() => {
    const rnd = mulberry32(4);
    return Array.from({ length: 5 }, (_, i) => {
      const a = (i / 5) * Math.PI * 2 + rnd();
      const r = 135 + rnd() * 60;
      return { pos: [Math.cos(a) * r, 14 + rnd() * 20, Math.sin(a) * r] as [number, number, number], s: 4 + rnd() * 5 };
    });
  }, []);
  return (
    <group>
      {isles.map((isle, i) => (
        <group key={i} position={isle.pos} scale={isle.s}>
          <mesh>
            <coneGeometry args={[1, 1.4, 8]} />
            <meshStandardMaterial color="#2c3550" roughness={0.9} />
          </mesh>
          <mesh position={[0, 0.75, 0]}>
            <cylinderGeometry args={[1, 0.9, 0.35, 8]} />
            <meshStandardMaterial color="#3d5a43" roughness={0.85} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

/** Campement du Sanctuaire : tentes, feu de camp, panneau, barrieres. */
function SanctuaryVillage() {
  const [x, z] = SANCTUARY_POS;
  return (
    <group position={[x, 0, z]}>
      <Suspense fallback={null}>
        <KitProp name="tent_detailedClosed" position={[-4.6, 0, -2.5]} rotationY={0.8} scale={1.4} />
        <KitProp name="tent_smallOpen" position={[4.4, 0, -3]} rotationY={-0.7} scale={1.5} />
        <KitProp name="tent_smallOpen" position={[0.5, 0, -5.4]} rotationY={0.15} scale={1.5} />
        <KitProp name="campfire_stones" position={[2.8, 0, 2.6]} scale={1.2} />
        <KitProp name="sign" position={[3.9, 0, 1.1]} rotationY={-2.2} scale={1.2} />
        {[-1, 0, 1].map((i) => (
          <React.Fragment key={i}>
            <KitProp name="fence_simpleHigh" position={[-6 + i * 2.05, 0, 3.4]} rotationY={0} scale={1.2} />
            <KitProp name="fence_simpleHigh" position={[-6 + i * 2.05, 0, -6.9]} rotationY={0} scale={1.2} />
          </React.Fragment>
        ))}
        <KitProp name="flower_yellowC" position={[-3.4, 0, 2.2]} scale={1.3} />
        <KitProp name="flower_yellowC" position={[4.9, 0, 3.6]} scale={1.1} />
        <KitProp name="lily_large" position={[-5.2, 0, 1.4]} scale={1.2} />
      </Suspense>
      {/* flammes du feu de camp */}
      <pointLight position={[2.8, 0.9, 2.6]} color="#ff9a3d" intensity={16} distance={10} decay={2} />
      <mesh position={[2.8, 0.55, 2.6]}>
        <coneGeometry args={[0.25, 0.7, 6]} />
        <meshStandardMaterial color="#ffb14d" emissive="#ff8a2a" emissiveIntensity={2.6} transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

export default function WorldScene(props: WorldSceneProps) {
  const { badges } = props;
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ position: [0, 22, 30], fov: 50, near: 0.5, far: 600 }}
      gl={{ antialias: true }}
      style={{ background: "#07071a" }}
    >
      <fog attach="fog" args={["#0b0f24", 70, 240]} />
      <Sky distance={4000} sunPosition={[-60, 10, -90]} turbidity={6} rayleigh={2.2} />
      <Stars radius={300} depth={80} count={2600} factor={5} fade speed={0.6} />

      <ambientLight intensity={0.35} color="#8fa2d8" />
      <directionalLight
        castShadow
        position={[60, 90, -40]}
        intensity={1.35}
        color="#ffe6b8"
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-130}
        shadow-camera-right={130}
        shadow-camera-top={130}
        shadow-camera-bottom={-130}
      />
      <hemisphereLight args={["#332e5e", "#0e1420", 0.5]} />

      {/* ile */}
      <mesh receiveShadow position={[0, -1, 0]}>
        <cylinderGeometry args={[ISLAND_RADIUS, ISLAND_RADIUS - 4, 2, 72]} />
        <meshStandardMaterial color="#2b3a2c" roughness={0.95} />
      </mesh>
      {/* mer */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.1, 0]}>
        <circleGeometry args={[500, 48]} />
        <meshStandardMaterial color="#0d1830" roughness={0.25} metalness={0.7} emissive="#0a1a33" emissiveIntensity={0.25} />
      </mesh>
      <Sparkles count={120} scale={[280, 4, 280]} size={2} speed={0.25} color="#5f86c9" position={[0, -1, 0]} />

      <FloatingIsles />

      {/* Sanctuaire central + campement */}
      <group position={[SANCTUARY_POS[0], 0, SANCTUARY_POS[1]]}>
        <mesh receiveShadow position={[0, 0.08, 0]}>
          <cylinderGeometry args={[5.4, 6, 0.18, 10]} />
          <meshStandardMaterial color="#3a4055" roughness={0.6} metalness={0.3} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.19, 0]}>
          <ringGeometry args={[4.2, 4.7, 40]} />
          <meshBasicMaterial color="#7fe8d5" transparent opacity={0.5} />
        </mesh>
        <Float speed={2} rotationIntensity={0.4} floatIntensity={0.8}>
          <mesh castShadow position={[0, 2.6, 0]} rotation={[0, Math.PI / 4, 0]}>
            <octahedronGeometry args={[1.15]} />
            <meshStandardMaterial color="#7fe8d5" emissive="#4ed8c2" emissiveIntensity={1.6} transparent opacity={0.92} roughness={0.15} />
          </mesh>
        </Float>
        <pointLight position={[0, 3, 0]} color="#6fe0cc" intensity={36} distance={26} decay={2} />
        <Sparkles count={60} scale={9} size={2.4} speed={0.6} color="#9df0e2" position={[0, 2.4, 0]} />
      </group>
      <SanctuaryVillage />

      {/* Secteurs des contrees */}
      {props.areas.map((a, areaIdx) => {
        const zone = props.zones.find((z0) => z0.id === a.zoneId);
        if (!zone) return null;
        const unlocked = zoneUnlocked(zone, badges);
        const beaten = badges.includes(a.zoneId);
        return (
          <group key={a.zoneId}>
            <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[a.center[0], 0.012, a.center[1]]}>
              <circleGeometry args={[a.patchRadius + 11, 40]} />
              <meshStandardMaterial color={a.ground} roughness={0.95} />
            </mesh>
            <Suspense fallback={null}>
              <BiomeProps area={a} />
            </Suspense>
            <ZoneSettlement area={a} zone={zone} index={areaIdx} />
            <ZoneArena area={a} zone={zone} final={areaIdx === props.areas.length - 1} />
            {unlocked && (
              <Suspense fallback={null}>
                <GrassPatch area={a} />
              </Suspense>
            )}
            <Altar area={a} beaten={beaten} locked={!unlocked} />
            {unlocked &&
              zone.wilds.slice(0, 2).map((w, i) => (
                <Wanderer key={w.speciesId} area={a} speciesId={w.speciesId} seed={i + 1 + areaIdx * 3} />
              ))}
          </group>
        );
      })}

      <GameSystems
        controlsRef={props.controlsRef}
        badges={badges}
        areas={props.areas}
        zones={props.zones}
        onEncounter={props.onEncounter}
        onProximity={props.onProximity}
        onSanctuary={props.onSanctuary}
      />

      <EffectComposer>
        <Bloom luminanceThreshold={0.5} intensity={0.75} mipmapBlur radius={0.7} />
      </EffectComposer>
    </Canvas>
  );
}

/* Les GLB du kit sont charges a la demande par Suspense; aucun prechargement
   global ici, sinon le decodage de dizaines de modeles bloque le lancement. */
