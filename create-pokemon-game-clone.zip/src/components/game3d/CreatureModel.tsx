"use client";

import React, { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { getSpecies } from "@/lib/game/data/species";
import { TYPE_COLOR } from "@/lib/game/data/chart";
import type { SpeciesPalette } from "@/lib/game/types";
import RiggedCreatureAsset, { hasRiggedAsset } from "./RiggedCreatureAsset";

/**
 * Creatures 3D procedurales de Valdoria.
 * Chaque espece est assemblee a partir de primitives animees (style low-poly
 * cinematographique). Les acces emissifs reagissent au bloom.
 */

interface AnimProps {
  /** incrementer pour declencher une attaque (lunge) */
  attackNonce?: number;
  /** incrementer pour declencher un coup recu (shake + flash) */
  hitNonce?: number;
  faint?: boolean;
}

interface CreatureModelProps extends AnimProps {
  speciesId: string;
  position?: [number, number, number];
  rotationY?: number;
  scale?: number;
  /** surmultiplie la couleur emissive (projecteur du camp, optionnel) */
}

/* --------------------------------- helpers -------------------------------- */

function Mat({
  color,
  emissive,
  emissiveIntensity = 0,
  roughness = 0.6,
  metalness = 0.1,
  transparent = false,
  opacity = 1,
}: {
  color: string;
  emissive?: string;
  emissiveIntensity?: number;
  roughness?: number;
  metalness?: number;
  transparent?: boolean;
  opacity?: number;
}) {
  return (
    <meshStandardMaterial
      color={color}
      emissive={emissive ?? "#000000"}
      emissiveIntensity={emissiveIntensity}
      roughness={roughness}
      metalness={metalness}
      transparent={transparent}
      opacity={opacity}
    />
  );
}

function Eye({ x, y, z, color = "#ffffff", pupil = "#101018", size = 0.09, glow = 0 }: { x: number; y: number; z: number; color?: string; pupil?: string; size?: number; glow?: number }) {
  return (
    <group position={[x, y, z]}>
      <mesh castShadow>
        <sphereGeometry args={[size, 12, 12]} />
        <Mat color={color} emissive={glow > 0 ? pupil : undefined} emissiveIntensity={glow} roughness={0.2} />
      </mesh>
      <mesh position={[0, 0, size * 0.55]}>
        <sphereGeometry args={[size * 0.5, 10, 10]} />
        <Mat color={pupil} emissive={glow > 0 ? pupil : undefined} emissiveIntensity={glow} roughness={0.1} />
      </mesh>
    </group>
  );
}

/* ------------------------------ especes 3D -------------------------------- */

function PyrraxBody() {
  const tail = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (tail.current) tail.current.rotation.z = Math.sin(clock.elapsedTime * 3) * 0.25;
  });
  return (
    <group>
      {/* corps */}
      <mesh castShadow position={[0, 0.62, 0]}>
        <sphereGeometry args={[0.52, 20, 20]} />
        <Mat color="#d96b35" />
      </mesh>
      {/* ventre */}
      <mesh position={[0, 0.5, 0.28]}>
        <sphereGeometry args={[0.34, 16, 16]} />
        <Mat color="#f2c79a" />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.28, 0.14]}>
        <sphereGeometry args={[0.42, 20, 20]} />
        <Mat color="#e07a3d" />
      </mesh>
      {/* criniere de flamme */}
      {[-0.2, 0, 0.2].map((x, i) => (
        <mesh key={i} position={[x, 1.62 - Math.abs(x), -0.05]} rotation={[(-x * Math.PI) / 3, 0, (-x * Math.PI) / 2]}>
          <coneGeometry args={[0.12, 0.45, 8]} />
          <Mat color="#ffb14d" emissive="#ff8a2a" emissiveIntensity={1.4} />
        </mesh>
      ))}
      {/* oreilles */}
      <mesh castShadow position={[-0.26, 1.72, 0.1]} rotation={[0, 0, 0.35]}>
        <coneGeometry args={[0.13, 0.42, 8]} />
        <Mat color="#d96b35" />
      </mesh>
      <mesh castShadow position={[0.26, 1.72, 0.1]} rotation={[0, 0, -0.35]}>
        <coneGeometry args={[0.13, 0.42, 8]} />
        <Mat color="#d96b35" />
      </mesh>
      <Eye x={-0.17} y={1.34} z={0.48} pupil="#3a1503" />
      <Eye x={0.17} y={1.34} z={0.48} pupil="#3a1503" />
      {/* museau */}
      <mesh position={[0, 1.2, 0.52]}>
        <sphereGeometry args={[0.07, 10, 10]} />
        <Mat color="#402012" />
      </mesh>
      {/* pattes */}
      {[-0.28, 0.28].map((x) =>
        [0.22, -0.22].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.18, z]}>
            <cylinderGeometry args={[0.09, 0.11, 0.36, 10]} />
            <Mat color="#b8542a" />
          </mesh>
        ))
      )}
      {/* queue braise */}
      <group ref={tail} position={[0, 0.72, -0.5]}>
        <mesh castShadow rotation={[Math.PI / 2.4, 0, 0]}>
          <coneGeometry args={[0.16, 0.7, 10]} />
          <Mat color="#e07a3d" />
        </mesh>
        <mesh position={[0, 0.42, -0.22]} rotation={[Math.PI / 2.4, 0, 0]}>
          <coneGeometry args={[0.14, 0.4, 10]} />
          <Mat color="#ffd23f" emissive="#ff9a1f" emissiveIntensity={2.2} />
        </mesh>
      </group>
    </group>
  );
}

function HydrissBody() {
  const tail = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (tail.current) tail.current.rotation.y = Math.sin(clock.elapsedTime * 2.4) * 0.3;
  });
  return (
    <group>
      {/* corps elongated */}
      <mesh castShadow position={[0, 0.6, 0]} rotation={[Math.PI / 2.6, 0, 0]}>
        <capsuleGeometry args={[0.4, 0.7, 6, 16]} />
        <Mat color="#2f8fb8" roughness={0.35} />
      </mesh>
      <mesh position={[0, 0.55, 0.3]} rotation={[Math.PI / 2.6, 0, 0]}>
        <capsuleGeometry args={[0.28, 0.55, 6, 14]} />
        <Mat color="#bfeaf2" roughness={0.3} />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.16, 0.42]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color="#35a3cc" roughness={0.35} />
      </mesh>
      {/* crete de nageoire */}
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[0, 1.44 - i * 0.12, 0.22 - i * 0.16]} rotation={[-0.5 - i * 0.25, 0, 0]}>
          <boxGeometry args={[0.04, 0.3 - i * 0.05, 0.22]} />
          <Mat color="#9fe6f7" emissive="#4ac3e8" emissiveIntensity={0.8} transparent opacity={0.9} />
        </mesh>
      ))}
      <Eye x={-0.15} y={1.22} z={0.7} pupil="#0c2f3f" />
      <Eye x={0.15} y={1.22} z={0.7} pupil="#0c2f3f" />
      {/* nageoires laterales */}
      <mesh castShadow position={[-0.42, 0.62, 0.1]} rotation={[0, 0, 0.9]}>
        <coneGeometry args={[0.1, 0.34, 8]} />
        <Mat color="#57c4e0" transparent opacity={0.9} />
      </mesh>
      <mesh castShadow position={[0.42, 0.62, 0.1]} rotation={[0, 0, -0.9]}>
        <coneGeometry args={[0.1, 0.34, 8]} />
        <Mat color="#57c4e0" transparent opacity={0.9} />
      </mesh>
      {/* queue */}
      <group ref={tail} position={[0, 0.42, -0.55]}>
        <mesh castShadow rotation={[Math.PI / 1.8, 0, 0]}>
          <coneGeometry args={[0.16, 0.7, 10]} />
          <Mat color="#2f8fb8" />
        </mesh>
        <mesh position={[0, 0.45, -0.18]} rotation={[Math.PI / 1.9, 0, 0]}>
          <coneGeometry args={[0.2, 0.34, 4]} />
          <Mat color="#9fe6f7" emissive="#4ac3e8" emissiveIntensity={1} transparent opacity={0.95} />
        </mesh>
      </group>
      {/* bulles */}
      {[[-0.3, 1.7, 0.3], [0.34, 1.55, 0.45], [0.1, 1.95, 0.2]].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <Mat color="#cfeeff" emissive="#9fdcff" emissiveIntensity={1.6} transparent opacity={0.7} />
        </mesh>
      ))}
    </group>
  );
}

function FeuillouBody() {
  const antlers = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (antlers.current) antlers.current.rotation.z = Math.sin(clock.elapsedTime * 1.6) * 0.06;
  });
  return (
    <group>
      {/* corps */}
      <mesh castShadow position={[0, 0.58, 0]}>
        <sphereGeometry args={[0.5, 20, 20]} />
        <Mat color="#5f9e56" />
      </mesh>
      <mesh position={[0, 0.5, 0.3]}>
        <sphereGeometry args={[0.3, 14, 14]} />
        <Mat color="#cfe7b4" />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.2, 0.12]}>
        <sphereGeometry args={[0.4, 20, 20]} />
        <Mat color="#6dad60" />
      </mesh>
      {/* bois de feuillage */}
      <group ref={antlers} position={[0, 1.5, 0.05]}>
        {[-1, 1].map((s) => (
          <group key={s} rotation={[0, 0, s * 0.5]}>
            <mesh castShadow position={[s * 0.22, 0.18, 0]} rotation={[0.3, 0, s * 0.9]}>
              <coneGeometry args={[0.1, 0.5, 6]} />
              <Mat color="#3f7a3a" />
            </mesh>
            <mesh position={[s * 0.42, 0.36, 0.06]} rotation={[0.5, 0, s * 1.2]}>
              <coneGeometry args={[0.16, 0.36, 6]} />
              <Mat color="#8fce6f" emissive="#4e9c3e" emissiveIntensity={0.5} />
            </mesh>
          </group>
        ))}
      </group>
      <Eye x={-0.16} y={1.26} z={0.46} pupil="#1e3a14" />
      <Eye x={0.16} y={1.26} z={0.46} pupil="#1e3a14" />
      <mesh position={[0, 1.12, 0.5]}>
        <sphereGeometry args={[0.06, 10, 10]} />
        <Mat color="#2c4a20" />
      </mesh>
      {/* sabots */}
      {[-0.26, 0.26].map((x) =>
        [0.2, -0.2].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.16, z]}>
            <cylinderGeometry args={[0.08, 0.1, 0.32, 10]} />
            <Mat color="#3f6b37" />
          </mesh>
        ))
      )}
      {/* lichen lumineux */}
      {[-0.3, 0.05, 0.3].map((x, i) => (
        <mesh key={i} position={[x, 0.72, -0.4]}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <Mat color="#cdeea0" emissive="#9ad94e" emissiveIntensity={1.4} />
        </mesh>
      ))}
    </group>
  );
}

function FoudrixBody() {
  const ears = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ears.current) ears.current.rotation.x = Math.sin(clock.elapsedTime * 5) * 0.08;
  });
  return (
    <group>
      <mesh castShadow position={[0, 0.6, 0]}>
        <sphereGeometry args={[0.42, 18, 18]} />
        <Mat color="#e8c53a" roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.55, 0.28]}>
        <sphereGeometry args={[0.26, 14, 14]} />
        <Mat color="#fff3c4" />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.14, 0.12]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color="#f0cf42" />
      </mesh>
      {/* longues oreilles eclair */}
      <group ref={ears} position={[0, 1.36, 0.1]}>
        {[-1, 1].map((s) => (
          <group key={s}>
            <mesh castShadow position={[s * 0.14, 0.3, 0]} rotation={[0, 0, s * 0.18]}>
              <boxGeometry args={[0.09, 0.55, 0.05]} />
              <Mat color="#e8c53a" />
            </mesh>
            <mesh position={[s * 0.2, 0.62, 0]} rotation={[0, 0, s * 0.5]}>
              <boxGeometry args={[0.08, 0.3, 0.04]} />
              <Mat color="#fff3c4" emissive="#ffd23f" emissiveIntensity={1.6} />
            </mesh>
          </group>
        ))}
      </group>
      <Eye x={-0.14} y={1.2} z={0.42} pupil="#20201a" />
      <Eye x={0.14} y={1.2} z={0.42} pupil="#20201a" />
      {/* moustaches electriques */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.34, 1.06, 0.36]} rotation={[0, s * 0.5, s * 1.35]}>
          <boxGeometry args={[0.02, 0.3, 0.02]} />
          <Mat color="#fff3c4" emissive="#ffd23f" emissiveIntensity={2.2} />
        </mesh>
      ))}
      {/* pattes arriere */}
      {[-0.22, 0.22].map((x) => (
        <mesh key={x} castShadow position={[x, 0.14, -0.05]}>
          <cylinderGeometry args={[0.08, 0.11, 0.28, 10]} />
          <Mat color="#c9a52a" />
        </mesh>
      ))}
      {/* etincelles */}
      {[[-0.45, 0.9, 0.2], [0.5, 1.0, 0.05]].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]}>
          <octahedronGeometry args={[0.05]} />
          <Mat color="#ffe98a" emissive="#ffd23f" emissiveIntensity={2.6} />
        </mesh>
      ))}
    </group>
  );
}

function GlacibouBody() {
  return (
    <group>
      {/* corps rond */}
      <mesh castShadow position={[0, 0.62, 0]}>
        <sphereGeometry args={[0.5, 20, 20]} />
        <Mat color="#bfe3f2" roughness={0.4} />
      </mesh>
      {/* face */}
      <mesh position={[0, 0.78, 0.34]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <Mat color="#eefaff" roughness={0.35} />
      </mesh>
      {/* yeux de hibou */}
      <Eye x={-0.14} y={0.85} z={0.6} size={0.11} pupil="#123347" />
      <Eye x={0.14} y={0.85} z={0.6} size={0.11} pupil="#123347" />
      {/* bec */}
      <mesh position={[0, 0.72, 0.62]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.06, 0.14, 8]} />
        <Mat color="#f0b429" />
      </mesh>
      {/* couronne de glace */}
      {[0, 1, 2, 3, 4].map((i) => {
        const a = (i / 5) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.2, 1.12, Math.sin(a) * 0.2]} rotation={[Math.sin(a) * 0.3, 0, -Math.cos(a) * 0.3]}>
            <octahedronGeometry args={[0.09]} />
            <Mat color="#a5e6ff" emissive="#6fc9f0" emissiveIntensity={1.2} transparent opacity={0.92} roughness={0.15} />
          </mesh>
        );
      })}
      {/* ailes */}
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.5, 0.66, -0.05]} rotation={[0.2, 0, s * 0.5]}>
          <coneGeometry args={[0.14, 0.44, 6]} />
          <Mat color="#9fd4e8" />
        </mesh>
      ))}
      {/* petites pattes */}
      {[-0.14, 0.14].map((x) => (
        <mesh key={x} castShadow position={[x, 0.1, 0.1]}>
          <cylinderGeometry args={[0.05, 0.07, 0.2, 8]} />
          <Mat color="#f0b429" />
        </mesh>
      ))}
    </group>
  );
}

function RocarokBody() {
  return (
    <group>
      {/* pierres empilees */}
      <mesh castShadow position={[0, 0.34, 0]}>
        <dodecahedronGeometry args={[0.42]} />
        <Mat color="#8a7a5e" roughness={0.85} />
      </mesh>
      <mesh castShadow position={[0, 0.82, 0]} rotation={[0.4, 0.7, 0]}>
        <dodecahedronGeometry args={[0.34]} />
        <Mat color="#98876a" roughness={0.85} />
      </mesh>
      <mesh castShadow position={[0, 1.22, 0.04]} rotation={[0.2, 0.3, 0.5]}>
        <dodecahedronGeometry args={[0.26]} />
        <Mat color="#7d6e55" roughness={0.85} />
      </mesh>
      {/* yeux runiques */}
      <Eye x={-0.11} y={1.26} z={0.26} size={0.06} color="#ffb35c" pupil="#ff8a2a" glow={2.6} />
      <Eye x={0.11} y={1.26} z={0.26} size={0.06} color="#ffb35c" pupil="#ff8a2a" glow={2.6} />
      {/* bras */}
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.52, 0.6, 0]} rotation={[0, 0, s * 0.4]}>
          <dodecahedronGeometry args={[0.18]} />
          <Mat color="#8a7a5e" roughness={0.85} />
        </mesh>
      ))}
      {/* mousse */}
      {[[-0.2, 1.05, 0.15], [0.22, 0.5, 0.3], [-0.05, 1.4, 0.05]].map((p, i) => (
        <mesh key={i} position={p as [number, number, number]} scale={[1, 0.4, 1]}>
          <sphereGeometry args={[0.12, 10, 10]} />
          <Mat color="#6f9c4a" roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

function SombraileBody() {
  const tail = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (tail.current) tail.current.rotation.y = Math.sin(clock.elapsedTime * 2.2) * 0.4;
  });
  return (
    <group>
      {/* corps fume */}
      <mesh castShadow position={[0, 0.6, 0]}>
        <sphereGeometry args={[0.4, 18, 18]} />
        <Mat color="#3a2f55" transparent opacity={0.92} roughness={0.4} />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.12, 0.14]}>
        <sphereGeometry args={[0.32, 18, 18]} />
        <Mat color="#463a68" transparent opacity={0.95} roughness={0.4} />
      </mesh>
      {/* oreilles de chat */}
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.2, 1.42, 0.08]} rotation={[0, 0, s * 0.4]}>
          <coneGeometry args={[0.1, 0.3, 6]} />
          <Mat color="#463a68" />
        </mesh>
      ))}
      <Eye x={-0.13} y={1.16} z={0.44} size={0.07} color="#e9dcff" pupil="#b388ff" glow={2.2} />
      <Eye x={0.13} y={1.16} z={0.44} size={0.07} color="#e9dcff" pupil="#b388ff" glow={2.2} />
      {/* croissant de lune */}
      <mesh position={[0, 1.32, 0.34]} rotation={[0, 0, Math.PI / 2]}>
        <torusGeometry args={[0.1, 0.03, 8, 16, Math.PI]} />
        <Mat color="#d7c6ff" emissive="#b388ff" emissiveIntensity={1.6} />
      </mesh>
      {/* pattes */}
      {[-0.2, 0.2].map((x) =>
        [0.18, -0.18].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.14, z]}>
            <cylinderGeometry args={[0.06, 0.08, 0.28, 8]} />
            <Mat color="#332a4e" />
          </mesh>
        ))
      )}
      {/* queue de fumee */}
      <group ref={tail} position={[0, 0.6, -0.4]}>
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[0, 0.1 + i * 0.14, -i * 0.16]}>
            <sphereGeometry args={[0.16 - i * 0.03, 10, 10]} />
            <Mat color="#5a4a85" emissive="#8f6fe0" emissiveIntensity={0.8} transparent opacity={0.75 - i * 0.12} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

function ZephyrelleBody() {
  const wings = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (wings.current) {
      const f = Math.sin(clock.elapsedTime * 6) * 0.4;
      wings.current.children.forEach((w, i) => (w.rotation.z = (i === 0 ? 1 : -1) * (0.3 + f)));
    }
  });
  return (
    <group>
      <mesh castShadow position={[0, 0.7, 0]} rotation={[0.3, 0, 0]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color="#7fa8e8" roughness={0.45} />
      </mesh>
      <mesh position={[0, 0.66, 0.2]}>
        <sphereGeometry args={[0.22, 14, 14]} />
        <Mat color="#eaf4ff" />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.14, 0.12]}>
        <sphereGeometry args={[0.26, 16, 16]} />
        <Mat color="#8db4ec" />
      </mesh>
      <Eye x={-0.12} y={1.18} z={0.34} size={0.06} pupil="#14253f" />
      <Eye x={0.12} y={1.18} z={0.34} size={0.06} pupil="#14253f" />
      {/* bec */}
      <mesh position={[0, 1.1, 0.4]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.05, 0.16, 8]} />
        <Mat color="#f0b429" />
      </mesh>
      {/* ailes */}
      <group ref={wings}>
        <mesh castShadow position={[-0.4, 0.78, -0.02]} rotation={[0, 0.2, 0.5]}>
          <boxGeometry args={[0.55, 0.06, 0.24]} />
          <Mat color="#9cc2f2" />
        </mesh>
        <mesh castShadow position={[0.4, 0.78, -0.02]} rotation={[0, -0.2, -0.5]}>
          <boxGeometry args={[0.55, 0.06, 0.24]} />
          <Mat color="#9cc2f2" />
        </mesh>
      </group>
      {/* queue en rubans */}
      {[-0.12, 0, 0.12].map((x, i) => (
        <mesh key={i} position={[x, 0.62, -0.42]} rotation={[Math.PI / 2.2, 0, x]}>
          <boxGeometry args={[0.07, 0.03, 0.55]} />
          <Mat color={i === 1 ? "#cfe4ff" : "#8db4ec"} emissive={i === 1 ? "#7fb5ff" : undefined} emissiveIntensity={i === 1 ? 1 : 0} transparent opacity={0.95} />
        </mesh>
      ))}
      {/* pattes */}
      {[-0.1, 0.1].map((x) => (
        <mesh key={x} position={[x, 0.32, 0.05]}>
          <cylinderGeometry args={[0.03, 0.04, 0.24, 6]} />
          <Mat color="#f0b429" />
        </mesh>
      ))}
    </group>
  );
}

function DrakonyxBody() {
  const wings = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (wings.current) {
      const f = Math.sin(clock.elapsedTime * 2.4) * 0.18;
      wings.current.children.forEach((w, i) => (w.rotation.z = (i === 0 ? 1 : -1) * (0.25 + f)));
    }
  });
  return (
    <group>
      {/* corps */}
      <mesh castShadow position={[0, 0.72, 0]} rotation={[0.15, 0, 0]}>
        <capsuleGeometry args={[0.42, 0.5, 6, 16]} />
        <Mat color="#1d1d2b" roughness={0.3} metalness={0.5} />
      </mesh>
      {/* ventre dore */}
      <mesh position={[0, 0.66, 0.3]} rotation={[0.2, 0, 0]}>
        <capsuleGeometry args={[0.26, 0.4, 6, 14]} />
        <Mat color="#c9962e" roughness={0.35} metalness={0.6} emissive="#7a5510" emissiveIntensity={0.4} />
      </mesh>
      {/* tete */}
      <mesh castShadow position={[0, 1.42, 0.2]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color="#23233a" roughness={0.3} metalness={0.5} />
      </mesh>
      {/* couronne de cornes dorees */}
      {[-2, -1, 0, 1, 2].map((i) => (
        <mesh key={i} position={[i * 0.11, 1.74 - Math.abs(i) * 0.05, 0.06 - Math.abs(i) * 0.03]} rotation={[-0.4, 0, i * -0.25]}>
          <coneGeometry args={[0.06, 0.3 - Math.abs(i) * 0.04, 6]} />
          <Mat color="#f0c04a" emissive="#c9962e" emissiveIntensity={1.2} metalness={0.7} roughness={0.25} />
        </mesh>
      ))}
      <Eye x={-0.15} y={1.48} z={0.5} size={0.07} color="#ffd98a" pupil="#f0a23d" glow={2.6} />
      <Eye x={0.15} y={1.48} z={0.5} size={0.07} color="#ffd98a" pupil="#f0a23d" glow={2.6} />
      {/* machoire */}
      <mesh position={[0, 1.32, 0.48]}>
        <boxGeometry args={[0.22, 0.1, 0.14]} />
        <Mat color="#1a1a28" metalness={0.4} roughness={0.35} />
      </mesh>
      {/* ailes constellees */}
      <group ref={wings}>
        <mesh castShadow position={[-0.6, 0.95, -0.1]} rotation={[0, 0.35, 0.4]}>
          <boxGeometry args={[0.85, 0.05, 0.4]} />
          <Mat color="#2e2e4d" emissive="#5a5db8" emissiveIntensity={0.8} transparent opacity={0.95} />
        </mesh>
        <mesh castShadow position={[0.6, 0.95, -0.1]} rotation={[0, -0.35, -0.4]}>
          <boxGeometry args={[0.85, 0.05, 0.4]} />
          <Mat color="#2e2e4d" emissive="#5a5db8" emissiveIntensity={0.8} transparent opacity={0.95} />
        </mesh>
      </group>
      {/* pattes */}
      {[-0.28, 0.28].map((x) =>
        [0.24, -0.24].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.2, z]}>
            <cylinderGeometry args={[0.09, 0.12, 0.4, 8]} />
            <Mat color="#23233a" metalness={0.4} roughness={0.35} />
          </mesh>
        ))
      )}
      {/* queue */}
      <mesh castShadow position={[0, 0.5, -0.62]} rotation={[Math.PI / 1.8, 0, 0]}>
        <coneGeometry args={[0.14, 0.9, 8]} />
        <Mat color="#1d1d2b" metalness={0.5} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.9, -0.85]}>
        <octahedronGeometry args={[0.09]} />
        <Mat color="#ffd98a" emissive="#f0a23d" emissiveIntensity={2} />
      </mesh>
    </group>
  );
}

/* ------------------------- Gabarits generiques 3D -------------------------- */
/* Corps parametres par palette pour les especes des quatre continents.        */

type Pal = Required<SpeciesPalette>;

function useWag(speed = 3) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.rotation.z = Math.sin(clock.elapsedTime * speed) * 0.22;
  });
  return ref;
}

function CanineBody({ c }: { c: Pal }) {
  const tail = useWag(3.4);
  return (
    <group>
      <mesh castShadow position={[0, 0.62, 0]}>
        <sphereGeometry args={[0.42, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 0.56, 0.24]}>
        <sphereGeometry args={[0.26, 14, 14]} />
        <Mat color={c.belly} />
      </mesh>
      <mesh castShadow position={[0, 1.14, 0.16]}>
        <sphereGeometry args={[0.3, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 1.06, 0.44]}>
        <boxGeometry args={[0.2, 0.14, 0.18]} />
        <Mat color={c.belly} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.18, 1.42, 0.06]} rotation={[0, 0, s * 0.3]}>
          <coneGeometry args={[0.09, 0.3, 6]} />
          <Mat color={c.body} />
        </mesh>
      ))}
      <Eye x={-0.12} y={1.2} z={0.42} pupil={c.eye} />
      <Eye x={0.12} y={1.2} z={0.42} pupil={c.eye} />
      {[-0.22, 0.22].map((x) =>
        [0.18, -0.18].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.16, z]}>
            <cylinderGeometry args={[0.07, 0.09, 0.32, 8]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
      <group ref={tail} position={[0, 0.66, -0.4]}>
        <mesh castShadow rotation={[Math.PI / 2.3, 0, 0]}>
          <coneGeometry args={[0.1, 0.55, 8]} />
          <Mat color={c.body} />
        </mesh>
        <mesh position={[0, 0.3, -0.16]} rotation={[Math.PI / 2.3, 0, 0]}>
          <coneGeometry args={[0.09, 0.22, 8]} />
          <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.9} />
        </mesh>
      </group>
    </group>
  );
}

function FelineBody({ c }: { c: Pal }) {
  const tail = useWag(2.6);
  return (
    <group>
      <mesh castShadow position={[0, 0.66, 0]}>
        <sphereGeometry args={[0.46, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh castShadow position={[0, 1.3, 0.18]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      {/* criniere solaire */}
      {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => {
        const a = (i / 8) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.42, 1.3 + Math.sin(a) * 0.42, 0.08]} rotation={[0, 0, a]}>
            <coneGeometry args={[0.1, 0.4, 6]} />
            <Mat color={c.accent} emissive={c.accent} emissiveIntensity={1.8} />
          </mesh>
        );
      })}
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.2, 1.6, 0.14]} rotation={[0, 0, s * 0.35]}>
          <coneGeometry args={[0.08, 0.24, 6]} />
          <Mat color={c.body} />
        </mesh>
      ))}
      <Eye x={-0.13} y={1.36} z={0.5} pupil={c.eye} glow={2} color={c.accent} />
      <Eye x={0.13} y={1.36} z={0.5} pupil={c.eye} glow={2} color={c.accent} />
      {[-0.24, 0.24].map((x) =>
        [0.2, -0.2].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.18, z]}>
            <cylinderGeometry args={[0.08, 0.1, 0.36, 8]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
      <group ref={tail} position={[0, 0.7, -0.44]}>
        <mesh castShadow rotation={[Math.PI / 2.2, 0, 0]}>
          <coneGeometry args={[0.09, 0.7, 8]} />
          <Mat color={c.body} />
        </mesh>
        <mesh position={[0, 0.4, -0.2]}>
          <sphereGeometry args={[0.12, 10, 10]} />
          <Mat color={c.accent} emissive={c.accent} emissiveIntensity={2} />
        </mesh>
      </group>
    </group>
  );
}

function UrsineBody({ c }: { c: Pal }) {
  return (
    <group>
      <mesh castShadow position={[0, 0.68, 0]}>
        <sphereGeometry args={[0.52, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 0.6, 0.3]}>
        <sphereGeometry args={[0.32, 14, 14]} />
        <Mat color={c.belly} />
      </mesh>
      <mesh castShadow position={[0, 1.26, 0.14]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.22, 1.54, 0.06]}>
          <sphereGeometry args={[0.1, 10, 10]} />
          <Mat color={c.accent} />
        </mesh>
      ))}
      <Eye x={-0.13} y={1.32} z={0.44} pupil={c.eye} />
      <Eye x={0.13} y={1.32} z={0.44} pupil={c.eye} />
      <mesh position={[0, 1.2, 0.46]}>
        <sphereGeometry args={[0.08, 10, 10]} />
        <Mat color={c.accent} />
      </mesh>
      {[-0.3, 0.3].map((x) =>
        [0.2, -0.2].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.18, z]}>
            <cylinderGeometry args={[0.1, 0.12, 0.36, 10]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
      {/* feuille / herbe sur la tete */}
      <mesh position={[0, 1.6, 0.12]} rotation={[0.4, 0, 0.2]}>
        <coneGeometry args={[0.14, 0.3, 5]} />
        <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.4} />
      </mesh>
    </group>
  );
}

function RodentBody({ c }: { c: Pal }) {
  const tail = useWag(2.2);
  return (
    <group>
      <mesh castShadow position={[0, 0.5, 0]}>
        <sphereGeometry args={[0.44, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh castShadow position={[0, 1.0, 0.16]}>
        <sphereGeometry args={[0.28, 16, 16]} />
        <Mat color={c.body} />
      </mesh>
      {/* grandes dents */}
      {[-0.05, 0.05].map((x) => (
        <mesh key={x} position={[x, 0.9, 0.42]}>
          <boxGeometry args={[0.06, 0.12, 0.04]} />
          <Mat color="#ffffff" roughness={0.2} />
        </mesh>
      ))}
      <Eye x={-0.11} y={1.06} z={0.4} pupil={c.eye} />
      <Eye x={0.11} y={1.06} z={0.4} pupil={c.eye} />
      {[-0.24, 0.24].map((x) =>
        [0.16, -0.16].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.14, z]}>
            <cylinderGeometry args={[0.07, 0.09, 0.28, 8]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
      {/* queue plate */}
      <group ref={tail} position={[0, 0.36, -0.44]}>
        <mesh castShadow rotation={[Math.PI / 2, 0, 0]} scale={[1.4, 1, 0.3]}>
          <sphereGeometry args={[0.24, 12, 12]} />
          <Mat color={c.accent} roughness={0.5} />
        </mesh>
      </group>
    </group>
  );
}

function SealBody({ c }: { c: Pal }) {
  return (
    <group>
      <mesh castShadow position={[0, 0.52, 0]} rotation={[Math.PI / 2.3, 0, 0]}>
        <capsuleGeometry args={[0.4, 0.55, 6, 16]} />
        <Mat color={c.body} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.44, 0.3]} rotation={[Math.PI / 2.3, 0, 0]}>
        <capsuleGeometry args={[0.28, 0.4, 6, 14]} />
        <Mat color={c.belly} roughness={0.4} />
      </mesh>
      <mesh castShadow position={[0, 0.98, 0.42]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <Mat color={c.body} />
      </mesh>
      {/* casque */}
      <mesh castShadow position={[0, 1.2, 0.4]}>
        <sphereGeometry args={[0.2, 12, 10, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.5} metalness={0.4} roughness={0.3} />
      </mesh>
      <Eye x={-0.12} y={1.02} z={0.66} pupil={c.eye} />
      <Eye x={0.12} y={1.02} z={0.66} pupil={c.eye} />
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.42, 0.5, 0.05]} rotation={[0, 0, s * 1]}>
          <coneGeometry args={[0.1, 0.36, 8]} />
          <Mat color={c.body} />
        </mesh>
      ))}
      <mesh castShadow position={[0, 0.36, -0.55]} rotation={[Math.PI / 1.9, 0, 0]}>
        <coneGeometry args={[0.18, 0.4, 8]} />
        <Mat color={c.body} />
      </mesh>
    </group>
  );
}

function SerpentBody({ c }: { c: Pal }) {
  const g = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!g.current) return;
    const t = clock.elapsedTime;
    g.current.children.forEach((seg, i) => {
      seg.position.x = Math.sin(t * 2.2 + i * 0.8) * 0.06 * i;
    });
  });
  const lens = [0.3, 0.26, 0.22, 0.17, 0.12];
  return (
    <group ref={g}>
      <mesh castShadow position={[0, 0.5, 0.4]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color={c.body} roughness={0.35} />
      </mesh>
      <Eye x={-0.13} y={0.62} z={0.74} pupil={c.eye} />
      <Eye x={0.13} y={0.62} z={0.74} pupil={c.eye} />
      {/* moustaches */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.28, 0.5, 0.66]} rotation={[0, s * 0.4, s * 1.3]}>
          <boxGeometry args={[0.02, 0.36, 0.02]} />
          <Mat color={c.accent} emissive={c.accent} emissiveIntensity={1.2} />
        </mesh>
      ))}
      {/* nageoires */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.2, 0.86, 0.3]} rotation={[0.2, 0, s * 0.7]}>
          <coneGeometry args={[0.1, 0.3, 6]} />
          <Mat color={c.accent} transparent opacity={0.9} />
        </mesh>
      ))}
      {lens.map((r, i) => (
        <mesh key={i} castShadow position={[0, 0.46 - i * 0.02, -0.1 - i * 0.32]}>
          <sphereGeometry args={[r, 14, 14]} />
          <Mat color={i % 2 ? c.belly : c.body} roughness={0.35} />
        </mesh>
      ))}
      <mesh position={[0, 0.4, -1.85]} rotation={[Math.PI / 2.1, 0, 0]}>
        <coneGeometry args={[0.16, 0.3, 4]} />
        <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.8} transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

function BirdBody({ c }: { c: Pal }) {
  const wings = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (wings.current) {
      const f = Math.sin(clock.elapsedTime * 5.5) * 0.35;
      wings.current.children.forEach((w, i) => (w.rotation.z = (i === 0 ? 1 : -1) * (0.35 + f)));
    }
  });
  return (
    <group>
      <mesh castShadow position={[0, 0.66, 0]} rotation={[0.25, 0, 0]}>
        <sphereGeometry args={[0.34, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 0.6, 0.2]}>
        <sphereGeometry args={[0.22, 14, 14]} />
        <Mat color={c.belly} />
      </mesh>
      <mesh castShadow position={[0, 1.12, 0.12]}>
        <sphereGeometry args={[0.24, 16, 16]} />
        <Mat color={c.body} />
      </mesh>
      {/* huppe */}
      <mesh position={[0, 1.36, 0.08]} rotation={[0.3, 0, 0]}>
        <coneGeometry args={[0.07, 0.26, 6]} />
        <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.9} />
      </mesh>
      <Eye x={-0.11} y={1.16} z={0.32} pupil={c.eye} />
      <Eye x={0.11} y={1.16} z={0.32} pupil={c.eye} />
      <mesh position={[0, 1.08, 0.38]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.05, 0.16, 8]} />
        <Mat color="#f0b429" />
      </mesh>
      <group ref={wings}>
        <mesh castShadow position={[-0.42, 0.74, -0.02]} rotation={[0, 0.2, 0.4]}>
          <boxGeometry args={[0.6, 0.06, 0.24]} />
          <Mat color={c.body} />
        </mesh>
        <mesh castShadow position={[0.42, 0.74, -0.02]} rotation={[0, -0.2, -0.4]}>
          <boxGeometry args={[0.6, 0.06, 0.24]} />
          <Mat color={c.body} />
        </mesh>
      </group>
      {[-0.1, 0.1].map((x) => (
        <mesh key={x} position={[x, 0.28, 0.05]}>
          <cylinderGeometry args={[0.03, 0.04, 0.26, 6]} />
          <Mat color="#f0b429" />
        </mesh>
      ))}
      <mesh position={[0, 0.6, -0.44]} rotation={[Math.PI / 2.2, 0, 0]}>
        <boxGeometry args={[0.14, 0.03, 0.5]} />
        <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.6} />
      </mesh>
    </group>
  );
}

function GhostBody({ c }: { c: Pal }) {
  const g = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (g.current) g.current.rotation.y = Math.sin(clock.elapsedTime * 1.4) * 0.12;
  });
  return (
    <group ref={g}>
      <mesh castShadow position={[0, 0.86, 0]}>
        <sphereGeometry args={[0.4, 18, 18]} />
        <Mat color={c.body} transparent opacity={0.85} roughness={0.3} />
      </mesh>
      {[0, 1, 2, 3].map((i) => (
        <mesh key={i} position={[Math.sin(i * 2) * 0.1, 0.5 - i * 0.14, -i * 0.1]}>
          <sphereGeometry args={[0.26 - i * 0.05, 12, 12]} />
          <Mat color={c.body} emissive={c.accent} emissiveIntensity={0.7} transparent opacity={0.7 - i * 0.12} />
        </mesh>
      ))}
      <Eye x={-0.14} y={0.94} z={0.38} size={0.08} color="#ffffff" pupil={c.accent} glow={2.4} />
      <Eye x={0.14} y={0.94} z={0.38} size={0.08} color="#ffffff" pupil={c.accent} glow={2.4} />
      {/* bras de brume */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.42, 0.8, 0.1]} rotation={[0, 0, s * 1.1]}>
          <coneGeometry args={[0.08, 0.4, 6]} />
          <Mat color={c.body} transparent opacity={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function BovineBody({ c }: { c: Pal }) {
  return (
    <group>
      <mesh castShadow position={[0, 0.66, -0.05]} rotation={[0.15, 0, 0]}>
        <capsuleGeometry args={[0.42, 0.5, 6, 14]} />
        <Mat color={c.body} roughness={0.7} />
      </mesh>
      <mesh castShadow position={[0, 1.06, 0.34]}>
        <sphereGeometry args={[0.32, 16, 16]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 0.94, 0.56]}>
        <sphereGeometry args={[0.2, 12, 12]} />
        <Mat color={c.belly} />
      </mesh>
      {/* cornes */}
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.3, 1.28, 0.3]} rotation={[0, 0, s * 1.1]}>
          <coneGeometry args={[0.06, 0.34, 6]} />
          <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.4} metalness={0.5} roughness={0.3} />
        </mesh>
      ))}
      {/* plaques de bronze */}
      {[0.2, -0.05, -0.3].map((z, i) => (
        <mesh key={i} position={[0, 0.95 - i * 0.16, z]} rotation={[0.3, 0, 0]}>
          <boxGeometry args={[0.55 - i * 0.08, 0.05, 0.18]} />
          <Mat color={c.accent} metalness={0.6} roughness={0.3} />
        </mesh>
      ))}
      <Eye x={-0.13} y={1.12} z={0.6} pupil={c.eye} />
      <Eye x={0.13} y={1.12} z={0.6} pupil={c.eye} />
      {[-0.26, 0.26].map((x) =>
        [0.24, -0.3].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.2, z]}>
            <cylinderGeometry args={[0.09, 0.12, 0.4, 8]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
    </group>
  );
}

function DrakeBody({ c }: { c: Pal }) {
  const wings = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!wings.current) return;
    const f = Math.sin(clock.elapsedTime * 3) * 0.25;
    wings.current.children.forEach((w, i) => (w.rotation.z = (i === 0 ? 1 : -1) * (0.3 + f)));
  });
  return (
    <group>
      <mesh castShadow position={[0, 0.6, 0]}>
        <sphereGeometry args={[0.42, 18, 18]} />
        <Mat color={c.body} />
      </mesh>
      <mesh position={[0, 0.54, 0.26]}>
        <sphereGeometry args={[0.26, 14, 14]} />
        <Mat color={c.belly} />
      </mesh>
      <mesh castShadow position={[0, 1.16, 0.16]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <Mat color={c.body} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.14, 1.44, 0.04]} rotation={[0.2, 0, s * 0.4]}>
          <coneGeometry args={[0.06, 0.26, 6]} />
          <Mat color={c.accent} emissive={c.accent} emissiveIntensity={0.7} />
        </mesh>
      ))}
      <Eye x={-0.12} y={1.22} z={0.42} pupil={c.eye} glow={1.6} color={c.accent} />
      <Eye x={0.12} y={1.22} z={0.42} pupil={c.eye} glow={1.6} color={c.accent} />
      <group ref={wings}>
        <mesh castShadow position={[-0.44, 0.8, -0.08]} rotation={[0, 0.3, 0.5]}>
          <coneGeometry args={[0.16, 0.55, 4]} />
          <Mat color={c.body} transparent opacity={0.95} />
        </mesh>
        <mesh castShadow position={[0.44, 0.8, -0.08]} rotation={[0, -0.3, -0.5]}>
          <coneGeometry args={[0.16, 0.55, 4]} />
          <Mat color={c.body} transparent opacity={0.95} />
        </mesh>
      </group>
      {[-0.22, 0.22].map((x) =>
        [0.18, -0.18].map((z) => (
          <mesh key={`${x}-${z}`} castShadow position={[x, 0.16, z]}>
            <cylinderGeometry args={[0.07, 0.09, 0.32, 8]} />
            <Mat color={c.body} />
          </mesh>
        ))
      )}
      <mesh castShadow position={[0, 0.5, -0.5]} rotation={[Math.PI / 1.9, 0, 0]}>
        <coneGeometry args={[0.1, 0.6, 8]} />
        <Mat color={c.body} />
      </mesh>
    </group>
  );
}

function GolemBody({ c }: { c: Pal }) {
  return (
    <group>
      <mesh castShadow position={[0, 0.4, 0]}>
        <dodecahedronGeometry args={[0.44]} />
        <Mat color={c.body} roughness={0.6} metalness={0.3} />
      </mesh>
      <mesh castShadow position={[0, 0.94, 0]} rotation={[0.4, 0.6, 0.2]}>
        <dodecahedronGeometry args={[0.34]} />
        <Mat color={c.body} roughness={0.55} metalness={0.35} />
      </mesh>
      <mesh castShadow position={[0, 1.4, 0.06]} rotation={[0.2, 0.3, 0.4]}>
        <dodecahedronGeometry args={[0.26]} />
        <Mat color={c.body} roughness={0.5} metalness={0.4} />
      </mesh>
      {/* couronne */}
      {[0, 1, 2, 3, 4].map((i) => {
        const a = (i / 5) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.2, 1.66, 0.06 + Math.sin(a) * 0.2]}>
            <coneGeometry args={[0.05, 0.2, 5]} />
            <Mat color={c.accent} emissive={c.accent} emissiveIntensity={1.4} />
          </mesh>
        );
      })}
      <Eye x={-0.11} y={1.44} z={0.3} size={0.06} color={c.accent} pupil={c.accent} glow={2.4} />
      <Eye x={0.11} y={1.44} z={0.3} size={0.06} color={c.accent} pupil={c.accent} glow={2.4} />
      {[-1, 1].map((s) => (
        <mesh key={s} castShadow position={[s * 0.55, 0.7, 0]} rotation={[0, 0, s * 0.4]}>
          <dodecahedronGeometry args={[0.18]} />
          <Mat color={c.body} metalness={0.3} roughness={0.55} />
        </mesh>
      ))}
    </group>
  );
}

const TEMPLATES: Record<string, React.ComponentType<{ c: Pal }>> = {
  canine: CanineBody,
  feline: FelineBody,
  ursine: UrsineBody,
  rodent: RodentBody,
  seal: SealBody,
  serpent: SerpentBody,
  bird: BirdBody,
  ghost: GhostBody,
  bovine: BovineBody,
  drake: DrakeBody,
  golem: GolemBody,
};

const BODIES: Record<string, React.ComponentType> = {
  pyrrax: PyrraxBody,
  hydriss: HydrissBody,
  feuillou: FeuillouBody,
  foudrix: FoudrixBody,
  glacibou: GlacibouBody,
  rocarok: RocarokBody,
  sombraile: SombraileBody,
  zephyrelle: ZephyrelleBody,
  drakonyx: DrakonyxBody,
};

const BASE_SCALE: Record<string, number> = {
  pyrrax: 1,
  hydriss: 1,
  feuillou: 1,
  foudrix: 0.95,
  glacibou: 0.95,
  rocarok: 1.05,
  sombraile: 1,
  zephyrelle: 0.95,
  drakonyx: 1.25,
};

/* ------------------------------- composant -------------------------------- */

export default function CreatureModel({
  speciesId,
  position = [0, 0, 0],
  rotationY = 0,
  scale = 1,
  attackNonce = 0,
  hitNonce = 0,
  faint = false,
}: CreatureModelProps) {
  const group = useRef<THREE.Group>(null);
  const atkStart = useRef(-1);
  const hitStart = useRef(-1);
  const clockRef = useRef<THREE.Clock | null>(null);
  const phase = useMemo(() => Math.random() * Math.PI * 2, []);

  useEffect(() => {
    if (attackNonce > 0 && clockRef.current) atkStart.current = clockRef.current.elapsedTime;
  }, [attackNonce]);
  useEffect(() => {
    if (hitNonce > 0 && clockRef.current) hitStart.current = clockRef.current.elapsedTime;
  }, [hitNonce]);

  useFrame((state) => {
    clockRef.current = state.clock;
    const g = group.current;
    if (!g) return;
    const t = state.clock.elapsedTime;

    // flottement / respiration
    let y = Math.sin(t * 2 + phase) * 0.05;
    let x = 0;
    let z = 0;
    let squash = 1;

    // attaque : charge vers l'avant puis retour
    if (atkStart.current >= 0) {
      const p = (t - atkStart.current) / 0.45;
      if (p < 1) {
        const fwd = Math.sin(p * Math.PI) * 1.4;
        z += fwd * Math.cos(rotationY + Math.PI / 2);
        x += fwd * -Math.sin(rotationY + Math.PI / 2);
      } else atkStart.current = -1;
    }
    // coup recu : tremblement
    if (hitStart.current >= 0) {
      const p = (t - hitStart.current) / 0.5;
      if (p < 1) {
        x += Math.sin(p * 45) * (1 - p) * 0.12;
      } else hitStart.current = -1;
    }
    // K.O. : bascule et descente
    let tilt = 0;
    let sink = 0;
    if (faint) {
      tilt = 1.2;
      sink = -0.35;
      squash = 0.7;
      y = 0;
    }
    g.position.set(position[0] + x, Math.max(0 + sink, position[1] + y + sink), position[2] + z);
    g.rotation.set(tilt, rotationY, 0);
    const s = scale * (BASE_SCALE[speciesId] ?? 1);
    g.scale.set(s, s * squash, s);
  });

  const species = getSpecies(speciesId);
  const Bespoke = BODIES[speciesId];
  const Tpl = TEMPLATES[species.template ?? "canine"];
  const palette: Pal = {
    body: species.colors?.body ?? "#8a8aa0",
    belly: species.colors?.belly ?? "#d8d8e8",
    accent: species.colors?.accent ?? TYPE_COLOR[species.type],
    eye: species.colors?.eye ?? "#101018",
  };

  return (
    <group ref={group} position={position}>
      {Bespoke ? <Bespoke /> : <Tpl c={palette} />}
      {/* ombre de contact */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
        <circleGeometry args={[0.65, 24]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.35} />
      </mesh>
    </group>
  );
}
