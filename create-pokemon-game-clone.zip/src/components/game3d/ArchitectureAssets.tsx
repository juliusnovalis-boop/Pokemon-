"use client";

import { Suspense, useMemo } from "react";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import type { AreaLayout } from "@/lib/game/data/worldLayout";
import type { Zone } from "@/lib/game/types";

const urlFor = (name: string) => `/models/architecture/${name}.glb`;

function NormalizedBuilding({
  name,
  position,
  rotationY,
  height,
}: {
  name: string;
  position: [number, number, number];
  rotationY: number;
  height: number;
}) {
  const { scene } = useGLTF(urlFor(name));
  const model = useMemo(() => {
    const copy = scene.clone(true);
    copy.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.castShadow = true;
        mesh.receiveShadow = true;
      }
    });
    return copy;
  }, [scene]);
  const fit = useMemo(() => {
    model.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    return {
      scale: height / Math.max(0.01, size.y),
      offset: new THREE.Vector3(-center.x, -box.min.y, -center.z),
    };
  }, [height, model]);

  return (
    <group position={position} rotation={[0, rotationY, 0]} scale={fit.scale}>
      <primitive object={model} position={fit.offset} />
    </group>
  );
}

const fallback = (
  <mesh castShadow position={[0, 1.5, 0]}>
    <boxGeometry args={[2.6, 3, 2.6]} />
    <meshStandardMaterial color="#50485d" roughness={0.8} />
  </mesh>
);

/**
 * Petit quartier construit sur le chemin entre le Sanctuaire et le biome.
 * Les batiments changent selon la nature de la zone.
 */
export function ZoneSettlement({ area, zone, index }: { area: AreaLayout; zone: Zone; index: number }) {
  const len = Math.hypot(area.center[0], area.center[1]) || 1;
  const ux = area.center[0] / len;
  const uz = area.center[1] / len;
  const tx = -uz;
  const tz = ux;

  // Place du village, en retrait des herbes hautes vers le Sanctuaire.
  const bx = area.center[0] - ux * 22;
  const bz = area.center[1] - uz * 22;
  const faceOut = Math.atan2(ux, uz);

  const primary = area.propKind === "cactus" ? "bld_market" : area.propKind === "runes" ? "bld_library" : area.propKind === "rochers" ? "bld_forge" : "bld_herb";
  const secondary = index % 2 ? "bld_market" : "bld_library";

  const buildings: { name: string; p: [number, number, number]; r: number; h: number }[] = [
    { name: primary, p: [bx + tx * 5.2, 0, bz + tz * 5.2], r: faceOut - 0.35, h: 5.2 },
    { name: secondary, p: [bx - tx * 5.2, 0, bz - tz * 5.2], r: faceOut + 0.35, h: 5 },
    { name: index % 3 === 0 ? "bld_forge" : "bld_herb", p: [bx - ux * 4.8, 0, bz - uz * 4.8], r: faceOut + Math.PI, h: 4.4 },
  ];

  return (
    <group>
      {/* place centrale pavee */}
      <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[bx, 0.025, bz]}>
        <circleGeometry args={[8.5, 20]} />
        <meshStandardMaterial color="#595260" roughness={0.9} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[bx, 0.04, bz]}>
        <ringGeometry args={[7.8, 8.2, 28]} />
        <meshBasicMaterial color={zone.hue} transparent opacity={0.28} />
      </mesh>

      {buildings.map((b, i) => (
        <Suspense key={`${b.name}-${i}`} fallback={<group position={b.p}>{fallback}</group>}>
          <NormalizedBuilding name={b.name} position={b.p} rotationY={b.r} height={b.h} />
        </Suspense>
      ))}

      {/* lampadaires runiques autour de la place */}
      {[-1, 1].flatMap((sx) =>
        [-1, 1].map((sz) => (
          <group key={`${sx}-${sz}`} position={[bx + tx * sx * 6.2 + ux * sz * 3.2, 0, bz + tz * sx * 6.2 + uz * sz * 3.2]}>
            <mesh castShadow position={[0, 1.25, 0]}>
              <cylinderGeometry args={[0.07, 0.12, 2.5, 8]} />
              <meshStandardMaterial color="#282638" roughness={0.6} metalness={0.4} />
            </mesh>
            <mesh position={[0, 2.6, 0]}>
              <octahedronGeometry args={[0.18]} />
              <meshStandardMaterial color={zone.hue} emissive={zone.hue} emissiveIntensity={1.8} />
            </mesh>
            <pointLight position={[0, 2.6, 0]} color={zone.hue} intensity={5} distance={8} decay={2} />
          </group>
        ))
      )}
    </group>
  );
}

/** Temple / arene monumentale placee derriere l'autel du champion. */
export function ZoneArena({ area, zone, final }: { area: AreaLayout; zone: Zone; final: boolean }) {
  const len = Math.hypot(area.altar[0], area.altar[1]) || 1;
  const ux = area.altar[0] / len;
  const uz = area.altar[1] / len;
  const px = area.altar[0] + ux * 7.5;
  const pz = area.altar[1] + uz * 7.5;
  const rotationY = Math.atan2(-ux, -uz);
  const building = final ? "temple" : area.propKind === "runes" ? "lmk_ruins" : "altar2";

  return (
    <group>
      <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[px, 0.025, pz]}>
        <circleGeometry args={[7.5, 28]} />
        <meshStandardMaterial color="#292735" roughness={0.8} />
      </mesh>
      <Suspense fallback={<group position={[px, 0, pz]}>{fallback}</group>}>
        <NormalizedBuilding name={building} position={[px, 0, pz]} rotationY={rotationY} height={final ? 9.5 : 7.2} />
      </Suspense>
      {final && (
        <>
          <pointLight position={[px, 6, pz]} color={zone.hue} intensity={24} distance={22} decay={2} />
          <mesh position={[px, 8.4, pz]} rotation={[0, rotationY, 0]}>
            <torusGeometry args={[1.1, 0.1, 10, 32]} />
            <meshStandardMaterial color={zone.hue} emissive={zone.hue} emissiveIntensity={2.2} />
          </mesh>
        </>
      )}
    </group>
  );
}

export function BattleArchitecture({ tint, boss }: { tint: string; boss: boolean }) {
  const columns: [number, number, number][] = [
    [-7, 0, -3.5],
    [7, 0, -3.5],
    [-8.5, 0, 1.5],
    [8.5, 0, 1.5],
  ];
  return (
    <group>
      <Suspense fallback={null}>
        <NormalizedBuilding name={boss ? "temple" : "lmk_ruins"} position={[0, 0, -10.5]} rotationY={0} height={boss ? 9.5 : 6.5} />
        {columns.map((p, i) => (
          <NormalizedBuilding key={i} name="wld_column" position={p} rotationY={i * 0.4} height={4.8 + (i % 2) * 0.7} />
        ))}
      </Suspense>
      {columns.slice(0, 2).map((p, i) => (
        <group key={`fire-${i}`} position={[p[0], 0, p[2] + 1.2]}>
          <mesh castShadow position={[0, 0.45, 0]}>
            <cylinderGeometry args={[0.45, 0.32, 0.7, 10]} />
            <meshStandardMaterial color="#282634" metalness={0.45} roughness={0.4} />
          </mesh>
          <mesh position={[0, 1.1, 0]}>
            <coneGeometry args={[0.28, 0.9, 7]} />
            <meshStandardMaterial color={tint} emissive={tint} emissiveIntensity={2.6} transparent opacity={0.92} />
          </mesh>
          <pointLight position={[0, 1.2, 0]} color={tint} intensity={12} distance={10} decay={2} />
        </group>
      ))}
    </group>
  );
}

// Les batiments KayKit restent charges par Suspense des que la place/arene
// correspondante monte a l'ecran. Aucun prechargement agressif au lancement.
