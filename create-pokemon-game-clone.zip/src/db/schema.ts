import { pgTable, uuid, varchar, boolean, jsonb, timestamp, index } from "drizzle-orm/pg-core";

/**
 * Sauvegardes de parties VALDORIA.
 * L'etat complet de la partie (equipe, reserve, inventaire, emblemes...)
 * est stocke en JSONB pour rester flexible.
 */
export const gameSaves = pgTable(
  "game_saves",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerName: varchar("player_name", { length: 40 }).notNull(),
    champion: boolean("champion").notNull().default(false),
    state: jsonb("state").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("game_saves_updated_idx").on(table.updatedAt)]
);

export type GameSaveRow = typeof gameSaves.$inferSelect;
