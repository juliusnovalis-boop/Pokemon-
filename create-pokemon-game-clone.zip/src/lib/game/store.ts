"use client";

import { create } from "zustand";
import type {
  BattleState,
  ItemId,
  LogLine,
  OwnedCreature,
  SaveMeta,
  SaveState,
} from "./types";
import { getSpecies } from "./data/species";
import { getRegion, getZone, isFinalZone } from "./data/regions";
import { getMove } from "./data/moves";
import {
  ITEMS,
  STATUS_LABEL,
  TEAM_LIMIT,
  aiChooseMove,
  applyXp,
  burnChip,
  catchRoll,
  createOwned,
  effSpd,
  effText,
  maxHpOf,
  resolveAttack,
  xpReward,
} from "./engine";

export type Screen = "title" | "starter" | "overworld" | "battle";

let logId = 1;
const line = (text: string, tone?: LogLine["tone"]): LogLine => ({ id: logId++, text, tone });

let persistTimer: ReturnType<typeof setTimeout> | null = null;

interface GameStore {
  screen: Screen;
  pendingStarterName: string;
  saveId: string | null;
  state: SaveState | null;
  battle: BattleState | null;
  saves: SaveMeta[];
  notice: string | null;

  setNotice: (n: string | null) => void;
  goStarter: (name: string) => void;
  backToTitle: () => void;

  fetchSaves: () => Promise<void>;
  createGame: (starterId: string, regionId: string) => Promise<void>;
  loadGame: (id: string) => Promise<void>;
  deleteGame: (id: string) => Promise<void>;
  persist: () => void;

  startWild: (zoneId: string) => void;
  startBoss: (zoneId: string) => void;
  actMove: (moveId: string) => void;
  actItem: (itemId: ItemId) => void;
  actSwitch: (uidTarget: string) => void;
  actRun: () => void;
  finishBattle: () => void;

  buy: (itemId: ItemId) => void;
  healAtSanctuary: () => void;
  deposit: (uidTarget: string) => void;
  withdraw: (uidTarget: string) => void;
}

function emptyState(playerName: string, starterId: string, regionId: string): SaveState {
  return {
    playerName,
    region: regionId,
    eclats: 120,
    team: [createOwned(starterId, 5)],
    box: [],
    items: { orbe: 5, potion: 2, "super-orbe": 0, "hyper-orbe": 0, elixir: 0 },
    badges: [],
    champion: false,
    totals: { captures: 0, victories: 0, defaites: 0 },
  };
}

function clone<T>(v: T): T {
  return structuredClone(v);
}

export const useGame = create<GameStore>((set, get) => {
  /** Applique la fin de tour (brûlures) et retourne les lignes générées. */
  function endOfTurnChip(
    b: BattleState,
    state: SaveState,
    lines: LogLine[]
  ): void {
    const player = state.team[b.playerIndex];
    const enemy = b.enemyTeam[b.enemyIndex];
    const pairs: [OwnedCreature, "player" | "enemy"][] = [];
    if (player && player.hp > 0) pairs.push([player, "player"]);
    if (enemy && enemy.hp > 0 && !b.over) pairs.push([enemy, "enemy"]);
    for (const [c, side] of pairs) {
      if (c.status === "brulure" && c.hp > 0) {
        const chip = burnChip(c);
        c.hp = Math.max(0, c.hp - chip);
        lines.push(line(`${getSpecies(c.speciesId).name} souffre de sa brûlure (-${chip} PV).`, "warn"));
        if (c.hp <= 0) handleFaint(b, state, c, side, lines);
      }
    }
  }

  function handleFaint(
    b: BattleState,
    state: SaveState,
    fallen: OwnedCreature,
    side: "player" | "enemy",
    lines: LogLine[]
  ): void {
    const name = getSpecies(fallen.speciesId).name;
    if (side === "enemy") {
      lines.push(line(`${name} ennemi est K.O. !`, "good"));
      const active = state.team[b.playerIndex];
      if (active.hp > 0) {
        const reward = xpReward(fallen.level, getSpecies(fallen.speciesId).xpYield, b.kind === "boss");
        const res = applyXp(active, reward);
        state.team[b.playerIndex] = res.creature;
        lines.push(line(`${getSpecies(active.speciesId).name} gagne ${reward} XP.`, "info"));
        if (res.levelsGained > 0) lines.push(line(`${getSpecies(active.speciesId).name} monte au niveau ${res.creature.level} !`, "good"));
        for (const m of res.learned) lines.push(line(`${getSpecies(active.speciesId).name} apprend ${m} !`, "good"));
      }
      const next = b.enemyIndex + 1;
      if (next < b.enemyTeam.length) {
        b.enemyIndex = next;
        const nxt = b.enemyTeam[next];
        lines.push(line(`${b.bossName ?? "L'adversaire"} envoie ${getSpecies(nxt.speciesId).name} (niv. ${nxt.level}) !`, "bad"));
      } else if (!b.over) {
        b.over = "win";
        lines.push(line(b.kind === "boss" ? `${b.bossName} est vaincu !` : "Victoire !", "good"));
      }
    } else {
      lines.push(line(`${name} est K.O. !`, "bad"));
      const alive = state.team.some((c) => c.hp > 0);
      if (alive) {
        b.awaitingSwitch = true;
      } else if (!b.over) {
        b.over = "lose";
        lines.push(line("Toute ton équipe est K.O.…", "bad"));
      }
    }
  }

  /** Exécute une attaque d'un camp vers l'autre (gère actions/effets). */
  function performAttack(
    b: BattleState,
    state: SaveState,
    attackerSide: "player" | "enemy",
    moveId: string,
    lines: LogLine[]
  ): void {
    const attacker = attackerSide === "player" ? state.team[b.playerIndex] : b.enemyTeam[b.enemyIndex];
    const defender = attackerSide === "player" ? b.enemyTeam[b.enemyIndex] : state.team[b.playerIndex];
    if (!attacker || !defender || attacker.hp <= 0 || defender.hp <= 0 || b.over) return;

    const aName = getSpecies(attacker.speciesId).name + (attackerSide === "enemy" ? " ennemi" : "");
    if (attacker.status === "paralysie" && Math.random() < 0.25) {
      lines.push(line(`${aName} est paralysé ! Il ne peut pas bouger.`, "warn"));
      return;
    }
    const move = getMove(moveId);
    const dName = getSpecies(defender.speciesId).name + (attackerSide === "player" ? " ennemi" : "");
    const hit = resolveAttack(attacker, defender, moveId);
    if (hit.missed) {
      lines.push(line(`${aName} utilise ${move.name}… mais échoue !`, "warn"));
      return;
    }
    defender.hp = Math.max(0, defender.hp - hit.dmg);
    b.lastHit = { side: attackerSide === "player" ? "enemy" : "player", dmg: hit.dmg, eff: hit.eff, key: logId };
    lines.push(line(`${aName} utilise ${move.name} ! (-${hit.dmg} PV)`, attackerSide === "player" ? "info" : "bad"));
    if (hit.crit) lines.push(line("Coup critique !", "warn"));
    const effMsg = effText(hit.eff);
    if (effMsg) lines.push(line(effMsg, hit.eff >= 2 ? "good" : "warn"));
    if (hit.statusInflicted && defender.hp > 0) {
      defender.status = hit.statusInflicted;
      lines.push(line(`${dName} subit : ${STATUS_LABEL[hit.statusInflicted]} !`, "warn"));
    }
    if (defender.hp <= 0) {
      handleFaint(b, state, defender, attackerSide === "player" ? "enemy" : "player", lines);
    }
  }

  /** L'ennemi riposte (utilisé après objet/changement). */
  function enemyCounter(b: BattleState, state: SaveState, lines: LogLine[]): void {
    const enemy = b.enemyTeam[b.enemyIndex];
    if (!enemy || enemy.hp <= 0 || b.over || b.awaitingSwitch) return;
    performAttack(b, state, "enemy", aiChooseMove(enemy), lines);
  }

  function appendLog(b: BattleState, lines: LogLine[]): LogLine[] {
    return [...b.log, ...lines].slice(-40);
  }

  return {
    screen: "title",
    pendingStarterName: "",
    saveId: null,
    state: null,
    battle: null,
    saves: [],
    notice: null,

    setNotice: (n) => set({ notice: n }),
    goStarter: (name) => set({ screen: "starter", pendingStarterName: name.trim() || "Nova" }),
    backToTitle: () => set({ screen: "title", state: null, saveId: null, battle: null }),

    /* ------------------------------- Sauvegarde ------------------------------ */

    fetchSaves: async () => {
      try {
        const res = await fetch("/api/saves", { cache: "no-store" });
        if (res.ok) set({ saves: await res.json() });
      } catch {
        /* silencieux */
      }
    },

    createGame: async (starterId, regionId) => {
      const { pendingStarterName } = get();
      const region = getRegion(regionId);
      if (!region.starters.includes(starterId)) return;
      const state = emptyState(pendingStarterName || "Nova", starterId, region.id);
      const res = await fetch("/api/saves", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ state }),
      });
      if (!res.ok) return;
      const created = (await res.json()) as { id: string };
      set({ saveId: created.id, state, screen: "overworld", notice: `Bienvenue à Valdoria, ${state.playerName} ! Ton aventure commence.` });
    },

    loadGame: async (id) => {
      const res = await fetch(`/api/saves/${id}`, { cache: "no-store" });
      if (!res.ok) return;
      const row = (await res.json()) as { id: string; state: SaveState };
      const st = row.state;
      if (!st.region) st.region = "afikala";
      set({ saveId: row.id, state: st, screen: "overworld", notice: null });
    },

    deleteGame: async (id) => {
      await fetch(`/api/saves/${id}`, { method: "DELETE" });
      await get().fetchSaves();
    },

    persist: () => {
      const { saveId, state } = get();
      if (!saveId || !state) return;
      if (persistTimer) clearTimeout(persistTimer);
      persistTimer = setTimeout(async () => {
        const s = get();
        if (!s.saveId || !s.state) return;
        try {
          await fetch(`/api/saves/${s.saveId}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ state: s.state }),
          });
        } catch {
          /* silencieux */
        }
      }, 800);
    },

    /* --------------------------------- Combat -------------------------------- */

    startWild: (zoneId) => {
      const { state } = get();
      if (!state || state.team.every((c) => c.hp <= 0)) {
        set({ notice: "Tes créatures sont épuisées. Passe d'abord par le Sanctuaire !" });
        return;
      }
      const zone = getZone(state.region, zoneId);
      const totalW = zone.wilds.reduce((a, w) => a + w.weight, 0);
      let r = Math.random() * totalW;
      let speciesId = zone.wilds[0].speciesId;
      for (const w of zone.wilds) {
        r -= w.weight;
        if (r <= 0) {
          speciesId = w.speciesId;
          break;
        }
      }
      const [lo, hi] = zone.levelRange;
      const lvl = lo + Math.floor(Math.random() * (hi - lo + 1));
      const wild = createOwned(speciesId, lvl);
      const playerIndex = state.team.findIndex((c) => c.hp > 0);
      set({
        screen: "battle",
        battle: {
          kind: "wild",
          zoneId,
          enemyTeam: [wild],
          enemyIndex: 0,
          playerIndex,
          turn: 1,
          log: [line(`Un ${getSpecies(speciesId).name} sauvage surgit ! (niv. ${lvl})`, "bad")],
          awaitingSwitch: false,
          over: null,
        },
      });
    },

    startBoss: (zoneId) => {
      const { state } = get();
      if (!state) return;
      if (state.team.every((c) => c.hp <= 0)) {
        set({ notice: "Tes créatures sont épuisées. Passe d'abord par le Sanctuaire !" });
        return;
      }
      const zone = getZone(state.region, zoneId);
      if (state.badges.includes(zoneId)) return;
      const team = zone.boss.team.map((t) => createOwned(t.speciesId, t.level));
      const playerIndex = state.team.findIndex((c) => c.hp > 0);
      set({
        screen: "battle",
        battle: {
          kind: "boss",
          zoneId,
          bossName: zone.boss.name,
          bossTitle: zone.boss.title,
          enemyTeam: team,
          enemyIndex: 0,
          playerIndex,
          turn: 1,
          log: [
            line(`${zone.boss.name}, ${zone.boss.title}, se dresse devant toi.`, "bad"),
            line(`« ${zone.boss.quote} »`, "info"),
          ],
          awaitingSwitch: false,
          over: null,
        },
      });
    },

    actMove: (moveId) => {
      const { battle, state } = get();
      if (!battle || !state || battle.over || battle.awaitingSwitch) return;
      const b = clone(battle);
      const s = clone(state);
      const lines: LogLine[] = [];
      const player = s.team[b.playerIndex];
      const enemy = b.enemyTeam[b.enemyIndex];
      if (!player || player.hp <= 0 || !enemy) return;

      const playerFirst = effSpd(player) >= effSpd(enemy);
      if (playerFirst) {
        performAttack(b, s, "player", moveId, lines);
        if (!b.over && !b.awaitingSwitch) performAttack(b, s, "enemy", aiChooseMove(enemy), lines);
      } else {
        performAttack(b, s, "enemy", aiChooseMove(enemy), lines);
        if (!b.over && !b.awaitingSwitch) performAttack(b, s, "player", moveId, lines);
      }
      if (!b.over && !b.awaitingSwitch) endOfTurnChip(b, s, lines);
      b.turn += 1;
      b.log = appendLog(b, lines);
      set({ battle: b, state: s });
      get().persist();
    },

    actItem: (itemId) => {
      const { battle, state } = get();
      if (!battle || !state || battle.over || battle.awaitingSwitch) return;
      const count = state.items[itemId] ?? 0;
      if (count <= 0) return;
      const b = clone(battle);
      const s = clone(state);
      const lines: LogLine[] = [];
      const item = ITEMS[itemId];
      const enemy = b.enemyTeam[b.enemyIndex];
      s.items[itemId] = count - 1;

      if (item.kind === "orbe") {
        if (b.kind !== "wild") {
          lines.push(line("Impossible de capturer la créature d'un Gardien !", "warn"));
          s.items[itemId] = count; // pas consommé
        } else if (enemy) {
          const roll = catchRoll(itemId, enemy);
          b.catchAnim = (b.catchAnim ?? 0) + 1;
          lines.push(line(`${s.playerName} lance une ${item.name} !`, "info"));
          lines.push(line(roll.shakes === 0 ? "L'Orbe ne tremble même pas…" : roll.shakes === 1 ? "L'Orbe tremble une fois…" : roll.shakes === 2 ? "L'Orbe tremble deux fois…" : "L'Orbe tremble trois fois…", "info"));
          if (roll.success) {
            const healed: OwnedCreature = { ...enemy, status: null };
            if (s.team.length < TEAM_LIMIT) {
              s.team.push(healed);
              lines.push(line(`${getSpecies(enemy.speciesId).name} rejoint ton équipe !`, "good"));
            } else {
              s.box.push(healed);
              lines.push(line(`${getSpecies(enemy.speciesId).name} est envoyé à la Réserve.`, "good"));
            }
            s.totals.captures += 1;
            b.over = "caught";
          } else {
            lines.push(line(`Zut ! ${getSpecies(enemy.speciesId).name} s'est échappé.`, "bad"));
            enemyCounter(b, s, lines);
            if (!b.over && !b.awaitingSwitch) endOfTurnChip(b, s, lines);
          }
        }
      } else {
        const active = s.team[b.playerIndex];
        const max = maxHpOf(active);
        if (active.hp >= max) {
          lines.push(line(`${getSpecies(active.speciesId).name} a déjà tous ses PV.`, "warn"));
          s.items[itemId] = count;
        } else {
          active.hp = Math.min(max, active.hp + (item.heal ?? 0));
          lines.push(line(`${item.name} restaure les PV de ${getSpecies(active.speciesId).name}. (+${item.heal})`, "good"));
          enemyCounter(b, s, lines);
          if (!b.over && !b.awaitingSwitch) endOfTurnChip(b, s, lines);
        }
      }
      b.turn += 1;
      b.log = appendLog(b, lines);
      set({ battle: b, state: s });
      get().persist();
    },

    actSwitch: (uidTarget) => {
      const { battle, state } = get();
      if (!battle || !state || battle.over) return;
      const idx = state.team.findIndex((c) => c.uid === uidTarget && c.hp > 0);
      if (idx < 0 || idx === battle.playerIndex) return;
      const b = clone(battle);
      const s = clone(state);
      const lines: LogLine[] = [];
      const wasForced = b.awaitingSwitch;
      const prev = s.team[b.playerIndex];
      b.playerIndex = idx;
      b.awaitingSwitch = false;
      if (wasForced) {
        lines.push(line(`${getSpecies(s.team[idx].speciesId).name} entre en scène !`, "info"));
      } else {
        lines.push(line(`${getSpecies(prev.speciesId).name}, reviens ! ${getSpecies(s.team[idx].speciesId).name}, à toi !`, "info"));
        enemyCounter(b, s, lines);
        if (!b.over && !b.awaitingSwitch) endOfTurnChip(b, s, lines);
      }
      b.turn += 1;
      b.log = appendLog(b, lines);
      set({ battle: b, state: s });
      get().persist();
    },

    actRun: () => {
      const { battle } = get();
      if (!battle || battle.over || battle.kind !== "wild") return;
      const b = clone(battle);
      b.over = "flee";
      b.log = appendLog(b, [line("Tu t'échappes sans histoire.", "info")]);
      set({ battle: b });
    },

    finishBattle: () => {
      const { battle, state } = get();
      if (!battle || !battle.over || !state) return;
      const s = clone(state);
      let notice: string | null = null;
      if (battle.over === "win") {
        s.totals.victories += 1;
        if (battle.kind === "boss") {
          const zone = getZone(s.region, battle.zoneId);
          if (!s.badges.includes(zone.id)) s.badges.push(zone.id);
          s.eclats += zone.boss.reward;
          notice = `${zone.boss.badge} obtenu ! (+${zone.boss.reward} éclats)`;
          if (isFinalZone(s.region, battle.zoneId) && !s.champion) {
            s.champion = true;
            notice = `${zone.boss.badge} ! Tu es Maître·sse d'${getRegion(s.region).name} — la ${getRegion(s.region).professor.split(" ")[1] ?? "région"} te salue !`;
          }
        } else {
          const gain = 15 + Math.floor(Math.random() * 21);
          s.eclats += gain;
          notice = `Victoire ! +${gain} éclats.`;
        }
      } else if (battle.over === "caught") {
        notice = "Capture réussie ! Consulte ton équipe ou ta Réserve.";
      } else if (battle.over === "lose") {
        s.totals.defaites += 1;
        const loss = Math.floor(s.eclats * 0.1);
        s.eclats -= loss;
        s.team = s.team.map((c) => ({ ...c, hp: maxHpOf(c), status: null }));
        notice = `Tu as été ramené·e au Sanctuaire (-${loss} éclats). Ton équipe est soignée.`;
      }
      set({ battle: null, screen: "overworld", state: s, notice });
      get().persist();
    },

    /* ------------------------------- Hub actions ------------------------------ */

    buy: (itemId) => {
      const { state } = get();
      if (!state) return;
      const item = ITEMS[itemId];
      if (state.eclats < item.price) {
        set({ notice: "Pas assez d'éclats pour cet objet." });
        return;
      }
      const s = clone(state);
      s.eclats -= item.price;
      s.items[itemId] = (s.items[itemId] ?? 0) + 1;
      set({ state: s, notice: `${item.name} acheté !` });
      get().persist();
    },

    healAtSanctuary: () => {
      const { state } = get();
      if (!state) return;
      const s = clone(state);
      s.team = s.team.map((c) => ({ ...c, hp: maxHpOf(c), status: null }));
      set({ state: s, notice: "Ton équipe est entièrement soignée." });
      get().persist();
    },

    deposit: (uidTarget) => {
      const { state } = get();
      if (!state || state.team.length <= 1) {
        set({ notice: "Tu dois garder au moins une créature dans ton équipe." });
        return;
      }
      const s = clone(state);
      const idx = s.team.findIndex((c) => c.uid === uidTarget);
      if (idx < 0) return;
      s.box.push(s.team[idx]);
      s.team.splice(idx, 1);
      set({ state: s });
      get().persist();
    },

    withdraw: (uidTarget) => {
      const { state } = get();
      if (!state || state.team.length >= TEAM_LIMIT) {
        set({ notice: "Ton équipe est pleine (6 créatures)." });
        return;
      }
      const s = clone(state);
      const idx = s.box.findIndex((c) => c.uid === uidTarget);
      if (idx < 0) return;
      s.team.push(s.box[idx]);
      s.box.splice(idx, 1);
      set({ state: s });
      get().persist();
    },
  };
});
