import { getSpecies } from "./data/species";
import { getMove } from "./data/moves";
import { effectiveness } from "./data/chart";
import type { ItemId, OwnedCreature, Species, Stats, StatusKind } from "./types";

export const MAX_LEVEL = 40;
export const TEAM_LIMIT = 6;

/* ---------------------------------- Stats --------------------------------- */

export function statsFor(sp: Species, level: number): Stats {
  const other = (b: number) => Math.floor((b * 2 * level) / 100) + 5;
  return {
    hp: Math.floor((sp.base.hp * 2 * level) / 100) + level + 10,
    atk: other(sp.base.atk),
    def: other(sp.base.def),
    spd: other(sp.base.spd),
  };
}

export function maxHpOf(o: OwnedCreature): number {
  return statsFor(getSpecies(o.speciesId), o.level).hp;
}

/** Statistiques effectives (statuts appliqués). */
export function effAtk(o: OwnedCreature): number {
  const s = statsFor(getSpecies(o.speciesId), o.level);
  return o.status === "brulure" ? Math.max(1, Math.floor(s.atk / 2)) : s.atk;
}
export function effDef(o: OwnedCreature): number {
  return statsFor(getSpecies(o.speciesId), o.level).def;
}
export function effSpd(o: OwnedCreature): number {
  const s = statsFor(getSpecies(o.speciesId), o.level);
  return o.status === "paralysie" ? Math.max(1, Math.floor(s.spd / 2)) : s.spd;
}

/* ------------------------------ Création / XP ------------------------------ */

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

/** Capacités connues à un niveau donné : les 4 plus récentes du learnset. */
export function movesForLevel(sp: Species, level: number): string[] {
  const known = sp.learnset.filter((l) => l.level <= level).map((l) => l.move);
  return Array.from(new Set(known)).slice(-4);
}

export function createOwned(speciesId: string, level: number): OwnedCreature {
  const sp = getSpecies(speciesId);
  const max = statsFor(sp, level).hp;
  return { uid: uid(), speciesId, level, xp: 0, hp: max, moves: movesForLevel(sp, level), status: null };
}

export function xpNeeded(level: number): number {
  return 20 + level * level * 6;
}

export function xpReward(enemyLevel: number, xpYield: number, isBoss: boolean): number {
  const base = Math.max(8, Math.round((xpYield * enemyLevel) / 5));
  return Math.round(base * (isBoss ? 1.5 : 1));
}

export interface XpResult {
  creature: OwnedCreature;
  levelsGained: number;
  learned: string[]; // noms de capacités apprises
}

export function applyXp(o: OwnedCreature, amount: number): XpResult {
  const sp = getSpecies(o.speciesId);
  let c: OwnedCreature = { ...o, xp: o.xp + amount };
  let levelsGained = 0;
  const learned: string[] = [];
  while (c.level < MAX_LEVEL && c.xp >= xpNeeded(c.level)) {
    c = { ...c, xp: c.xp - xpNeeded(c.level), level: c.level + 1 };
    levelsGained++;
    // gain de PV maximum ajouté aux PV actuels
    c.hp = Math.min(statsFor(sp, c.level).hp, c.hp + (statsFor(sp, c.level).hp - statsFor(sp, c.level - 1).hp));
    // apprentissage
    for (const l of sp.learnset) {
      if (l.level === c.level && !c.moves.includes(l.move)) {
        if (c.moves.length < 4) {
          c = { ...c, moves: [...c.moves, l.move] };
          learned.push(getMove(l.move).name);
        }
      }
    }
  }
  if (c.level >= MAX_LEVEL) c = { ...c, xp: 0 };
  return { creature: c, levelsGained, learned };
}

/* --------------------------------- Combat --------------------------------- */

export interface HitResult {
  missed: boolean;
  dmg: number;
  eff: number;
  crit: boolean;
  statusInflicted: StatusKind | null;
}

export function resolveAttack(attacker: OwnedCreature, defender: OwnedCreature, moveId: string): HitResult {
  const move = getMove(moveId);
  const rand = Math.random;
  if (rand() * 100 > move.accuracy) {
    return { missed: true, dmg: 0, eff: 1, crit: false, statusInflicted: null };
  }
  const spA = getSpecies(attacker.speciesId);
  const spD = getSpecies(defender.speciesId);
  const eff = effectiveness(move.type, spD.type);
  const stab = move.type === spA.type ? 1.5 : 1;
  const crit = rand() < 0.0625;
  const base = Math.floor(Math.floor(((2 * attacker.level) / 5 + 2) * move.power * (effAtk(attacker) / Math.max(1, effDef(defender)))) / 50) + 2;
  const variance = 0.85 + rand() * 0.15;
  const dmg = Math.max(1, Math.floor(base * stab * eff * (crit ? 1.5 : 1) * variance * (eff === 0 ? 0.5 : 1)));
  let statusInflicted: StatusKind | null = null;
  if (move.status && !defender.status && rand() * 100 < move.status.chance && eff > 0) {
    statusInflicted = move.status.kind;
  }
  return { missed: false, dmg, eff, crit, statusInflicted };
}

/** Dégâts de brûlure en fin de tour. */
export function burnChip(o: OwnedCreature): number {
  return Math.max(1, Math.floor(maxHpOf(o) / 8));
}

/** Choix de capacité de l'IA (pondéré par la puissance). */
export function aiChooseMove(o: OwnedCreature): string {
  const pool = o.moves.length ? o.moves : ["charge"];
  const weights = pool.map((m) => getMove(m).power + 20);
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < pool.length; i++) {
    r -= weights[i];
    if (r <= 0) return pool[i];
  }
  return pool[pool.length - 1];
}

/* -------------------------------- Capture --------------------------------- */

export const CATCH_BONUS: Partial<Record<ItemId, number>> = {
  orbe: 0,
  "super-orbe": 0.15,
  "hyper-orbe": 0.3,
};

export function catchChance(orb: ItemId, target: OwnedCreature): number {
  const sp = getSpecies(target.speciesId);
  const hpFactor = 1 - target.hp / Math.max(1, maxHpOf(target));
  const bonus = (CATCH_BONUS[orb] ?? 0) + (target.status ? 0.12 : 0);
  return Math.min(0.95, Math.max(0.04, sp.catchRate * 0.5 + hpFactor * 0.55 + bonus - target.level * 0.003));
}

export function catchRoll(orb: ItemId, target: OwnedCreature): { success: boolean; shakes: number; chance: number } {
  const chance = catchChance(orb, target);
  const success = Math.random() < chance;
  return { success, shakes: success ? 3 : Math.floor(Math.random() * 3), chance };
}

/* --------------------------------- Objets ---------------------------------- */

export const ITEMS: Record<ItemId, { name: string; desc: string; price: number; kind: "orbe" | "soin"; heal?: number }> = {
  orbe: { name: "Orbe d'Éther", desc: "L'orbe standard des dresseurs.", price: 60, kind: "orbe" },
  "super-orbe": { name: "Super Orbe", desc: "Un alliage plus stable. +15 % de capture.", price: 150, kind: "orbe" },
  "hyper-orbe": { name: "Hyper Orbe", desc: "Précision gravée de runes. +30 % de capture.", price: 320, kind: "orbe" },
  potion: { name: "Potion d'Aurore", desc: "Restaure 30 PV.", price: 80, kind: "soin", heal: 30 },
  elixir: { name: "Élixir Majeur", desc: "Restaure 90 PV.", price: 180, kind: "soin", heal: 90 },
};

export const STATUS_LABEL: Record<StatusKind, string> = {
  brulure: "Brûlure",
  paralysie: "Paralysie",
};

export function effText(eff: number): string | null {
  if (eff >= 2) return "C'est super efficace !";
  if (eff <= 0.5) return "Ce n'est pas très efficace…";
  return null;
}
