import type { Region } from "../types";

/**
 * Disposition spatiale de l'ile-monde de Valdoria (3D).
 * L'ile est un disque ; les secteurs des zones de la region choisie sont
 * disposes en cercle autour du Sanctuaire central.
 */

export const ISLAND_RADIUS = 96;
export const SANCTUARY_POS: [number, number] = [0, 0];

export interface AreaLayout {
  zoneId: string;
  center: [number, number];
  altar: [number, number];
  patchRadius: number;
  ground: string;
  foliage: string;
  accent: string;
  propKind: "arbres" | "cristaux" | "rochers" | "champignons" | "cactus" | "runes";
}

function polar(angleDeg: number, radius: number): [number, number] {
  const a = (angleDeg * Math.PI) / 180;
  return [Math.cos(a) * radius, Math.sin(a) * radius];
}

/** Calcule les secteurs 3D pour la region donnee. */
export function getAreas(region: Region): AreaLayout[] {
  return region.zones.map((zone, i) => {
    const angle = (i * 360) / region.zones.length;
    return {
      zoneId: zone.id,
      center: polar(angle, 62),
      altar: polar(angle, 80),
      patchRadius: 15,
      ground: zone.ground ?? "#33402a",
      foliage: zone.foliage ?? "#7fae5a",
      accent: zone.hue,
      propKind: zone.propKind ?? "arbres",
    };
  });
}

export function getArea(areas: AreaLayout[], zoneId: string): AreaLayout | undefined {
  return areas.find((a) => a.zoneId === zoneId);
}

/* ------------------------- Aleatoire deterministe ------------------------- */

export function mulberry32(seed: number) {
  let t = seed >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export interface PropPlacement {
  pos: [number, number];
  scale: number;
  rot: number;
  variant: number;
}

/** Genere des positions pseudo-aleatoires autour du centre d'un secteur. */
export function scatter(area: AreaLayout, count: number, radius: number, seed: number): PropPlacement[] {
  const rnd = mulberry32(seed);
  const out: PropPlacement[] = [];
  for (let i = 0; i < count; i++) {
    const ang = rnd() * Math.PI * 2;
    const dist = Math.sqrt(rnd()) * radius;
    out.push({
      pos: [area.center[0] + Math.cos(ang) * dist, area.center[1] + Math.sin(ang) * dist],
      scale: 0.7 + rnd() * 0.8,
      rot: rnd() * Math.PI * 2,
      variant: Math.floor(rnd() * 3),
    });
  }
  return out;
}
