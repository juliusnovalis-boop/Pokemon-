import type { MoveDef } from "../types";

export const MOVES: Record<string, MoveDef> = {
  charge: { id: "charge", name: "Charge", type: "normal", power: 40, accuracy: 100, desc: "Un choc direct et franc." },
  griffe: { id: "griffe", name: "Griffe Vive", type: "normal", power: 45, accuracy: 100, desc: "Des griffes aiguisées." },
  morsure: { id: "morsure", name: "Morsure", type: "normal", power: 55, accuracy: 95, desc: "Une morsure brutale." },

  braise: { id: "braise", name: "Braise", type: "feu", power: 40, accuracy: 100, status: { kind: "brulure", chance: 10 }, desc: "Une gerbe de braises chaudes." },
  "langue-feu": { id: "langue-feu", name: "Langue de Feu", type: "feu", power: 65, accuracy: 95, status: { kind: "brulure", chance: 10 }, desc: "Un fouet de flammes." },
  "souffle-ardent": { id: "souffle-ardent", name: "Souffle Ardent", type: "feu", power: 85, accuracy: 85, status: { kind: "brulure", chance: 15 }, desc: "Un torrent de feu pur." },

  ecume: { id: "ecume", name: "Jet d'Écume", type: "eau", power: 40, accuracy: 100, desc: "Un jet d'eau bouillonnant." },
  "lame-onde": { id: "lame-onde", name: "Lame d'Onde", type: "eau", power: 65, accuracy: 95, desc: "Une lame d'eau tranchante." },
  cascade: { id: "cascade", name: "Cascade Fracassante", type: "eau", power: 85, accuracy: 85, desc: "Le poids d'une chute d'eau." },

  "fouet-liane": { id: "fouet-liane", name: "Fouet Liane", type: "plante", power: 40, accuracy: 100, desc: "Une liane claque l'air." },
  "lames-feuilles": { id: "lames-feuilles", name: "Lames Feuilles", type: "plante", power: 60, accuracy: 95, desc: "Des feuilles affûtées comme des rasoirs." },
  "seve-solaire": { id: "seve-solaire", name: "Sève Solaire", type: "plante", power: 85, accuracy: 85, desc: "L'énergie du soleil concentrée." },

  decharge: { id: "decharge", name: "Décharge", type: "foudre", power: 45, accuracy: 100, status: { kind: "paralysie", chance: 15 }, desc: "Un arc électrique soudain." },
  "arc-foudre": { id: "arc-foudre", name: "Arc Foudroyant", type: "foudre", power: 70, accuracy: 95, status: { kind: "paralysie", chance: 10 }, desc: "La foudre guidée par la colère." },
  orage: { id: "orage", name: "Orage", type: "foudre", power: 90, accuracy: 80, status: { kind: "paralysie", chance: 20 }, desc: "Le ciel entier s'embrase." },

  "poudre-givre": { id: "poudre-givre", name: "Poudre Givrée", type: "glace", power: 45, accuracy: 100, desc: "Une poudre glaciale mordante." },
  "crocs-givre": { id: "crocs-givre", name: "Crocs de Givre", type: "glace", power: 65, accuracy: 95, desc: "Des crocs taillés dans la glace." },
  blizzard: { id: "blizzard", name: "Blizzard", type: "glace", power: 85, accuracy: 85, desc: "Une tempête de neige aveuglante." },

  "jet-pierres": { id: "jet-pierres", name: "Jet de Pierres", type: "roche", power: 50, accuracy: 100, desc: "Des pierres lancées avec force." },
  eboulement: { id: "eboulement", name: "Éboulement", type: "roche", power: 75, accuracy: 90, desc: "La falaise s'effondre." },
  "charge-granit": { id: "charge-granit", name: "Charge Granit", type: "roche", power: 90, accuracy: 80, desc: "Une charge pesant une tonne." },

  "ombre-mordante": { id: "ombre-mordante", name: "Ombre Mordante", type: "spectre", power: 50, accuracy: 100, desc: "L'ombre elle-même attaque." },
  "voile-obscur": { id: "voile-obscur", name: "Voile Obscur", type: "spectre", power: 70, accuracy: 95, desc: "Un voile de ténèbres étreint la proie." },
  "onde-spectrale": { id: "onde-spectrale", name: "Onde Spectrale", type: "spectre", power: 90, accuracy: 85, desc: "Une onde venue d'ailleurs." },

  rafale: { id: "rafale", name: "Rafale", type: "aerien", power: 40, accuracy: 100, desc: "Un coup de vent violent." },
  "pique-vent": { id: "pique-vent", name: "Piqué-Vent", type: "aerien", power: 65, accuracy: 95, desc: "Une descente en piqué fulgurante." },
  ouragan: { id: "ouragan", name: "Ouragan", type: "aerien", power: 85, accuracy: 85, desc: "Des vents à déraciner les arbres." },

  "draco-souffle": { id: "draco-souffle", name: "Draco-Souffle", type: "dragon", power: 75, accuracy: 95, desc: "Le souffle ancestral des drakes." },
  "ecaille-fracas": { id: "ecaille-fracas", name: "Écaille Fracassante", type: "dragon", power: 90, accuracy: 85, desc: "Un impact d'écailles d'onyx." },
};

export function getMove(id: string): MoveDef {
  const m = MOVES[id];
  if (!m) throw new Error(`Capacité inconnue: ${id}`);
  return m;
}
