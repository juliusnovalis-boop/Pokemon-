import type { TypeName } from "../types";

/** Multiplicateurs d'attaque : CHART[attaque][defense] (defaut = 1) */
export const TYPE_CHART: Record<TypeName, Partial<Record<TypeName, number>>> = {
  feu: { plante: 2, glace: 2, eau: 0.5, roche: 0.5, feu: 0.5, dragon: 0.5 },
  eau: { feu: 2, roche: 2, eau: 0.5, plante: 0.5, dragon: 0.5 },
  plante: { eau: 2, roche: 2, feu: 0.5, plante: 0.5, aerien: 0.5, glace: 0.5, dragon: 0.5 },
  foudre: { eau: 2, aerien: 2, plante: 0.5, foudre: 0.5, roche: 0.5, dragon: 0.5 },
  glace: { plante: 2, aerien: 2, dragon: 2, feu: 0.5, glace: 0.5, eau: 0.5 },
  roche: { feu: 2, glace: 2, aerien: 2, roche: 0.5 },
  spectre: { spectre: 2, normal: 0.5 },
  aerien: { plante: 2, foudre: 0.5, roche: 0.5, glace: 0.5 },
  dragon: { dragon: 2 },
  normal: { spectre: 0.5 },
};

export function effectiveness(moveType: TypeName, targetType: TypeName): number {
  return TYPE_CHART[moveType]?.[targetType] ?? 1;
}

export const TYPE_LABEL: Record<TypeName, string> = {
  feu: "Feu",
  eau: "Eau",
  plante: "Plante",
  foudre: "Foudre",
  glace: "Glace",
  roche: "Roche",
  spectre: "Spectre",
  aerien: "Aérien",
  dragon: "Dragon",
  normal: "Normal",
};

export const TYPE_COLOR: Record<TypeName, string> = {
  feu: "#ff7a45",
  eau: "#4aa3ff",
  plante: "#5fd98a",
  foudre: "#ffd23f",
  glace: "#8fd8ff",
  roche: "#c9a15a",
  spectre: "#b388ff",
  aerien: "#9db8ff",
  dragon: "#f0a23d",
  normal: "#cfd6e4",
};
