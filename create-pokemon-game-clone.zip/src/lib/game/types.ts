/**
 * Types centraux du jeu VALDORIA — Chroniques des Gardiens.
 * Univers, noms et creatures 100 % originaux.
 */

export type TypeName =
  | "feu"
  | "eau"
  | "plante"
  | "foudre"
  | "glace"
  | "roche"
  | "spectre"
  | "aerien"
  | "dragon"
  | "normal";

export type StatusKind = "brulure" | "paralysie";

export interface Stats {
  hp: number;
  atk: number;
  def: number;
  spd: number;
}

export interface MoveDef {
  id: string;
  name: string;
  type: TypeName;
  power: number;
  accuracy: number; // 0-100
  status?: { kind: StatusKind; chance: number }; // % d'infliger
  desc: string;
}

export interface SpeciesPalette {
  body: string;
  belly?: string;
  accent?: string;
  eye?: string;
}

export interface Species {
  id: string;
  name: string;
  type: TypeName;
  image?: string; // portrait 2D (si genere)
  /** gabarit de modele 3D procedural (si pas de corps sur-mesure) */
  template?:
    | "canine"
    | "feline"
    | "ursine"
    | "rodent"
    | "seal"
    | "serpent"
    | "bird"
    | "ghost"
    | "bovine"
    | "drake"
    | "golem";
  colors?: SpeciesPalette;
  base: Stats;
  catchRate: number; // 0..1 facilite de capture
  xpYield: number;
  desc: string;
  learnset: { level: number; move: string }[];
  rarity: "commun" | "rare" | "legendaire";
}

export interface OwnedCreature {
  uid: string;
  speciesId: string;
  level: number;
  xp: number; // progression vers le niveau suivant
  hp: number; // PV actuels
  moves: string[]; // ids, max 4
  status: StatusKind | null;
}

export type ItemId = "orbe" | "super-orbe" | "hyper-orbe" | "potion" | "elixir";

export type Inventory = Partial<Record<ItemId, number>>;

export interface SaveState {
  playerName: string;
  region: string; // id de la region choisie
  eclats: number;
  team: OwnedCreature[]; // max 6
  box: OwnedCreature[];
  items: Inventory;
  badges: string[]; // ids de zones vaincues
  champion: boolean;
  totals: { captures: number; victories: number; defaites: number };
}

export interface SaveMeta {
  id: string;
  playerName: string;
  champion: boolean;
  updatedAt: string;
  teamPreview: { speciesId: string; level: number }[];
}

export interface ZoneBoss {
  name: string;
  title: string;
  badge: string;
  team: { speciesId: string; level: number }[];
  reward: number;
  quote: string;
}

export interface Zone {
  id: string;
  name: string;
  subtitle: string;
  desc: string;
  minBadges: number;
  levelRange: [number, number];
  hue: string; // couleur principale (css)
  wilds: { speciesId: string; weight: number }[];
  boss: ZoneBoss;
  /** biome 3D du secteur */
  ground?: string;
  foliage?: string;
  propKind?: "arbres" | "cristaux" | "rochers" | "champignons" | "cactus" | "runes";
}

export interface Region {
  id: string;
  name: string;
  continent: string;
  tagline: string;
  lore: string;
  hue: string;
  emblem: string; // emoji interdit -> on utilise un code couleur + initiale
  starters: string[];
  villain: string; // team ennemie
  villainGoal: string;
  professor: string;
  zones: Zone[];
}

export interface LogLine {
  id: number;
  text: string;
  tone?: "info" | "good" | "bad" | "warn";
}

export interface BattleState {
  kind: "wild" | "boss";
  zoneId: string;
  bossName?: string;
  bossTitle?: string;
  enemyTeam: OwnedCreature[]; // original
  enemyIndex: number;
  playerIndex: number; // index dans save.team
  turn: number;
  log: LogLine[];
  awaitingSwitch: boolean;
  over: null | "win" | "lose" | "caught" | "flee";
  lastHit?: { side: "player" | "enemy"; dmg: number; eff: number; key: number };
  catchAnim?: number; // nb de secousses a animer
}
