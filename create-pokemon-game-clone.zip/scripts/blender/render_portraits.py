"""
VALDORIA — rendu automatique de portraits depuis les GLB rigges.
Usage : blender -b --python scripts/blender/render_portraits.py

Le script fonctionne sans interface graphique. Il importe les modeles CC0 deja
presents dans public/models/creatures, applique une scene studio Eevee et rend
un portrait PNG coherent pour chaque espece.
"""

import bpy
import math
import os
import numpy as np
from mathutils import Vector

# Compatibilite Blender 3.4 / importeur glTF avec NumPy >= 1.24.
if not hasattr(np, "bool"):
    np.bool = bool
if not hasattr(np, "int"):
    np.int = int
if not hasattr(np, "float"):
    np.float = float

ROOT = os.getcwd()
ASSET_DIR = os.path.join(ROOT, "public", "models", "creatures")
OUTPUT_DIR = os.path.join(ROOT, "public", "portraits3d")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Espece -> (asset, couleur de type)
SPECIES = {
    "pyrrax": ("gob_Corgi", "#ff7a45"),
    "hydriss": ("gob_Platypus", "#4aa3ff"),
    "feuillou": ("mount_deer", "#5fd98a"),
    "rocarok": ("mob_goleling", "#c9a15a"),
    "zephyrelle": ("mob_birb", "#9db8ff"),
    "sombraile": ("mob_ghost", "#b388ff"),
    "glacibou": ("mob_birb_blob", "#8fd8ff"),
    "foudrix": ("mob_bunny", "#ffd23f"),
    "drakonyx": ("mob_dragon_fly", "#f0a23d"),
    "flambaobab": ("mob_cactoro_blob", "#ff7a45"),
    "cameleonio": ("mob_frog", "#5fd98a"),
    "hippotide": ("gob_Hippo", "#4aa3ff"),
    "soleonix": ("boss1", "#ff7a45"),
    "zebrolt": ("mount_donkey", "#ffd23f"),
    "coyotflamme": ("gob_Corgi", "#ff7a45"),
    "racovert": ("mob_yeti_blob", "#5fd98a"),
    "castoreau": ("gob_Platypus", "#4aa3ff"),
    "thundereagal": ("mount_pegasus", "#ffd23f"),
    "bisonbron": ("gob_Rhino", "#c9a15a"),
    "tanukiflam": ("mob_cat_blob", "#ff7a45"),
    "pandaboo": ("mob_yeti", "#5fd98a"),
    "koiryu": ("mob_fish_blob", "#4aa3ff"),
    "shinryujin": ("boss10", "#f0a23d"),
    "tsurumi": ("gob_Duck", "#9db8ff"),
    "dragonnet": ("mob_dino", "#ff7a45"),
    "faeloup": ("mount_deer", "#5fd98a"),
    "phoquevalier": ("gob_Platypus", "#4aa3ff"),
    "arthurion": ("boss8", "#c9a15a"),
    "brumelin": ("mob_ghost_skull", "#b388ff"),
}


def hex_rgb(value):
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.armatures,
                       bpy.data.cameras, bpy.data.lights, bpy.data.materials):
        # Les images importees sont reutilisees par Blender puis liberees a la fin.
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def create_material(name, color, roughness=0.72, metallic=0.0, emission=None):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Specular"].default_value = 0.32
    if emission:
        bsdf.inputs["Emission"].default_value = (*emission, 1)
        bsdf.inputs["Emission Strength"].default_value = 1.5
    return mat


def add_area(name, location, energy, size, color):
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy
    data.shape = "DISK"
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    return obj


def point_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def imported_objects():
    return [o for o in bpy.context.scene.objects if o.type in {"MESH", "ARMATURE", "EMPTY"}]


def mesh_objects():
    return [o for o in bpy.context.scene.objects if o.type == "MESH"]


def world_bounds(objects):
    points = []
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in objects:
        evaluated = obj.evaluated_get(depsgraph)
        for corner in evaluated.bound_box:
            points.append(evaluated.matrix_world @ Vector(corner))
    if not points:
        return Vector((-1, -1, 0)), Vector((1, 1, 2))
    return Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points))), Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))


def tune_imported_materials():
    for obj in mesh_objects():
        # Lissage avec normales automatiques : silhouette douce, aretes conservees.
        for polygon in obj.data.polygons:
            polygon.use_smooth = True
        if hasattr(obj.data, "use_auto_smooth"):
            obj.data.use_auto_smooth = True
            obj.data.auto_smooth_angle = math.radians(38)
        for slot in obj.material_slots:
            mat = slot.material
            if not mat or not mat.use_nodes:
                continue
            bsdf = mat.node_tree.nodes.get("Principled BSDF")
            if bsdf:
                bsdf.inputs["Roughness"].default_value = 0.68
                bsdf.inputs["Specular"].default_value = 0.28


def normalize_model():
    roots = [o for o in imported_objects() if o.parent is None]
    meshes = mesh_objects()
    minimum, maximum = world_bounds(meshes)
    size = maximum - minimum
    factor = 2.35 / max(size.x, size.y, size.z, 0.01)
    center = (minimum + maximum) * 0.5
    for obj in roots:
        obj.scale *= factor
    bpy.context.view_layer.update()
    minimum, maximum = world_bounds(meshes)
    center = (minimum + maximum) * 0.5
    for obj in roots:
        obj.location.x -= center.x
        obj.location.y -= center.y
        obj.location.z -= minimum.z
    bpy.context.view_layer.update()


def render_one(species_id, asset_name, accent_hex):
    clear_scene()
    input_path = os.path.join(ASSET_DIR, asset_name + ".glb")
    if not os.path.exists(input_path):
        print("ABSENT", input_path)
        return
    bpy.ops.import_scene.gltf(filepath=input_path)

    # Choisit une animation d'attente et une image interessante.
    for obj in bpy.context.scene.objects:
        if obj.type == "ARMATURE" and obj.animation_data and obj.animation_data.action:
            action = obj.animation_data.action
            idle = next((a for a in bpy.data.actions if "idle" in a.name.lower()), None)
            if idle:
                obj.animation_data.action = idle
            bpy.context.scene.frame_set(8)
            break

    tune_imported_materials()
    normalize_model()
    accent = hex_rgb(accent_hex)

    # Socle a bords doux.
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=1.72, depth=0.10, location=(0, 0, -0.07))
    pedestal = bpy.context.object
    pedestal.name = "Studio_Pedestal"
    pedestal.data.materials.append(create_material("Pedestal", (0.055, 0.065, 0.095), 0.36, 0.18))
    bevel = pedestal.modifiers.new("Soft edge", "BEVEL")
    bevel.width = 0.06
    bevel.segments = 3

    # Anneau emissif au sol.
    bpy.ops.mesh.primitive_torus_add(major_segments=64, minor_segments=12, location=(0, 0, 0.015), major_radius=1.4, minor_radius=0.018)
    ring = bpy.context.object
    ring.data.materials.append(create_material("Type glow", accent, 0.3, 0.1, accent))

    # Fond vertical legerement courbe simule par un grand disque.
    bpy.ops.mesh.primitive_circle_add(vertices=64, radius=4.3, fill_type="NGON", location=(0, 1.8, 2.0), rotation=(math.radians(90), 0, 0))
    backdrop = bpy.context.object
    dark_accent = tuple(c * 0.10 + 0.018 for c in accent)
    backdrop.data.materials.append(create_material("Backdrop", dark_accent, 1.0))

    # Camera portrait.
    camera_data = bpy.data.cameras.new("Portrait Camera")
    camera = bpy.data.objects.new("Portrait Camera", camera_data)
    bpy.context.collection.objects.link(camera)
    camera.location = (3.9, -6.5, 3.0)
    camera_data.lens = 58
    point_at(camera, (0, 0, 1.15))
    bpy.context.scene.camera = camera

    # Eclairage trois points.
    key = add_area("Key", (-3.6, -4.2, 5.2), 850, 4.5, (1.0, 0.86, 0.70))
    point_at(key, (0, 0, 1.0))
    fill = add_area("Fill", (4.2, -1.8, 3.1), 520, 3.8, tuple(min(1, c * 0.7 + 0.3) for c in accent))
    point_at(fill, (0, 0, 1.0))
    rim = add_area("Rim", (0.5, 3.0, 4.7), 1050, 3.0, accent)
    point_at(rim, (0, 0, 1.35))

    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.eevee.use_gtao = True
    scene.eevee.gtao_distance = 3
    scene.eevee.gtao_factor = 1.35
    scene.eevee.use_bloom = True
    scene.eevee.bloom_intensity = 0.06
    scene.eevee.bloom_radius = 4
    scene.render.resolution_x = 512
    scene.render.resolution_y = 512
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.render.film_transparent = False
    scene.world.color = (0.008, 0.01, 0.025)
    scene.view_settings.look = "Medium High Contrast"
    scene.view_settings.exposure = 0.35
    scene.view_settings.view_transform = "Standard"
    scene.render.filepath = os.path.join(OUTPUT_DIR, species_id + ".png")
    bpy.ops.render.render(write_still=True)
    print("RENDER", species_id)


for species, (asset, color) in SPECIES.items():
    render_one(species, asset, color)

print("Portraits termines :", len(SPECIES))
